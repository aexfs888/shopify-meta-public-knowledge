- Facebook
# Facebook
Sign Up
## Customer List Custom Audiences Terms
Meta’s Customer List Custom Audiences feature enables you to create an audience using your data ("Customer List Data"). When using this feature, user contact information such as name, email address, and phone number is hashed before you upload and pass it to Meta to be used to create your audience (“Audience”). Without limiting any agreement between you and Meta, by clicking “I accept,” passing to Meta the Customer List Data, or using an Audience for advertising, you agree to the following:
You represent and warrant, without limiting anything in these Terms, that you have all necessary rights and permissions and a lawful basis to disclose and use the Audience and Customer List Data in compliance with all applicable laws, regulations, and industry guidelines. If you are using a Meta identifier to create an Audience, you must have obtained the identifier directly from Meta or the data subject in compliance with these terms.
- You represent and warrant, without limiting anything in these Terms, that the names you choose and the criteria you establish for your Audiences will not include, reflect, imply, or be based on, directly or otherwise, (i) information you know or reasonably should know is from or about children under the age of 13, (ii) identifiers we do not permit, such as social security or credit card numbers, or (iii) health information, financial information, consumer report information, or other categories of sensitive information (including any information defined as sensitive under applicable laws, regulations and applicable industry guidelines).
- If you are providing Customer List Data on behalf of an advertiser, you represent and warrant that you have the authority as agent to the advertiser to disclose and use such data on their behalf and will bind the advertiser to these terms.
- You represent and warrant that the Customer List Data does not relate to data about any individual who has exercised an option that you have, directly or indirectly, committed to honoring or provided to opt out of having such data used to create such audiences on Meta's platforms. To the extent an individual exercises such an opt-out after you have used data relating to them to create an Audience, you will remove them from the Audience.
- You instruct Meta to use the Customer List Data for the matching process to create the Audience. Meta will not share the Customer List Data with third parties or other advertisers and will delete the Customer List Data after the match process is complete subject to your choice of optional features. Technical details on how to use customer list custom audiences are available in our developer documentation . Meta will implement processes and procedures to maintain the confidentiality and security of the Customer List Data and the collection of Facebook User IDs that comprise the Audience(s) created from your Customer List Data (“your Audience(s)”), including by maintaining technical and physical safeguards that are designed to (a) protect the security and integrity of data while it is within Meta's systems and (b) guard against the accidental or unauthorized access, use, alteration or disclosure of data within Meta's systems. These processes and procedures include the measures listed in Meta’s Data Security Terms (as updated from time to time, for example, to reflect technological developments) which are expressly incorporated into these terms.
- Meta will not give access to or information about the Audience(s) to third parties or other advertisers, use your Audience(s) to append to the information we have about our users or build interest-based profiles, or use your Audience(s) except to provide services to you, unless we have your permission or are required to do so by law.
- You acknowledge that Meta offers tools to provide transparency to people about how Facebook advertising works, to explain why people are shown specific ads, and to allow people to control their ads experience. You also acknowledge that Meta does not disclose to you which individual users comprise your Audience created based on your Customer List Data.
- Meta may modify, suspend or terminate access to, or discontinue the availability of, this feature at any time. You may discontinue your use of Audiences at any time. You may delete your Audience(s) from the Meta system at any time through your account tools.
- You may not use this feature unless you are an advertiser (or an agency acting on behalf of an advertiser), Ads API or Custom Audiences API partner, a data partner uploading an audience on behalf of that advertiser, or have obtained express, written permission from Meta.
- You may not sell or transfer your Audiences, or authorize any third party to sell or transfer Audiences. However, advertisers and their service providers, as well as independent parties you have entered into agreements with for licensing marketing information, can share Audiences with each other through tools we make available for that purpose, subject to the restrictions and requirements of those tools, our terms, and applicable law.
- Data Processing Terms: To the extent Customer List Data contain Personal Information which you Process subject to the General Data Protection Regulation (Regulation (EU) 2016/679) (the “GDPR”) or you are in Andorra, Azores, Canary Islands, Channel Islands, French Guiana, Guadeloupe, Isle of Man, Madeira, Martinique, Mayotte, Monaco, Réunion, San Marino, Saint Barthélemy, Saint-Martin, Switzerland, United Kingdom sovereign bases in Cyprus (Akrotiri or Dhekelia), or Vatican City, the parties acknowledge and agree that for purposes of creating your Audience(s), as described above, that you are the Controller in respect of such Personal Information, and you instruct Meta Platforms Ireland Limited., Block J, Serpentine Avenue, Dublin 4 Ireland (“Meta Ireland”) to Process such Personal Information on your behalf as your Processor pursuant to these terms and Meta’s Data Processing Terms . The Data Processing Terms are expressly incorporated herein by reference and apply between you and Meta Ireland together with these Customer List Custom Audiences Terms.
- To the extent that Customer List Data contains Personal Information which you Process subject to the UK GDPR (as defined under the Data Protection Act 2018), the parties acknowledge and agree that for purposes of creating your Audience(s), as described above, that you are the Controller in respect of such Personal Information, and you instruct Meta Platforms, Inc., 1 Meta Way, Menlo Park, CA 94025 USA to Process such Personal Information on your behalf as your Processor pursuant to these terms and Meta's Data Processing Terms . The Data Processing Terms are expressly incorporated herein by reference and apply between you and Meta Platforms, Inc. together with these Customer List Custom Audiences Terms. For the avoidance of doubt, this Section 11.b takes precedence over Section 11.a where the Personal Information relates to individuals living in the UK. In all other cases, Section 11.a takes precedence.
- In all other cases, the parties acknowledge and agree that for purposes of creating your Audience(s), as described above, that you are the controller in respect of such Personal Information, and you instruct Meta Platforms, Inc., 1 Meta Way, Menlo Park, CA 94025 USA to Process such Personal Information on your behalf as your Processor pursuant to these terms and Meta’s Data Processing Terms . The Data Processing Terms are expressly incorporated herein by reference and apply between you and Meta Platforms, Inc. together with these Customer List Custom Audiences Terms.
- “Personal Information,” “Controller,” “Processor” and “Processing” in this Section 11 have the meanings set out in the Data Processing Terms .
- For US data subjects: The parties acknowledge and agree that the State-Specific Terms may apply to the provision and use of this feature and are incorporated into these Customer List Custom Audiences Terms by reference.
- These terms and, to the extent applicable, the Data Processing Terms are supplemental to the Commercial Terms and do not replace any other terms applicable to your purchase of advertising inventory from Meta (including but not limited to the Meta Advertising Standards and Self-Serve Ads Terms , which will continue to apply. In the event of any conflict between these terms and the Commercial Terms, these terms will govern with respect to your use of this feature and solely to the extent of the conflict. Meta reserves the right to monitor or audit your compliance with these terms and to update these terms from time to time.
- These terms apply to the creation of Audiences as described above. Website Custom Audiences, Mobile App Custom Audiences, and Offline Custom Audiences are subject to the Business Tools Terms. We have updated the Custom Audiences Terms, including changing its name to the Customer List Custom Audiences Terms. For purposes of the Customer List Custom Audiences Terms, references in existing terms or agreements to the “your custom audience(s)” will now mean Audience(s).
Effective Date: December 3, 2025
- English (US)
- Español
- Français (France)
- 中文(简体)
- العربية
- Português (Brasil)
- Italiano
- 한국어
- Deutsch
- हिन्दी
- 日本語
-
- Sign Up
- Log In
- Messenger
- Facebook Lite
- Video
- Meta Pay
- Meta Store
- Meta Quest
- Ray-Ban Meta
- Meta AI
- Muse
- Instagram
- Threads
- Privacy Policy
- Consumer Health Privacy
- Privacy Center
- About
- Create ad
- Create Page
- Developers
- Careers
- Cookies
- Ad choices
- Terms
- Help
- Contact Uploading & Non-Users
- Settings
- Activity log
Meta © 2026
