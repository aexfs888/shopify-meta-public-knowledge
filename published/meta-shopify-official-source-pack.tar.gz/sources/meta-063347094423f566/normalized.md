- Facebook
# Facebook
Registrarte
## Condiciones de los públicos personalizados de listas de clientes
La función de público personalizado a partir de lista de clientes de Meta te permite crear un público a partir de datos que ya tienes ("Datos de listas de clientes"). Al usar esta función, la información de contacto del usuario, como su nombre, dirección de correo electrónico y número de teléfono, se pasa a formato hash antes de que la subas y la transfieras a Meta para que se use en la creación del público ("Público"). Sin perjuicio del acuerdo entre Meta y tú, al hacer clic en "Acepto" y transferir los Datos de listas de clientes o usar un Público para fines publicitarios, aceptas las siguientes condiciones:
Sin perjuicio de ninguna de las presentes condiciones, declaras y garantizas que posees todos los derechos y permisos necesarios, así como los fundamentos legales, para divulgar y usar los Datos de listas de clientes de conformidad con todas las leyes, regulaciones y normas del sector pertinentes. Si usas un identificador de Meta para crear un Público, debes haberlo obtenido directamente de Meta o del interesado, según lo estipulado en las presentes condiciones.
- Sin limitación de ninguna disposición incluida en estas Condiciones, declaras y garantizas que los nombres que elijas y los criterios que establezcas para tus Públicos no incluirán, reflejarán ni insinuarán (i) información que sabes, o deberías saber de forma razonable, que procede de menores de 13 años o se relaciona con ellos, (ii) identificadores que no permitimos, como números de la seguridad social o de tarjetas de crédito, o (iii) información de salud, finanzas, informes de consumidores u otras categorías de información confidencial (incluida aquella que se define como confidencial en virtud de las leyes, regulaciones y normas del sector aplicables), así como tampoco se basarán en ellos, de manera directa o de otro modo.
- Si proporcionas Datos de listas de clientes en nombre de un anunciante, declaras y garantizas que, como representante del anunciante, tienes autorización para divulgar y usar estos datos en su nombre, y que dicho tercero quedará supeditado a las presentes condiciones.
- Declaras y garantizas que los Datos de listas de clientes no están relacionados con datos de personas que hayan ejercido una opción que, directa o indirectamente, te comprometiste a respetar o proporcionaste para que rechacen el uso de esos datos a fin de crear dichos públicos en las plataformas de Meta. En el caso de que una persona elija no participar con sus datos una vez que ya los hayas utilizado para crear un Público, eliminarás a dicha persona del Público.
- Le indicas a Meta que use los Datos de listas de clientes en el proceso de asociación para crear el Público. Meta no compartirá dichos datos con terceros u otros anunciantes, y los eliminará luego de que se complete el proceso de asociación, sujeto a las funciones opcionales que hayas elegido. Consulta los detalles técnicos sobre cómo usar los públicos personalizados de listas de clientes en nuestra documentación para desarrolladores . Meta implementará procesos y procedimientos para respetar la confidencialidad y la seguridad de los Datos de listas de clientes y de los identificadores de usuario de Facebook recopilados que conformen el Público creado a partir de los Datos de listas de clientes ("tu Público") a través de medidas de seguridad técnicas y físicas desarrolladas con el fin de (a) proteger la seguridad y la integridad de los datos mientras estos se encuentran en los sistemas de Meta y (b) evitar que se acceda a ellos, usen, modifiquen o divulguen en los sistemas de Meta de forma accidental o sin autorización. Estos procesos y procedimientos incluyen las medidas que se enumeran en las Condiciones de seguridad de los datos de Meta (según las actualizaciones periódicas, por ejemplo, para reflejar desarrollos tecnológicos), que se incorporan expresamente en estas condiciones.
- Meta no proporcionará información sobre los Públicos ni concederá acceso a estos a otros anunciantes ni a terceros, así como tampoco usará tus Públicos para ampliar la información que ya posee sobre los usuarios en cuestión o crear perfiles en función de intereses ni de ninguna otra manera que no sea para ofrecerte sus servicios, a menos que cuente con tu permiso o así lo exija la ley.
- Reconoces que Meta ofrece herramientas que proporcionan transparencia a las personas en cuanto al funcionamiento de la publicidad de Facebook, explican los motivos por los que se muestran anuncios específicos y permiten que estas controlen su experiencia publicitaria. Asimismo, reconoces que Meta no te informa qué usuarios concretos forman parte de los Públicos que creaste a partir de los Datos de listas de clientes.
- Meta puede modificar, suspender o cancelar el acceso a esta función en cualquier momento, así como interrumpir su disponibilidad. Tú también podrás dejar de utilizar Públicos en cualquier momento. Asimismo, puedes eliminar tus Públicos del sistema de Meta cuando quieras mediante las herramientas de tu cuenta.
- No podrás usar esta función, a menos que seas un anunciante (o una agencia que actúe en nombre de un anunciante), un socio de API de anuncios o de API de públicos personalizados o un socio de datos que haya subido un público en nombre de dicho anunciante, o que hayas obtenido el permiso expreso por escrito de Meta.
- No puedes vender ni transferir tus Públicos, ni autorizar a terceros para que los vendan o transfieran. No obstante, los anunciantes y sus proveedores de servicios, así como aquellos terceros independientes con los que hayas celebrado acuerdos para autorizar el uso de la información de marketing, podrán compartir Públicos entre sí a través de las herramientas que ponemos a disposición a tal efecto, conforme a las restricciones y los requisitos de dichas herramientas, las condiciones de Facebook y la legislación aplicable.
- Condiciones del tratamiento de datos: En la medida en que los Datos de listas de clientes incluyan Información personal cuyo tratamiento lleves a cabo con sujeción al Reglamento General de Protección de Datos (Reglamento [UE] 2016/679) ("RGPD"), o en caso de que te encuentres en Andorra, áreas de base soberana del Reino Unido en Chipre (Acrotiri o Dhekelia), Azores, Ciudad del Vaticano, Guadalupe, Guayana Francesa, Isla de Man, Islas Canarias, Islas del Canal, Madeira, Martinica, Mayotte, Mónaco, Reunión, San Bartolomé, San Marino, San Martín o Suiza, las partes reconocen y aceptan que eres el Responsable respecto de dicha Información personal a efectos de la creación de tus Públicos, tal como se describe anteriormente, y que encargas a Meta Platforms Ireland Limited., Block J, Serpentine Avenue, Dublín 4 Irlanda ("Meta Ireland") llevar a cabo el tratamiento de la Información personal en tu nombre en calidad de Encargado, de conformidad con las presentes condiciones y las Condiciones del tratamiento de datos de Meta. Las Condiciones del tratamiento de datos se incorporan expresamente aquí por referencia y se aplican entre tú y Meta Ireland junto con estas Condiciones de los públicos personalizados de listas de clientes.
- En la medida en que los Datos de listas de clientes contengan Información personal cuyo tratamiento lleves conforme al RGPD del Reino Unido (según se define en la Ley de Protección de Datos de 2018), las partes reconocen y aceptan que eres el Responsable respecto de la Información personal a efectos de la creación de tus Públicos, tal como se describe anteriormente, y que encargas a Meta Platforms, Inc., 1 Meta Way, Menlo Park, CA 94025, EE. UU. llevar a cabo el tratamiento de la Información personal en tu nombre en calidad de Encargado de conformidad con las presentes condiciones y las Condiciones del tratamiento de datos de Meta. Las Condiciones del tratamiento de datos se incorporan expresamente aquí por referencia y se aplican entre tú y Meta Platforms, Inc. junto con estas Condiciones de los públicos personalizados de listas de clientes. Para evitar dudas, la sección 11.b tendrá prioridad sobre la sección 11.a cuando la Información personal se relacione con personas que viven en el Reino Unido. En cualquier otro caso, tendrá prioridad la sección 11.a.
- En todos los demás casos, las partes reconocen y aceptan que eres el Responsable respecto de la Información personal a efectos de la creación de tus Públicos, tal como se describe anteriormente, y que encargas a Meta Platforms, Inc., 1 Meta Way, Menlo Park, CA 94025, EE. UU., llevar a cabo el tratamiento de la Información personal en tu nombre en calidad de Encargado, de conformidad con las presentes condiciones y las Condiciones del tratamiento de datos de Meta. Las Condiciones del tratamiento de datos se incorporan expresamente aquí por referencia y se aplican entre tú y Meta Platforms, Inc. junto con estas Condiciones de los públicos personalizados de listas de clientes.
- Los términos "Información personal", "Responsable", "Encargado" y "Tratamiento" en esta sección 11 tienen los significados establecidos en las Condiciones del tratamiento de datos .
- Interesados en los Estados Unidos: las partes reconocen y aceptan que las Condiciones específicas de estados se apliquen a la prestación y al uso de esta función, y se incorporen a las presentes Condiciones de los públicos personalizados de listas de clientes.
- Estas condiciones y las Condiciones del tratamiento de datos , en la medida en que estas se apliquen, complementan las Condiciones comerciales y no sustituyen a ningunas otras que rijan la compra de inventario publicitario de Meta por tu parte (incluidas, entre otras, las Normas de publicidad de Meta y las Condiciones de los anuncios de autoservicio , que seguirán prevaleciendo). En caso de conflicto entre las presentes condiciones y las Condiciones comerciales, prevalecerán las primeras en lo referente al uso que hagas de esta función y solo en el ámbito del conflicto. Meta se reserva el derecho a supervisar o auditar tu cumplimiento de estas Condiciones, así como a actualizarlas ocasionalmente.
- Estas condiciones rigen la creación de Públicos tal como se describe anteriormente. Los públicos personalizados del sitio web, los públicos personalizados de la app para celulares y los públicos personalizados offline están sujetos a las Condiciones de las herramientas empresariales. Realizamos actualizaciones de las Condiciones de los públicos personalizados, como la modificación de su nombre a "Condiciones de los públicos personalizados de listas de clientes". A los efectos de las Condiciones de los públicos personalizados de listas de clientes, a partir de ahora las referencias a "tus públicos personalizados" en condiciones o acuerdos existentes serán equivalentes a "Públicos".
Fecha de entrada en vigencia: 3 de diciembre de 2025
- Español
- English (US)
- Português (Brasil)
- Français (France)
- Italiano
- Deutsch
- العربية
- 日本語
- हिन्दी
- 中文(简体)
-
- Registrarte
- Iniciar sesión
- Messenger
- Facebook Lite
- Video
- Meta Pay
- Tienda de Meta
- Meta Quest
- Ray-Ban Meta
- Meta AI
- Muse
- Instagram
- Threads
- Política de privacidad
- Centro de privacidad
- Información
- Crear anuncio
- Crear página
- Desarrolladores
- Empleo
- Cookies
- Opciones de anuncios
- Condiciones
- Ayuda
- Importación de contactos y no usuarios
- Configuración
- Registro de actividad
Meta © 2026
