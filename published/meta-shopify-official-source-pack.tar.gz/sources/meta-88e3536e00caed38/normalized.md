# Metadata Tags
You can optionally set metadata tags in your product feed files. Setting these tags enables Facebook to attribute catalogs using this feed to your app. Once a catalog is attributed to your app, you don&#039;t need to include the metadata tags in subsequent feed uploads to that catalog.
Include the following elements as space-delimited comments at the top of TSV/CSV (tab-separated and comma-separated) feeds or inside a `metadata` tag in your XML feeds:
* `ref_application_id` — Your Facebook app ID
* `ref_asset_id` - ID that uniquely identifies this feed in your system
## Feed formats
| Feed Format | Description |
| --- | --- |
| CSV | Sample CSV Feed file with reference information inside the metadata tag.Download (Right-Click &gt; Save Link As) |
| TSV | Sample TSV Feed file with reference information inside the metadata tag. Download (Right-Click &gt; Save Link As) |
| RSS XML | Sample RSS XML Feed file with reference information inside the metadata tag. Download (Right-Click &gt; Save Link As) |
| ATOM XML | Sample Atom XML Feed file with reference information inside the metadata tag. Download (Right-Click &gt; Save Link As) |
#### Example - TSV feed format
```
# ref_application_id &lt;YOUR_APP_ID&gt;
# ref_asset_id &lt;YOUR_ASSET_ID&gt;
id title ios_url ios_app_store_id ios_app_name android_url android_package android_app_name windows_phone_url windows_phone_app_id windows_phone_app_name description google_product_category product_type link image_link condition availability price sale_price sale_price_effective_date gtin brand mpn item_group_id gender age_group color size shipping custom_label_0
DB_1 Dog Bowl In Blue example-ios://electronic/db_1 123 Electronic Example iOS example-android://electronic/db_1 com.electronic.example Electronic Example Android example-windows://electronic/db_1 64ec0d1b-5b3b-4c77-a86b-5e12d465edc0 Electronic Example Windows Solid plastic Dog Bowl in marine blue color Animals &gt; Pet Supplies Bowls &amp; Dining &gt; Food &amp; Water Bowls http://www.example.com/bowls/db-1.html https://www.facebook.com/images/product_image_template.png?id=1 new in stock 9.99 GBP Example DB_GROUP_1 UK::Standard:9.95 GBP &quot;Made in Waterford, IE&quot;
...
```
#### Example - RSS XML feed format
```
...
&lt;?xml version=&quot;1.0&quot;?&gt;
&lt;rss xmlns:g=&quot;http://base.google.com/ns/1.0&quot; version=&quot;2.0&quot;&gt;
&lt;channel&gt;
&lt;metadata&gt;
&lt;ref_application_id&gt;&lt;YOUR_APP_ID&gt;&lt;/ref_application_id&gt;
&lt;ref_asset_id&gt;&lt;YOUR_ASSET_ID&gt;&lt;/ref_asset_id&gt;
&lt;/metadata&gt;
&lt;/channel&gt;
&lt;/rss&gt;
...
```
#### Example - ATOM XML feed format
```
...
&lt;?xml version=&quot;1.0&quot;?&gt;
&lt;rss xmlns:g=&quot;http://base.google.com/ns/1.0&quot; version=&quot;2.0&quot;&gt;
&lt;feed&gt;
&lt;metadata&gt;
&lt;ref_application_id&gt;&lt;YOUR_APP_ID&gt;&lt;/ref_application_id&gt;
&lt;ref_asset_id&gt;&lt;YOUR_ASSET_ID&gt;&lt;/ref_asset_id&gt;
&lt;/metadata&gt;
&lt;/feed&gt;
&lt;/rss&gt;
...
```
