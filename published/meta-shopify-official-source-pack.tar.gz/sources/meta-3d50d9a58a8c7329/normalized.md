Facebook
Logged in on your phone?
Scan the QR code with your phone’s camera and enter this code.
LBX-EFB-KYXQ
Log into Facebook
English (US)
Español
Français (France)
中文(简体)
العربية
Português (Brasil)
Italiano
More languages…
Sign Up
Log In
Messenger
Facebook Lite
Video
Meta Pay
Meta Store
Meta Quest
Ray-Ban Meta
Meta AI
Muse
Instagram
Threads
Privacy Policy
Privacy Center
About
Create ad
Create Page
Developers
Careers
Cookies
Ad choices
Terms
Help
Contact Uploading & Non-Users
