Facebook
Explore the things you love .
Log into Facebook
English (US)
Español
Français (France)
中文(简体)
العربية
Português (Brasil)
Italiano
More languages…
Sign Up
Log In
Messenger
Facebook Lite
Video
Meta Pay
Meta Store
Meta Quest
Ray-Ban Meta
Meta AI
Instagram
Threads
Privacy Policy
Privacy Center
About
Create ad
Create Page
Developers
Careers
Cookies
Ad choices
Terms
Help
Contact Uploading & Non-Users
