Facebook
Explore the things you love .
Log into Facebook
English (US)
Français (Canada)
Español
中文(简体)
한국어
日本語
Português (Brasil)
More languages…
Sign Up
Log In
Messenger
Facebook Lite
Video
Meta Pay
Meta Store
Meta Quest
Ray-Ban Meta
Meta AI
Muse
Instagram
Threads
Privacy Policy
Privacy Center
About
Create ad
Create Page
Developers
Careers
Cookies
Ad choices
Terms
Help
Contact Uploading & Non-Users
