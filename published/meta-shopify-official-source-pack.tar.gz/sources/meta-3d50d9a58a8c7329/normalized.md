Facebook
好きなこと をチェックしよう。
Facebookにログイン
日本語
English (US)
Português (Brasil)
中文(简体)
Tiếng Việt
Español
Bahasa Indonesia
その他の言語…
アカウント登録
ログイン
Messenger
Facebook Lite
動画
Meta Pay
Metaストア
Meta Quest
Ray-Ban Meta
Meta AI
Instagram
Threads
プライバシーポリシー
プライバシーセンター
Facebookについて
広告を作成
ページを作成
開発者
採用情報
Cookie
AdChoices
利用規約
ヘルプ
連絡先のアップロードと非ユーザー
