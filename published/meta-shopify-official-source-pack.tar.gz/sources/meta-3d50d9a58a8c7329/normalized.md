- Instagram & Facebook Reels: Create Short Video Ads | Meta for Business
Overview
#### Reels ads
# Turn attention into action with Instagram and Facebook Reels ads.
Develop creative built for Reels to supercharge your business results.
Download the guide
Create Reels ads
Something went wrong
We're having trouble playing this video.
Learn more
## What are Reels ads?
Reels ads are immersive, built-for-mobile ads that reach a high-intent audience. Reels is seamlessly integrated into the AI-enabled Meta Advantage suite of ad placements, allowing you to benefit from the immense scale, advanced targeting and measurement solutions Meta offers.
Read more Collapse
## Reach your business goals with Reels ads.
### Ignite connection.
People participate, share, have conversations and take action in Reels.
### Enhance performance, backed by AI.
Reels is built into Meta Advantage, allowing you to amplify results across objectives.
### Multiply success with creative.
Reels ads with key messages in the safe zone, quality audio and vertical video see better results.
## See real results with Reels ads.
79%
of people surveyed say they’ve purchased a product or service after watching Reels. 1
2x
higher delivery to the Reels placement for campaigns that included 9:16 video ads with audio, with key messages in the safe zone 2
34.5%
lower cost per result compared to image ads for campaigns that included 9:16 video ads with audio, with key messages in the safe zone. 3
Get started
## Build Reels ads that drive performance.
## Utilize free tools to create Reels ads with ease
## Canva
Build on customizable templates that automatically apply best practices. Use the Meta Design Check app to review your reels before setting them up as ads.
Create Reels ads
## Adobe Express
Select your template and click the Safe Zones feature to ensure key elements like messaging and visuals are not being overlapped by the Reels user interface.
Create Reels ads
## Discover pro tips for building successful Reels ads.
Watch video
## How to set up your Reels ads campaign.
Include Reels as a placement for your campaign in Meta Ads Manager.
#### 1. Select your placements
#### 2. Incorporate your ad creative
#### 3. Test and learn with A/B testing
### 1. Select your placements
After creating your campaign as usual in Ads Manager, view the Placements section at the ad set level.
You have two options:
a. Advantage+ placements.
This is recommended since it enables your ad to be seen on all placements including Facebook, Messenger, Instagram and Audience Network and allows our delivery system to try to make the most of your budget and increase your ad’s exposure. When you choose this option, it includes both Facebook and Instagram Reels.
b. Manual placements.
Use the check boxes to select Facebook Reels and Instagram Reels under Stories and Reels. It's recommended to select six or more placements.
### 2. Incorporate your ad creative
You can upload new ad creative built for Reels at the ad level. Here, you can use placement asset customization and make use of all the placements where your ad creative can be shown, including Reels. You can also select Advantage+ creative to optimize your reels.
To promote an existing reel, go to the ad setup section and select Use existing post . For reels you own, go to the Facebook or Instagram tab and select your reel. For branded content, go to Partner content .
Note: You will need to toggle on Allow business partners to promote . Otherwise, you can publish the ad and the creator will receive a request to grant permission to post.
### 3. Test and learn with A/B testing
Once you have incorporated Reels into your business strategy, you can run an A/B test to determine the impact.
Test and learn with native ad creative for Reels or assets optimized for Reels ads. Incorporating Reels ad placements or selecting Advantage+ placements can help you gain insight into optimizing your campaign strategy.
Improve setup
## Explore the language of Reels.
###
Once you master the creative essentials, consider creating Reels ads that lean into the communication style of Reels.
## Use Advantage+ Creative to optimize your Reels
Automate your creative with Advantage+ in Ads Manager at the ad level. Opting in to Advantage+ Creative can help improve performance.
Expand all Collapse all
### Adjust the aspect ratio of image and video ads.
Fine-tune visuals will automatically adjust the aspect ratio of your ad’s creative where it can improve performance.
- Image expansion uses generative AI to automatically expand your creative for the 9:16 vertical aspect ratio of Reels to make your creative look more natural in the Reels placement and save you time.
### Add music to your image ads.
- Let our AI automatically select a song from our royalty free library that is most likely to resonate with your audience and makes sense within the context of your ad. By automatically applying music, you’ll let us select a song to accompany your ad based on the content of your ad.
- Or, Manually select up to five songs based on the mood, artist and more. We’ll use a song from one of your selections when delivering the ads. Selected music will be trimmed across eligible placements.
## Work with a Meta Business Partner for faster, easier integrations.
Take your Reels ads to the next level.
Canva
Videoleap
Adobe Express
Find more partners
Inspiration
## "After rolling out Reels ads on top of my ads that click to Messenger, my return on ad spend doubled from 12X to 25X. I am so grateful to Meta for their help, and am thrilled that my ads are performing so well, and helping my business thrive!" 1
Mr. Keng, Owner
Baan Talay Seafood
## "By bundling Reels ads with Click-to-Message campaigns, we experienced a surge in conversations within just 24 hours. We achieved a 55-65% reduction in CPC and a conversion rate from messages to orders between 20-25%!" 1
Abed Moustafa, Founder & CEO
Amigo Social Media Marketing
## "We were previously using carousel photo ads without much planning. After our agency introduced us to the idea of Reels ads that click to WhatsApp, the volume of leads increased considerably, reaching over a thousand each month — a huge leap." 1
Renato Steponovicius, Partner & Director
Face Doctor Piedade
## "I combined a Reels ad with a Click-to-Message campaign on Instagram to showcase our new slippers collection. The results were amazing - a 32% increase in clicks and higher engagement rates, especially among younger audiences." 1
Khaled Kaa El Kef, Media Buyer
Made For You
## Want to learn from businesses like these?
Join Meta Business Growth Forums to connect with fellow business leaders, exchange ideas and unlock new opportunities.
Join now
## See how real businesses use Reels ads.
Resources
## See the latest best practices and courses for Reels ads.
Meta Blueprint course
### Reach your business goals with Reels ads
Start lesson
Meta Blueprint course
### How to create engaging Reels
Start lesson
Meta Blueprint course
### Ad placement and formats
Start lesson
Meta Blueprint course
### How to use Reels ads for your business
Start lesson
On demand webinar
### Reels Measurement
Watch now
## Frequently Asked Questions
Expand all Collapse all
### How often will users see Reels ads?
The auction delivers ads dynamically based on a range of criteria including advertiser targeting settings, to the value the ad drives to the user. Depending on the instance and criteria being met, an ad may or may not be delivered.
### Will the ads play with automatic sound on?
Reels default to Sound On. The ads will play with sound on if the user hasn’t turned off the sound setting.
### Where will ads show in Reels?
In order to be served a Reels ad, the user first needs to tap into the immersive Reels viewer. They are able to get there from three different entry points: 1) Dedicated Reels Tab, 2) Reels in Explore, 3) Reels In-Feed Unit. After someone taps into the Reels viewer, ads are eligible to deliver as part of the browsing experience. Ads will not be displayed on Audio pages.
### Can I run image ads in Reels?
You are encouraged to opt-in to Reels ads with whatever asset you have available, as there are performance benefits no matter your creative. That said, many advertisers value the impact that creative can drive in their media strategy. In tests, Reels ads that were built in 9:16 video, with audio, and key creative elements in the safe zone had 34.5% lower cost per result than image ads on Reels ads.
Source: Statistical global Meta-analysis of 15 split tests of Reels-only campaigns where advertisers used a still image asset in one campaign and 9:16 video with sound on respecting safe zones in another campaign. Advertiser verticals included ecommerce, retail and consumer packaged goods and included small and medium businesses. This approach outperformed with 99.9% confidence.
### How can I crop my video assets to 9:16 aspect ratio?
Learn how to crop your video to vertical 9:16 ratio in Ads Manager.
### How can I check to see if my Reels ads creative is compliant with the Reels safe zone?
Check that your key creative elements are in the safe zone with the Reels safe zone checker ( ppt , psd , keynote ). Learn more about the safe zone here .
### How can I get help creating Reels ads?
From lightweight templates to full-scale production and working with creators, Meta Business Partners offer end-to end solutions for Reels on Facebook and Instagram, so you can create quality campaigns at speed and scale. In a recent study, we saw adding partner-enabled native Reels creative — 9:16 video with audio, in the safe zone — to a business-as usual campaign setup drove on average a 5% lower cost per result and an 11% higher conversion rate.
Source: Results from the Meta-analysis of a series of 15 A/B tests across verticals and global regions (DE, ES, ID, UK and US); n = 15 studies conducted May 2022- Apr 2023. Test cell setup (Partner-enabled creative on Reels placement with at least 30% campaign budget and business-as-usual non-9:16 creative across other placements).
### How can I find a creator partner to create Reels ads?
In select markets, leverage the Instagram creator marketplace to discover the right creators and create partnership ads to maximize the impact of your partnership. Instagram’s creator marketplace utilizes personalized, machine learning-driven creator recommendations based on first-party data to help you identify branded content reels for your brand that can be boosted into high performing campaigns.
### How can I add music to my Reels ads?
Add audio to your ad with Sound Collection to download free audio that you can use in your creative, or let Meta’s Advantage+ creative automate your music selection.
### Where can I find the specs for Reels ads?
Video ads guide
## Energize your brand with Reels ads.
Supercharge your business results by turning attention into action.
Create ads
## Related Content
Get creative with ads
Creatively engage your audience with Instagram
Create Engaging Content for Your Instagram Audience
Manage your online presence with the Facebook Business Suite
Create Instagram promotions in five steps
Meta Travel Advertising: Reach Travelers Throughout Their Journey
## Get the latest updates from Meta for Business.
Provide your email address to receive the latest updates from Meta for Business, including news, events and product updates.
© 2026 Meta
About Developers Careers Privacy Cookies Terms Help Center
English (US) English (UK) Español Português (Brasil) Français (France) Español (España) More languages
#### Log in to Meta for Business
Manage your ad accounts and get personalized support.
Log in with Facebook
