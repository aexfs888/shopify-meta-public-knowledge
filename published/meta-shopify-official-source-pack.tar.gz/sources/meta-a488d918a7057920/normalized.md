-
100-101 Meta Certified Digital Marketing Associate Exam Courses : Learn new skills to build your brand or business
Skip to main content
This site uses cookies to provide you with a greater user experience. By using Exceed LMS, you accept our use of cookies .
Search
Topics
##
All Topics
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
Log In
The Digital Marketing Associate path provides fundamental knowledge to connect with customers across Meta technologies and to explore the basics of campaign creation on our platforms.
-
###
Start marketing with Meta technologies
In this course, you’ll learn about the Meta technologies you can use to grow your business online. You’ll discover ways Facebook, Messenger, Instagram and WhatsApp can help to build awareness, engage customers and achieve business goals.
Duration
10m
-
Rating 4.8
- Beginner
-
Credential
-
###
Build an online presence with a Facebook Page
Learn how to create and maintain a Page, build an audience and implement best practices for posting on Facebook.
Duration
30m
-
Rating 4.9
- Beginner
-
Credential
-
###
Build an online business presence with Instagram
Discover how to create and use a business account on Instagram, identify how to set up your profile and explore key business account features.
Duration
25m
-
Rating 4.8
- Beginner
-
Credential
-
###
Establish your business presence with Messenger
Discover how to engage with customers through Messenger and use different features to communicate more efficiently.
Duration
10m
-
Rating 4.7
- Beginner
-
Credential
-
###
Use WhatsApp for a business
Learn how to create a WhatsApp Business Account and explore key features for communicating with customers.
Duration
18m
-
Rating 4.9
- Beginner
-
Credential
-
###
Connect with customers using Meta Business Suite
Learn how to use Meta Business Suite to manage your presence on both Facebook and Instagram, connect with customers, create ads and grow your business — all from one central location.
Duration
19m
-
Rating 4.9
- Beginner
-
Credential
-
###
Get started with advertising on Facebook and Instagram
Learn about what ads on Facebook look like and how to use a Facebook business Page and Ads Manager to create ads.
Duration
15m
-
Rating 4.9
- Beginner
-
Credential
-
###
Introduction to campaign objectives
Learn how to define business goals, select the correct ad objective and measure success in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Intermediate
-
###
Create audiences in Meta Ads Manager
Learn about the different types of audiences available for ads and how to create them for campaigns in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Intermediate
-
###
Choose ad placements, budget and schedule in Meta Ads Manager
Learn how to choose placements and set a budget and schedule for ad campaigns in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Beginner
-
###
Customize ad creative in Meta Ads Manager
Learn how to create ads and review format, placement and creative options in Meta Ads Manager.
Duration
20m
-
Rating 4.8
- Intermediate
-
###
Set up the Meta Pixel and Meta Conversions API for ad campaigns
Use the Meta Pixel and the Conversions API to gain insight into customer actions and optimize your advertising strategy.
Duration
10m
-
Rating 4.9
- Beginner
-
Credential
-
###
Analyze your ad campaign results in Meta Ads Manager
Learn where to find key metrics in Ads Manager and how to use them to analyze campaign results.
Duration
10m
-
Rating 4.8
- Intermediate
-
###
Privacy and data protection across Meta technologies
Learn about privacy and data protection on Meta technologies, as well as how to create ads that adhere to Meta's ad policies.
Duration
10m
-
Rating 4.8
- Beginner
-
Credential
-
###
Opportunity score: experimentally proven recommendations to help improve your campaign performance
Learn how you can use opportunity score in Ads Manager to help improve your campaign performance.
Duration
30m
-
Rating 4.8
- Intermediate
-
Credential
##
All Topics
-
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
##
Review
##
Warning: Closing this page may affect activity tracking!
This page is used by your activity to communicate with the learning platform. Please be sure to close all activity windows before closing or navigating away from this page.
Return to activity
Did you arrive on this page without seeing a new activity window launch? You may have a pop-up blocker. Check out pop-up blocker tips here.
