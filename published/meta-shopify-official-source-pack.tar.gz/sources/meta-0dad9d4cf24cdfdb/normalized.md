Versiones - API Graph - Documentación - Meta for Developers
-
API Graph
Información general
- Primeros pasos
- Solicitudes por lotes
- Solicitudes de depuración
- Administrar errores
- Field Expansion
- Secure Requests
- Registro de cambios
- Reference
# Versiones
Los registros de cambios que se enumeran a continuación documentan los cambios presentados en las nuevas versiones de la API Graph y la API de marketing. Para obtener más información sobre las versiones, consulta el documento Versiones de la plataforma .
Los cambios introducidos fuera de una versión se asientan en nuestro documento Cambios sin versión .
## API Graph
Versión
|
Fecha de lanzamiento
|
Fecha de caducidad
|
v26.0
|
29 de julio de 2026
|
Por determinar
|
v25.0
|
18 de febrero de 2026
|
29 de julio de 2028
|
v24.0
|
8 de octubre de 2025
|
18 de febrero de 2028
|
v23.0
|
29 de mayo de 2025
|
8 de octubre de 2027
|
v22.0
|
21 de enero de 2025
|
20 de mayo de 2027
|
v21.0
|
2 de octubre de 2024
|
21 de enero de 2027
|
v20.0
|
21 de mayo de 2024
|
24 de septiembre de 2026
|
v19.0
|
23 de enero de 2024
|
21 de mayo de 2026
|
18.0
|
12 de septiembre de 2023
|
26 de enero de 2023
|
17.0
|
23 de mayo de 2023
|
12 de septiembre de 2025
|
16.0
|
2 de febrero de 2023
|
14 de mayo de 2025
|
15.0
|
15 de septiembre de 2022
|
20 de noviembre de 2024
|
14.0
|
25 de mayo de 2022
|
17 de septiembre de 2024
|
13.0
|
8 de febrero de 2022
|
28 de mayo de 2024
|
12.0
|
14 de septiembre de 2021
|
8 de febrero de 2024
|
11.0
|
8 de junio de 2021
|
14 de septiembre de 2023
|
10.0
|
23 de febrero de 2021
|
8 de junio de 2023
|
9.0
|
10 de noviembre de 2020
|
23 de febrero de 2023
|
8.0
|
4 de agosto de 2020
|
1 de noviembre de 2022
|
7.0
|
5 de mayo de 2020
|
4 de agosto de 2022
|
6.0
|
3 de febrero de 2020
|
5 de mayo de 2022
|
5.0
|
29 de octubre de 2019
|
3 de febrero de 2022
|
4.0
|
29 de julio de 2019
|
2 de noviembre de 2021
|
3.3
|
30 de abril de 2019
|
3 de agosto de 2021
|
3.2
|
23 de octubre de 2018
|
4 de mayo de 2021
|
3.1
|
26 de julio de 2018
|
27 de octubre de 2020
|
3.0
|
1 de mayo de 2018
|
28 de julio de 2020
|
2.12
|
30 de enero de 2018
|
5 de mayo de 2020
|
2.11
|
7 de noviembre de 2017
|
28 de enero de 2020
|
2.10
|
18 de julio de 2017
|
7 de noviembre de 2019
|
2.9
|
18 de abril de 2017
|
22 de julio de 2019
|
2.8
|
5 de octubre de 2016
|
18 de abril de 2019
|
2.7
|
13 de julio de 2016
|
5 de octubre de 2018
|
2.6
|
12 de abril de 2016
|
13 de julio de 2018
|
2.5
|
7 de octubre de 2015
|
12 de abril de 2018
|
2.4
|
8 de julio de 2015
|
9 de octubre de 2017
|
2.3
|
25 de marzo de 2015
|
10 de julio de 2017
|
2.2
|
30 de octubre de 2014
|
27 de marzo de 2017
|
2.1
|
7 de agosto de 2014
|
31 de octubre de 2016
|
2.0
|
30 de abril de 2014
|
8 de agosto de 2016
|
Versión 1.0
|
21 de abril de 2010
|
30 de abril de 2015
|
## API de marketing
La función de actualización automática de la versión de la API de marketing se lanzará el 29 de julio de 2026.
Version
|
Release Date
|
Expiration Date
|
v25.0
|
February 18, 2026
|
TBD
|
v24.0
|
October 8, 2025
|
October 6, 2026
|
v23.0
|
May 29, 2025
|
June 9, 2026
|
v22.0
|
January 21, 2025
|
February 19, 2026
|
v21.0
|
October 2, 2024
|
September 9, 2025
|
v20.0
|
May 21, 2024
|
May 6, 2025
|
v19.0
|
January 23, 2024
|
February 4, 2025
|
v18.0
|
September 12, 2023
|
August 13, 2024
|
v17.0
|
May 23, 2023
|
May 14, 2024
|
v16.0
|
February 2, 2023
|
February 6, 2024
|
v15.0
|
September 15, 2022
|
September 20, 2023
|
v14.0
|
May 25, 2022
|
September 20, 2023
|
v13.0
|
February 8, 2022
|
January 25, 2023
|
v12.0
|
September 14, 2021
|
August 9, 2022
|
v11.0
|
June 8, 2021
|
February 23, 2022
|
v10.0
|
February 23, 2021
|
October 4, 2021
|
v9.0
|
November 10, 2020
|
August 25, 2021
|
v8.0
|
August 4, 2020
|
May 4, 2021
|
v7.0
|
May 5, 2020
|
March 3, 2021
|
v6.0
|
February 3, 2020
|
Extended to February 8, 2021
|
v5.0
|
October 29, 2019
|
September 28, 2020
|
v4.0
|
July 29, 2019
|
March 31, 2020
|
v3.3
|
April 30, 2019
|
January 13, 2020
|
v3.2
|
October 23, 2018
|
August 13, 2019
|
v3.1
|
July 26, 2018
|
May 14, 2019
|
v3.0
|
May 1, 2018
|
February 1, 2019
|
v2.12
|
January 30, 2018
|
August 7, 2018
|
v2.11
|
November 7, 2017
|
August 7, 2018
|
v2.10
|
July 18, 2017
|
May 8, 2018
|
v2.9
|
April 18, 2017
|
November 6, 2017
|
v2.8
|
October 5, 2016
|
July 26, 2017
|
v2.7
|
July 13, 2016
|
April 25, 2017
|
v2.6
|
April 12, 2016
|
October 5, 2016
|
v2.5
|
October 7, 2015
|
July 13, 2016
|
v2.4
|
July 8, 2015
|
April 11, 2016
|
v2.3
|
March 25, 2015
|
October 8, 2015
|
v2.2
|
October 30, 2014
|
July 8, 2015
|
v2.1
|
October 1, 2014
|
March 11, 2015
|
v2.0
|
October 1, 2014
|
March 11, 2015
|
v1.0
|
October 1, 2014
|
March 11, 2015
|
