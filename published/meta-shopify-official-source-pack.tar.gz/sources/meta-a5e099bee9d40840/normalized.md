# Page-Owned Product Catalog API
**Warning:** **Note**: This API currently has limited functionality. Meta is releasing it incrementally and limits access to it.
This document explains how to create a catalog for a Facebook Page using the Page-Owned Product Catalog API.
## Before you start
Before you start, you need the following:
* A valid Facebook **Page ID** (passed in the URL).
* A valid user access token with permissions to manage catalogs and Pages.
* (*Optional*) Meta&#039;s business ID managing the page you want to link to the catalog.
* (*Optional*) External business ID/installation ID of third-party partner.
* (*Optional*) Agency&#039;s information to share catalog with the agency business.
## API use cases
**When a page ID exists without a corresponding business ID**: By making a call without a `business_id`, the API creates a catalog for the page passed in the URL.
**When a business ID exists**: By passing the `business_id` as a parameter, the API creates a catalog and associates the catalog with the business and the page passed in the URL.
**When you want to provide partial access to an agency business**: By providing both the `business_id` and `business_metadata` as parameters, the API creates a catalog, links the catalog to the specified business and page from the URL, and shares the catalog with the agency `business_id` included in the `business_metadata`.
## Limitations
Only the **commerce** vertical is supported. Any other value for `vertical` will result in API failure.
If the `agency` param is provided in `business_metadata`, both `business_id` and `permitted_tasks` inside the `agency` field are required.
## Create a product catalog for a Page
To create a product catalog, send a `POST` request to the `/pages/&#123;page_id&#125;/owned_product_catalogs` endpoint.
Include the following fields in your request body:
| Field | Description |
| --- | --- |
| `name` | **Required**&lt;br&gt;The name of the catalog. |
| `vertical` | **Optional**&lt;br&gt;The vertical type. Defaults to `commerce` if not provided. |
| `business_id` | **Optional**&lt;br&gt;The Facebook business ID to link the catalog. |
| `business_metadata` | **Optional**&lt;br&gt;Additional metadata consisting of external business ID and agency information. |
Optional fields inside `business_metadata`:
| Field | Description |
| --- | --- |
| `external_business_id` | **Optional**&lt;br&gt;Partner&#039;s business ID for which the catalog is created. |
| `agency` | **Optional**&lt;br&gt;If provided, must include both `business_id` (agency&#039;s Facebook business ID) and `permitted_tasks` (for example, 240588526848665 to manage or 2015469438531460 to advertise). |
In your API call you must include the access token which has permission for **catalog management** and **page metadata management**.
When testing an API call, you can include the `access_token` parameter set to your access token. However, when making secure calls from your app, use the [access token class.](https://developers.facebook.com/documentation/facebook-login/guides/access-tokens#portabletokens)
Example request:
```bash
curl -X POST &quot;https://ads-api.facebook.com/&lt;PAGE_ID&gt;/owned_product_catalogs \
-H &quot;Content-Type: application/json&quot; \
-H &quot;Authorization: Bearer &lt;ACCESS_TOKEN&gt;&quot; \
-d &#039;&#123;
&quot;name&quot;:&quot;My catalog&quot;,
&quot;vertical&quot;:&quot;commerce&quot;,
&quot;business_id&quot;:&quot;&lt;META_BUSINESS_ID&gt;&quot;,
&quot;business_metadata&quot;:&#123;
&quot;external_business_id&quot;: &quot;&lt;PARTNER_EXTERNAL_ID&gt;&quot;,
&quot;agency&quot;: &#123;
&quot;business_id&quot;: &quot;&lt;AGENCY_META_BUSINESS_ID&gt;&quot;,
&quot;permitted_tasks&quot;: [&quot;240588526848665&quot;],
&#125;
&#125;
&#125;
```
On success, your app receives the following JSON response with the ID for the created catalog:
```json
&#123; &quot;id&quot;: &quot;CATALOG_ID&quot;&#125;
```
## See also
To learn more about the components and concepts mentioned in this guide, refer to the following guides:
* [Catalog](https://developers.facebook.com/documentation/ads-commerce/catalog)
* [Business Owned Product Catalogs API](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/business/owned_product_catalogs)
* [Access Tokens Guide](https://developers.facebook.com/documentation/facebook-login/guides/access-tokens#portabletokens)
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
