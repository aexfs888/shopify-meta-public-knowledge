# Payload Helper
Fill out the required and recommended data parameter fields to see how your payload should be structured when it&#039;s sent to Facebook from your server.
**Note:** Web, app, and physical store events shared using the Conversions API require specific parameters. The list of [required parameters is available here](https://developers.facebook.com/documentation/ads-commerce/conversions-api/parameters).
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
