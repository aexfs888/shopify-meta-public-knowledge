# Business Owned Product Catalogs
## Reading
Product catalogs owned by this business.
#### Example
### HTTP
```
GET /v25.0/&#123;business-id&#125;/owned_product_catalogs HTTP/1.1
Host: graph.facebook.com
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;get(
&#039;/&#123;business-id&#125;/owned_product_catalogs&#039;,
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;/&#123;business-id&#125;/owned_product_catalogs&quot;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;/&#123;business-id&#125;/owned_product_catalogs&quot;,
null,
HttpMethod.GET,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;/&#123;business-id&#125;/owned_product_catalogs&quot;
parameters:params
HTTPMethod:&#064;&quot;GET&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=GET&amp;path=%7Bbusiness-id%7D%2Fowned_product_catalogs&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
This endpoint doesn&#039;t have any parameters.
#### Fields
Reading from this edge will return a JSON formatted result:
```
&#123;
&quot;data&quot;: [],
&quot;paging&quot;: &#123;&#125;,
&quot;summary&quot;: &#123;&#125;
&#125;
```
##### data
A list of [ProductCatalog](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/product-catalog) nodes.
##### paging
For more details about pagination, see the [Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api#paging).
##### summary
Aggregated information about the edge, such as counts. Specify the fields to fetch in the summary param (like summary=__type__).
| Field | Description |
| --- | --- |
#### Error Codes
| Error Code | Description |
| --- | --- |
| 200 | Permissions error |
| 100 | Invalid parameter |
| 80009 | There have been too many calls to this Catalog account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting. |
| 190 | Invalid OAuth 2.0 Access Token |
| 104 | Incorrect signature |
## Creating
### /&#123;business_id&#125;/owned_product_catalogs
You can make a POST request to *owned_product_catalogs* edge from the following paths:
- [/&#123;business_id&#125;/owned_product_catalogs](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/business/owned_product_catalogs)
When posting to this edge, a [ProductCatalog](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/product-catalog) will be created.
#### Parameters
| Parameter | Description |
| --- | --- |
| `additional_vertical_option`&lt;br&gt;&lt;br&gt;*enum &#123;LOCAL_DA_CATALOG, LOCAL_PRODUCTS&#125;* | Additional catalog configurations that does not introduce either new verticals or subverticals&lt;br&gt; |
| `business_metadata`&lt;br&gt;&lt;br&gt;*JSON object* | business_metadata&lt;br&gt;&lt;br&gt;&lt;br&gt;`page_id` *numeric string*&lt;br&gt;page_id&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`external_business_id` *string*&lt;br&gt;external_business_id&lt;br&gt; |
| `catalog_segment_filter`&lt;br&gt;&lt;br&gt;*A JSON-encoded rule* | Provide filter for catalog to create a catalog segment.&lt;br&gt; |
| `da_display_settings`&lt;br&gt;&lt;br&gt;*Object* | Dynamic Ads display settings.&lt;br&gt;&lt;br&gt;&lt;br&gt;`carousel_ad` *Object*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`transformation_type` *enum&#123;background_cropping_and_padding, background_padding, none&#125;*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`single_ad` *Object*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`transformation_type` *enum&#123;background_cropping_and_padding, background_padding, none&#125;*&lt;br&gt;**[required]**&lt;br&gt; |
| `destination_catalog_settings`&lt;br&gt;&lt;br&gt;*JSON object* | Destination catalog settings.&lt;br&gt;&lt;br&gt;&lt;br&gt;`generate_items_from_pages` *boolean*&lt;br&gt;&lt;br&gt;**Default value: **`false` |
| `flight_catalog_settings`&lt;br&gt;&lt;br&gt;*JSON object* | Flight catalog settings.&lt;br&gt;&lt;br&gt;&lt;br&gt;`generate_items_from_events` *boolean*&lt;br&gt;&lt;br&gt;**Default value: **`false` |
| `name`&lt;br&gt;&lt;br&gt;*UTF-8 encoded string* | Name of the catalog.&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `parent_catalog_id`&lt;br&gt;&lt;br&gt;*numeric string or integer* | Parent catalog ID.&lt;br&gt; |
| `partner_integration`&lt;br&gt;&lt;br&gt;*JSON object* | Partner integration settings&lt;br&gt;&lt;br&gt;&lt;br&gt;`external_access_token` *string*&lt;br&gt;External access token&lt;br&gt;&lt;br&gt;&lt;br&gt;`external_merchant_id` *string*&lt;br&gt;External merchant identifier&lt;br&gt; |
| `store_catalog_settings`&lt;br&gt;&lt;br&gt;*JSON object* | Store catalog settings.&lt;br&gt;&lt;br&gt;&lt;br&gt;`page_id` *numeric string*&lt;br&gt;page_id&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `vertical`&lt;br&gt;&lt;br&gt;*enum &#123;adoptable_pets, apps_and_software, articles_and_publications, commerce, destinations, flights, generic, home_listings, hotels, local_service_businesses, media_titles, offer_items, services, offline_commerce, transactable_items, vehicles&#125;* | **Default value: **`commerce`&lt;br&gt;The catalog&#039;s industry or vertical, such as `commerce`.&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *id* in the return type.
```
Struct &#123;
id: numeric string,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 190 | Invalid OAuth 2.0 Access Token |
| 804 | Specified object already exists |
| 102 | Session key invalid or no longer valid |
| 200 | Permissions error |
| 2310019 | The business of this catalog is not onboarded to Collaborative Ads |
## Updating
You can&#039;t perform this operation on this endpoint.
## Deleting
You can&#039;t perform this operation on this endpoint.
