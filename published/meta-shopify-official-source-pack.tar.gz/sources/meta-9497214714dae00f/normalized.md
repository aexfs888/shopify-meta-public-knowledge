Changelog - Graph API - Documentation - Meta for Developers
-
Graph API
Overview
- Get Started
- Batch Requests
- Debug Requests
- Handle Errors
- Field Expansion
- Secure Requests
- Changelog
- Reference
# Version 26.0
# Changelog
The latest Graph API version is:
| v26.0 |
The Graph API and Marketing API changelogs document versioned and out-of-cycle changes, respective to the API.
### Related Changelogs
-
Instagram Platform Changelog
-
Marketing API Changelog
-
Messenger Platform Changelog
(includes Instagram Messaging)
-
WhatsApp Business Platform Changelog
### Versioned Changes
Versioned changes are changes introduced with the release of a new API version . Versioned changes typically apply to the newest version immediately and often will apply to other versions at a future date. The changelog accompanying each release indicates which changes apply to the current release and which changes apply to other versions.
Refer to our Upgrade Guide to learn how to upgrade to a new API version.
### Out-Of-Cycle Changes
Out-of-cycle changes are changes introduced outside of our normal, versioned release schedule and typically do not apply to a specific version. Instead, out-of-cycle changes usually apply to all API versions immediately. Because of this, out-of-cycle changes are introduced infrequently.
## Available Graph API Versions
Version
|
Date Introduced
|
Available Until
|
v26.0
|
July 29, 2026
|
TBD
|
v25.0
|
February 18, 2026
|
July 29, 2028
|
v24.0
|
October 8, 2025
|
February 18, 2028
|
v23.0
|
May 29, 2025
|
October 8, 2027
|
v22.0
|
January 21, 2025
|
May 20, 2027
|
v21.0
|
October 2, 2024
|
January 21, 2027
|
v20.0
|
May 21, 2024
|
September 24, 2026
|
v19.0
|
January 23, 2024
|
May 21, 2026
|
v18.0
|
September 12, 2023
|
January 26, 2026
|
v17.0
|
May 23, 2023
|
September 12, 2025
|
v16.0
|
February 2, 2023
|
May 14, 2025
|
v15.0
|
September 15, 2022
|
November 20, 2024
|
v14.0
|
May 25, 2022
|
September 17, 2024
|
v13.0
|
February 8, 2022
|
May 28, 2024
|
## Available Marketing API Versions
Marketing API version auto-upgrade will be released on July 29, 2026.
Version
|
Date Introduced
|
Available Until
|
v26.0
|
July 29, 2026
|
TBD
|
v25.0
|
February 18, 2026
|
TBD
|
v24.0
|
October 8, 2025
|
October 6, 2026
|
## Out-Of-Cycle Changes
- 2025 out-of-cycle changes
