Registro de cambios - API Graph - Documentación - Meta for Developers
-
API Graph
Información general
- Primeros pasos
- Solicitudes por lotes
- Solicitudes de depuración
- Administrar errores
- Field Expansion
- Secure Requests
- Registro de cambios
- Reference
# Versión 26.0
# Registro de cambios
La versión más reciente de la API Graph es:
| v26.0 |
En los registros de cambios de la API Graph y la API de marketing se documentan los cambios con versión y sin versión relacionados con la API.
### Registros de cambios relacionados
-
Registro de cambios de la plataforma de Instagram
-
Registro de cambios de la API de marketing
-
Registro de cambios de la plataforma de Messenger (incluye mensajes de Instagram)
-
Registro de cambios de la Plataforma de WhatsApp Business
### Cambios con versión
Los cambios con versión son cambios que se producen con el lanzamiento de una nueva versión de la API. Generalmente, los cambios con versión se aplican a la versión más reciente de inmediato y, a menudo, se aplican a otras versiones en una fecha futura. El registro de cambios que se incluye con cada lanzamiento indica qué cambios corresponden al lanzamiento actual y cuáles, a otras versiones.
Consulta nuestra Guía de actualizaciones para aprender a actualizar a una nueva versión de la API.
### Cambios fuera de ciclo
Los cambios sin versión son cambios que se producen fuera de nuestro cronograma normal de lanzamientos de versiones y, por lo general, no se aplican a una versión específica. Los cambios sin versión se suelen aplicar a todas las versiones de la API de inmediato. Por esta razón, es poco frecuente que se produzcan cambios sin versión.
## Versiones disponibles de la API Graph
Versión
|
Fecha de introducción
|
Disponible hasta
|
v26.0
|
29 de julio de 2026
|
Por determinar
|
v25.0
|
18 de febrero de 2026
|
29 de julio de 2028
|
v24.0
|
8 de octubre de 2025
|
18 de febrero de 2028
|
v23.0
|
29 de mayo de 2025
|
8 de octubre de 2027
|
v22.0
|
21 de enero de 2025
|
20 de mayo de 2027
|
v21.0
|
2 de octubre de 2024
|
21 de enero de 2027
|
v20.0
|
21 de mayo de 2024
|
24 de septiembre de 2026
|
v19.0
|
23 de enero de 2024
|
21 de mayo de 2026
|
18.0
|
12 de septiembre de 2023
|
26 de enero de 2023
|
17.0
|
23 de mayo de 2023
|
12 de septiembre de 2025
|
16.0
|
2 de febrero de 2023
|
14 de mayo de 2025
|
15.0
|
15 de septiembre de 2022
|
20 de noviembre de 2024
|
14.0
|
25 de mayo de 2022
|
17 de septiembre de 2024
|
13.0
|
8 de febrero de 2022
|
28 de mayo de 2024
|
## Versiones disponibles de la API de marketing
La función de actualización automática de la versión de la API de marketing se lanzará el 29 de julio de 2026.
Version
|
Date Introduced
|
Available Until
|
v26.0
|
July 29, 2026
|
TBD
|
v25.0
|
February 18, 2026
|
TBD
|
v24.0
|
October 8, 2025
|
October 6, 2026
|
## Cambios fuera de ciclo
-
Cambios fuera de ciclo de 2025
