# Changelog
The latest Graph API version is:
[v27.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version27.0)
The Graph API and Marketing API changelogs document [versioned](#versioned) and [out-of-cycle](#outofcycle) changes, respective to the API.
### Related Changelogs
- [Instagram Platform Changelog](https://developers.facebook.com/documentation/instagram-platform/changelog)
- [Marketing API Changelog](https://developers.facebook.com/documentation/ads-commerce/marketing-api/marketing-api-changelog)
- [Messenger Platform Changelog](https://developers.facebook.com/documentation/business-messaging/messenger-platform/changelog) (includes Instagram Messaging)
- [WhatsApp Business Platform Changelog](https://developers.facebook.com/documentation/business-messaging/whatsapp/changelog)
### Versioned Changes &#123;#versioned&#125;
Versioned changes are changes introduced with the release of a new API [version](https://developers.facebook.com/docs/apps/versions). Versioned changes typically apply to the newest version immediately and often will apply to other versions at a future date. The changelog accompanying each release indicates which changes apply to the current release and which changes apply to other versions.
Refer to our [Upgrade Guide](https://developers.facebook.com/docs/apps/upgrading) to learn how to upgrade to a new API version.
### Out-Of-Cycle Changes &#123;#outofcycle&#125;
Out-of-cycle changes are changes introduced outside of our normal, versioned release schedule and typically do not apply to a specific version. Instead, out-of-cycle changes usually apply to all API versions immediately. Because of this, out-of-cycle changes are introduced infrequently.
## Available Graph API Versions
| Version | Date Introduced | Available Until |
| --- | --- | --- |
| [v27.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version27.0) | November 4, 2026 | TBD |
| [v26.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version26.0) | July 29, 2026 | TBD |
| [v25.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version25.0) | February 18, 2026 | July 29, 2028 |
| [v24.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version24.0) | October 8, 2025 | February 18, 2028 |
| [v23.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version23.0) | May 29, 2025 | October 8, 2027 |
| [v22.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version22.0) | January 21, 2025 | May 20, 2027 |
| [v21.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version21.0) | October 2, 2024 | January 21, 2027 |
| [v20.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version20.0#graph-api) | May 21, 2024 | September 24, 2026 |
| [v19.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version19.0#graph-api) | January 23, 2024 | May 21, 2026 |
| [v18.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version18.0#graph-api) | September 12, 2023 | January 26, 2026 |
| [v17.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version17.0#graph-api) | May 23, 2023 | September 12, 2025 |
| [v16.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version16.0#graph-api) | February 2, 2023 | May 14, 2025 |
| [v15.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version15.0#graph-api) | September 15, 2022 | November 20, 2024 |
| [v14.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version14.0#graph-api) | May 25, 2022 | September 17, 2024 |
| [v13.0](https://developers.facebook.com/documentation/development/graph-api/changelog/version13.0#graph-api) | February 8, 2022 | May 28, 2024 |
## Available Marketing API Versions
**Warning:** Marketing API [version auto-upgrade](https://developers.facebook.com/documentation/ads-commerce/marketing-api/overview/versioning#version-auto-upgrade) will be released on July 29, 2026.
| Version | Date Introduced | Available Until |
| --- | --- | --- |
| [v27.0](https://developers.facebook.com/documentation/ads-commerce/marketing-api/marketing-api-changelog/version27.0) | November 4, 2026 | TBD |
| [v26.0](https://developers.facebook.com/docs/marketing-api/marketing-api-changelog/version26.0) | July 29, 2026 | TBD |
| [v25.0](https://developers.facebook.com/documentation/ads-commerce/marketing-api/marketing-api-changelog/version25.0) | February 18, 2026 | TBD |
| [v24.0](https://developers.facebook.com/documentation/ads-commerce/marketing-api/marketing-api-changelog/version24.0) | October 8, 2025 | October 6, 2026 |
## Out-Of-Cycle Changes
* [2025 out-of-cycle changes](https://developers.facebook.com/docs/graph-api/changelog/non-versioned-changes/nvc-2025)
---
Full documentation index for this product: https://developers.facebook.com/documentation/development/llms.txt
