-
Set up the Meta Pixel and Meta Conversions API for ad campaigns : Learn new skills to build your brand or business
Skip to main content
This site uses cookies to provide you with a greater user experience. By using Exceed LMS, you accept our use of cookies .
Search
Topics
##
All Topics
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
Log In
Learn how to use the Meta Pixel and the Conversions API together to gain insight into customer actions on your website and optimize your advertising strategy.
-
### Get started with the Meta Pixel and Meta Conversions API
5 m
-
### Connect your data with the Meta Pixel and Meta Conversions API
5 m
##
All Topics
-
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
##
Review
##
Warning: Closing this page may affect activity tracking!
This page is used by your activity to communicate with the learning platform. Please be sure to close all activity windows before closing or navigating away from this page.
Return to activity
Did you arrive on this page without seeing a new activity window launch? You may have a pop-up blocker. Check out pop-up blocker tips here.
