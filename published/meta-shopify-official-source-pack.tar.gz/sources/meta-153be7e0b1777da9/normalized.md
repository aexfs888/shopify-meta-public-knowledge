-
Meta Ads Manager learning : Learn new skills to build your brand or business
Skip to main content
This site uses cookies to provide you with a greater user experience. By using Exceed LMS, you accept our use of cookies .
Search
Topics
##
All Topics
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
Log In
Meta Ads Manager is your starting point for running ads on Facebook, Instagram and Messenger. Learn how to select a campaign objective that meets your business goals and how to create, manage and track ad campaigns in Ads Manager.
Take the test below to earn a Meta Small Business Academy skilling certificate for Ads Manager and demonstrate your expertise online.
Note: Although you’re encouraged to explore the courses in this learning path first, course completion is not required to begin the test.
See all topics
-
###
Introduction to campaign objectives
Learn how to define business goals, select the correct ad objective and measure success in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Intermediate
-
###
Create audiences in Meta Ads Manager
Learn about the different types of audiences available for ads and how to create them for campaigns in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Intermediate
-
###
Choose ad placements, budget and schedule in Meta Ads Manager
Learn how to choose placements and set a budget and schedule for ad campaigns in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Beginner
-
###
Customize ad creative in Meta Ads Manager
Learn how to create ads and review format, placement and creative options in Meta Ads Manager.
Duration
20m
-
Rating 4.8
- Intermediate
-
###
Analyze your ad campaign results in Meta Ads Manager
Learn where to find key metrics in Ads Manager and how to use them to analyze campaign results.
Duration
10m
-
Rating 4.8
- Intermediate
-
###
Understanding Meta Advertising Standards
Learn how to comply with Meta Advertising Standards to effectively place ads with Meta.
Duration
15m
-
Rating 4.8
- Beginner
-
###
Meta Small Business Academy Meta Ads Manager learning skill test
Test your knowledge to earn a Meta Small Business Academy skilling certificate for Meta Ads Manager.
Rating 5.0
##
All Topics
-
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
##
Review
##
Warning: Closing this page may affect activity tracking!
This page is used by your activity to communicate with the learning platform. Please be sure to close all activity windows before closing or navigating away from this page.
Return to activity
Did you arrive on this page without seeing a new activity window launch? You may have a pop-up blocker. Check out pop-up blocker tips here.
