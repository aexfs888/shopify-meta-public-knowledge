- Shopify Help Center | Facebook and Instagram by Meta
Help
Log in
### Service disruptions at Shopify
Admin, Checkout and API & Mobile are experiencing issues.
For more details, check the Shopify Status page.
Contents
# Facebook and Instagram by Meta
Facebook and Instagram by Meta
Install the Facebook & Instagram sales channel from the Shopify App Store.
You can use Facebook and Instagram by Meta to sync your products to a catalog on Facebook and Instagram, so that you can sell on Facebook Shop and Instagram Shopping. The Facebook and Instagram by Meta sales channel is free to use with all Shopify plans, subject to store eligibility.
To learn about marketing on Facebook, including Facebook ads, refer to Marketing on Facebook .
If you use Campaign Autopilot , then Autopilot can recommend Advantage+ campaigns that are separate from ads you create through Facebook and Instagram by Meta. Learn how catalog sync, billing, and approvals work in Meta ads with Autopilot .
For more information about integrating your Shopify store with Meta, refer to the following resources from Meta Business Help Center:
Resources for Your Shopify Integration
- How to Connect Shopify with Facebook
You can use the following three features to help you grow your business with the Facebook and Instagram by Meta sales channel:
- Use Facebook Shop to sell on your business's Facebook Page .
- Use Instagram Shopping to sell on your business's Instagram profile .
- Use Meta Marketing for the following tasks:
Create a Meta pixel using Facebook and Instagram by Meta
- Add a Meta pixel to Facebook and Instagram by Meta
- Choose Facebook's customer data-sharing level
- Learn about tracking customers using the Facebook Conversions API
### In this section
-
Requirements and considerations for using Facebook and Instagram by Meta
-
Setting up Facebook and Instagram by Meta
-
Instagram Shopping
-
Facebook Shop
-
Publishing products on Facebook and Instagram by Meta
-
Providing Google Product Categories
Leave feedback
