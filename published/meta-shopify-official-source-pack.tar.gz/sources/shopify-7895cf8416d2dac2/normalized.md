- Shopify Help Center | Pixels overview
Help
Log in
Contents
# Pixels overview
You can use the Shopify pixels manager to manage and add pixels that track customer events. Customer events are actions that take place in the customer's browser, for example, clicking a link or adding a product to a cart. You can add and manage pixels in the Customer events section of your Shopify admin.
Previously, merchants could manually add JavaScript snippets in several places in their online store: in online preferences, in checkout scripts, and in apps. These scripts weren't usually quality controlled, and were time-consuming to manage. With the pixel manager, your scripts are stored in a single management tool and run in a sandbox environment . Adding app pixels or custom pixels to your store can provide the following benefits:
Access to a stream of customer events on your online store, including checkout events.
- An additional layer of security for your online store and your customers, including greater control over the customer data that you share with third-party services.
- Prevention of third-party code running non-performing Javascript, or interfering with your online store and checkout.
- Built-in tools for privacy compliance.
Pixels can be added to your online store in 2 ways: through app pixels , which are installed through marketing and data collection apps, and custom pixels , which can be manually added by a developer in the pixels manager of your Shopify admin.
Pixels automatically load on the Storefront, Checkout, Thank you page, and Order status page. On customer account pages, pixels load only after you connect a custom subdomain for customer accounts , and they track only the page_viewed customer event on those pages.
## On this page
- Sandbox environment for pixels
- Pixel tracking capabilities
- Customer privacy
- Potential risks
## Sandbox environment for pixels
Shopify uses a secure sandbox for app pixels and custom pixels. A sandbox is an isolated environment that allows you to run scripts without affecting the rest of your online store. A sandboxed pixel has the freedom to run anywhere on your website, but is restricted to the data made available within the sandbox. This sandbox ensures that any pixels installed or created in the pixels manager can't collect or retrieve data outside the stated intent of the pixel, which could be a security risk.
Learn more about the potential risks associated with pixels .
### Limitations of the pixels sandbox
There are some limitations on what information can be accessed, because pixels run in a secure sandbox environment. The increased security gives you and your customers greater control over what data third parties have access to. These limitations might not be compatible with some third-party pixels. Consult the third-party pixel provider to confirm which pixels are compatible.
Review the following known limitations of the pixels sandboxes:
- Pixels sandboxes can't render user interface elements, such as buttons, forms, banners, or modals.
- Pixels sandboxes can't automatically detect the following information:
Events from DOM (Document Object Model) scraping.
- Metadata from DOM scraping.
- User information, such as email and phone, from DOM scraping.
- Outbound link clicks from DOM scraping.
- Page scrolling.
- Clicks and mouse movement to create heatmaps from DOM scraping.
Automatic detection of page URLs in the Lax sandbox include a sandbox version and not exactly reflect the main window’s URL. You can get the main window’s URL from the page_viewed event.
For automatic detection of events, metadata, user information, and outbound links from DOM scraping, you can publish custom events as an alternative. Publishing custom events might not be supported by all app pixels.
## Pixel tracking capabilities
The following describes what you can generally expect to track for each pixel type:
- Conversion and marketing pixels : Standard checkout events and customer actions work for most conversion tracking. Features that automatically scrape forms for email addresses or phone numbers might not work in the sandbox. Most pixel providers support passing this data manually instead.
- Analytics pixels : Standard customer events such as page views, product views, cart updates, purchases, and searches all work. You can also track custom events using the Shopify.analytics.publish() method. Tracking form interactions and link clicks requires publishing them as custom events.
- Google Tag Manager : You can run Google Tag Manager as a custom pixel. However, pixels that Google Tag Manager loads still run within the Shopify sandbox, so the same tracking capabilities and limitations apply. Learn more about using Google Tag Manager as a custom pixel .
## Customer privacy
In markets configured to require consent (usually the European Economic Area (EEA) and the United Kingdom), web pixels run only when visitors have provided the permissions required in the pixel configuration. By default, new pixels require Marketing and Analytics permissions.
Similarly, pixels configured as data sale won't run for customers that have opted out of data sales or sharing, unless the pixel supports limited data use.
Developers of custom pixels can learn more about collecting and registering consent .
## Potential risks
Always ensure you understand the code that you add to your online store or store checkout, or hire a Shopify Partner for help with custom pixels.
### Performance risks
Pixels are scripts that run in the background of your online store to track customer events. The more scripts you have, the slower your store will run. Additionally, if the script added is broken or formatted incorrectly, then the activity could run indefinitely, which can cause your site to load slowly or fail to load.
### Privacy risks
User privacy is heavily regulated to ensure customer information is protected online. Code snippets can be used to bypass customer consent requirements, which violates the Shopify Terms of Service and can lead to legal liability for you. This is especially true if you live in or serve customers in locations with stricter privacy regulations, such as some US states or the European Economic Area. Remember that you are responsible for complying with applicable laws and getting all necessary consents when you use pixels to collect customer data. Speak with a lawyer if you are unsure about the requirements that apply to you.
Leave feedback
