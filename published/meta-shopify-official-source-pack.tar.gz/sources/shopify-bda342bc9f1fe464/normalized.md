---
title: analytics
description: Provides access to Shopify's customer event API
source_url:
html: 'https://shopify.dev/docs/api/web-pixels-api/standard-api/analytics'
md: 'https://shopify.dev/docs/api/web-pixels-api/standard-api/analytics.md'
api_name: web-pixels
---
# analytics
Provides access to Shopify's [customer event API](https://shopify.dev/docs/api/web-pixels-api/standard-events)
#### Properties
* **subscribe**
**(eventName: string, event\_callback: Function) => Promise\<undefined>**
Examples
### Examples
* #### Accessing Standard Api
##### App Pixel
```js
import {register} from '@shopify/web-pixels-extension';
register(({analytics, browser, settings, init}) => {
analytics.subscribe('page_viewed', (event) => {
// subscribe to page_viewed events
});
analytics.subscribe('all_events', (event) => {
// subscribe to all events
});
analytics.subscribe('all_standard_events', (event) => {
// subscribe to all standard events
});
analytics.subscribe('all_custom_events', (event) => {
// subscribe to all custom events
});
});
```
##### Custom Pixel
```js
analytics.subscribe('page_viewed', (event) => {
// subscribe to page_viewed events
});
analytics.subscribe('all_events', (event) => {
// subscribe to all events
});
analytics.subscribe('all_standard_events', (event) => {
// subscribe to all standard events
});
analytics.subscribe('all_custom_events', (event) => {
// subscribe to all custom events
});
```
***
