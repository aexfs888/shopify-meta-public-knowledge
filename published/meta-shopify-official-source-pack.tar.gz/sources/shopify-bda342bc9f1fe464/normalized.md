- analytics Skip to main content
Provides access to Shopify's customer event API
####
Anchor to properties Properties
Anchor to subscribe
subscribe subscribe
(eventName: string, event_callback: Function) => Promise<undefined> (eventName: string, event_callback: Function) => Promise<undefined>
Examples
Accessing Standard Api
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
import { register } from '@shopify/web-pixels-extension' ;
register ( ( { analytics , browser , settings , init } ) => {
analytics . subscribe ( 'page_viewed' , ( event ) => {
// subscribe to page_viewed events
} ) ;
analytics . subscribe ( 'all_events' , ( event ) => {
// subscribe to all events
} ) ;
analytics . subscribe ( 'all_standard_events' , ( event ) => {
// subscribe to all standard events
} ) ;
analytics . subscribe ( 'all_custom_events' , ( event ) => {
// subscribe to all custom events
} ) ;
} ) ;
### Examples
#### Accessing Standard Api
#### App Pixel
import {register} from '@shopify/web-pixels-extension';
register(({analytics, browser, settings, init}) => {
analytics.subscribe('page_viewed', (event) => {
// subscribe to page_viewed events
});
analytics.subscribe('all_events', (event) => {
// subscribe to all events
});
analytics.subscribe('all_standard_events', (event) => {
// subscribe to all standard events
});
analytics.subscribe('all_custom_events', (event) => {
// subscribe to all custom events
});
});
#### Custom Pixel
analytics.subscribe('page_viewed', (event) => {
// subscribe to page_viewed events
});
analytics.subscribe('all_events', (event) => {
// subscribe to all events
});
analytics.subscribe('all_standard_events', (event) => {
// subscribe to all standard events
});
analytics.subscribe('all_custom_events', (event) => {
// subscribe to all custom events
});
Was this page helpful?
Yes No
