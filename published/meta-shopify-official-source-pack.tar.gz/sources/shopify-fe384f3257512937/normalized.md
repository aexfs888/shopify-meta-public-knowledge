Advanced DOM Pixel Events API Skip to main content
##
Anchor to For apps providing session recording and/or heatmaps For apps providing session recording and/or heatmaps
The Advanced DOM Events API provides events that replicate the DOM, changes to the DOM and user interactions. It can be used to recreate user journeys and interactions for session recording and/or heatmaps. The API provides these events across the Storefront, Checkout, Thank you page and Customer Accounts pages.
Shopify Plus
These events are limited on checkout to stores on the Shopify Plus plan.
Shopify Plus:
These events are limited on checkout to stores on the Shopify Plus plan.
Access required
Requires access to the Advanced DOM Events in web pixel app extensions scope. To request access, please use the form in the Partner Dashboard. This scope is only available for apps that have a heatmap and/or session recordings. The Advanced DOM Events cannot be used on custom apps.
Access required:
Requires access to the Advanced DOM Events in web pixel app extensions scope. To request access, please use the form in the Partner Dashboard. This scope is only available for apps that have a heatmap and/or session recordings. The Advanced DOM Events cannot be used on custom apps.
##
Anchor to Events Events
advanced _dom _available
The advanced_dom_available event is published when the DOM has been loaded and is available for interaction.
advanced _dom _changed
The advanced_dom_changed event is published when the DOM has been changed in any way, such as an element being added, removed, or modified.
advanced _dom _clicked
The advanced_dom_clicked event is published when a customer clicks on a page element.
advanced _dom _clipboard
The advanced_dom_clipboard event is published when a customer has cut, copied or pasted text to or from the clipboard.
advanced _dom _form _submitted
The advanced_dom_form_submitted event is published when a form on a page is submitted.
advanced _dom _input _blurred
The advanced_dom_input_blurred event is published when an input on a page loses focus.
advanced _dom _input _changed
The advanced_dom_input_changed event is published when an input value changes.
advanced _dom _input _focused
The advanced_dom_input_focused event is published when an input on a page gains focus.
advanced _dom _mouse _moved
The advanced_dom_mouse_moved event is published when a customer moves their cursor over the page.
advanced _dom _scrolled
The advanced_dom_scrolled event is published when a customer scrolls on a page or in a scrollable element.
advanced _dom _selection _changed
The advanced_dom_selection_changed event is published when a customer uses text selection on a page.
advanced _dom _window _resized
The advanced_dom_window_resized event is published when a customer resizes their browser window.
Was this page helpful?
Yes No
