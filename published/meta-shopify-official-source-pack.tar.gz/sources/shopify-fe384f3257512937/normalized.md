---
title: Advanced DOM Pixel Events API
source_url:
html: 'https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events'
md: 'https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events.md'
api_name: web-pixels
---
# Advanced DOM Pixel Events API
***
## For apps providing session recording and/or heatmaps
The Advanced DOM Events API provides events that replicate the DOM, changes to the DOM and user interactions. It can be used to recreate user journeys and interactions for session recording and/or heatmaps. The API provides these events across the Storefront, Checkout, Thank you page and Customer Accounts pages.
**Shopify Plus:**
These events are limited on [checkout](https://help.shopify.com/manual/checkout-settings) to stores on the [Shopify Plus](https://www.shopify.com/plus) plan.
**Access required:**
Requires access to the **Advanced DOM Events in web pixel app extensions** scope. To request access, please use the form in the Partner Dashboard. This scope is only available for apps that have a heatmap and/or session recordings. The Advanced DOM Events cannot be used on custom apps.
![For apps providing session recording and/or heatmaps](https://shopify.dev/assets/assets/images/templated-apis-screenshots/web-pixels-api/shopify-heatmaps-e4TwTkyF.png)
***
## Events
[advanced​\_dom​\_available](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_available)
[The advanced\_dom\_available event is published when the DOM has been loaded and is available for interaction.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_available)
[advanced​\_dom​\_changed](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_changed)
[The advanced\_dom\_changed event is published when the DOM has been changed in any way, such as an element being added, removed, or modified.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_changed)
[advanced​\_dom​\_clicked](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_clicked)
[The advanced\_dom\_clicked event is published when a customer clicks on a page element.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_clicked)
[advanced​\_dom​\_clipboard](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_clipboard)
[The advanced\_dom\_clipboard event is published when a customer has cut, copied or pasted text to or from the clipboard.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_clipboard)
[advanced​\_dom​\_form​\_submitted](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_form_submitted)
[The advanced\_dom\_form\_submitted event is published when a form on a page is submitted.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_form_submitted)
[advanced​\_dom​\_input​\_blurred](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_input_blurred)
[The advanced\_dom\_input\_blurred event is published when an input on a page loses focus.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_input_blurred)
[advanced​\_dom​\_input​\_changed](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_input_changed)
[The advanced\_dom\_input\_changed event is published when an input value changes.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_input_changed)
[advanced​\_dom​\_input​\_focused](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_input_focused)
[The advanced\_dom\_input\_focused event is published when an input on a page gains focus.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_input_focused)
[advanced​\_dom​\_mouse​\_moved](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_mouse_moved)
[The advanced\_dom\_mouse\_moved event is published when a customer moves their cursor over the page.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_mouse_moved)
[advanced​\_dom​\_scrolled](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_scrolled)
[The advanced\_dom\_scrolled event is published when a customer scrolls on a page or in a scrollable element.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_scrolled)
[advanced​\_dom​\_selection​\_changed](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_selection_changed)
[The advanced\_dom\_selection\_changed event is published when a customer uses text selection on a page.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_selection_changed)
[advanced​\_dom​\_window​\_resized](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_window_resized)
[The advanced\_dom\_window\_resized event is published when a customer resizes their browser window.](https://shopify.dev/docs/api/web-pixels-api/advanced-dom-events/advanced_dom_window_resized)
***
