- Shopify Help Center | Publishing products on Facebook and Instagram by Meta
Help
Log in
### Service disruptions at Shopify
Admin, Checkout and API & Mobile are experiencing issues.
For more details, check the Shopify Status page.
Contents
# Publishing products on Facebook and Instagram by Meta
After you set up Facebook and Instagram by Meta your Shopify products will start syncing to Facebook. You can select the products that you want to make available to the channel on the Product page, or by using the bulk editor in Facebook and Instagram by Meta.
When you make a product available to Facebook and Instagram by Meta, it's available to all of the features that you have set up in Facebook and Instagram by Meta. Because all of Facebook and Instagram by Meta's features share the same product catalog, it's not possible to make a product available to only one feature of Facebook and Instagram by Meta if you have multiple features set up. For example, if you have both Facebook Shop and Instagram Shopping set up in Facebook and Instagram by Meta, and you make a product available to Facebook and Instagram by Meta, then the product is available on both Facebook Shop and Instagram Shopping.
Unless your store is based in the United States, collections in Shopify don't sync to Facebook. If your store is located outside the United States, then you can create collections for Facebook using your available products in your Facebook Commerce Manager .
## On this page
Product requirements
- Make your products available to Facebook and Instagram by Meta
- Facebook product status
- Hide products from Facebook and Instagram by Meta
- Change product details
- View the products shared with Facebook
- Resolve product publishing errors
- Common product publishing errors
## Product requirements
If you want a product to be available on Facebook, then the product must meet a few requirements:
- It needs to be available to Facebook
- It needs to require shipping , so it can't be a digital product
- It needs to have a return policy
- The product title needs to meet Meta's Product Title Specifications for Catalogs
- The product description needs to meet Meta's Product Description Specifications for Catalogs
- The product image needs to meet Meta's Product Image Specifications for Catalogs
- It needs to be eligible according to Meta's Commerce Policy and can't be in violation of the Facebook Community Standards
- It needs to have a Google Product Category assigned to it
- It can't be free.
## Make your products available to Facebook and Instagram by Meta
To view the products that are available to Facebook and Instagram by Meta, in your Shopify admin click Facebook > Overview > View products .
If you don't have any products in your store, then click Add product to add products to your store .
#### Step 1: Check product availability on Facebook and Instagram by Meta
- Check that your products are published to Facebook and Instagram by Meta on the Products page.
- Click More filters .
- In the Availability section, select Unavailable on Facebook .
- Click Done .
#### Step 2: Make your products available on Facebook and Instagram by Meta
- If you want to make your products available on Facebook, then do one of the following:
Select all of the products that display after you apply the Unavailable on Facebook filter.
- Individually select what products you want to make available.
- Click More actions > Add available channel(s)... .
- In the new dialog window, select Facebook .
- Click Make products available .
## Facebook product status
The Product status section of the Overview page displays the status of products available on Facebook and Instagram by Meta, and indicates if there are any errors. For a list of errors, click View products . Use the information listed in the Issues column to fix any problems with a product.
## Hide products from Facebook and Instagram by Meta
-
From your Shopify admin, go to Products > Collections .
-
Click the name of the product that you want to hide from Facebook.
-
On the Product availability section of the product details page, click Manage .
-
In the Manage sales channels availability dialog, uncheck Facebook , and then click Done .
-
Click Save .
## Change product details
Changes to product details in Shopify are automatically synced to Facebook. You can change how a product's image, title, or price is displayed on Facebook by editing the product in Shopify. Your changes display on Facebook after your products sync, which usually takes a few minutes.
## View the products shared with Facebook
For a list of the products available to Facebook, as well as any product errors, go to the Product status section of Facebook and Instagram by Meta in your Shopify admin.
Desktop
-
From your Shopify admin, go to Sales channels > Facebook & Instagram .
-
If there are errors in the Product status section, then click the product for information on the error.
-
Optional: Click View all products to display all the products that are available in Facebook and Instagram by Meta to edit their availability, Google Product Category , and condition.
Mobile
-
From the Shopify app , tap the icon.
-
In the Sales channels section, tap Facebook .
-
A summary of the products that you have available in Facebook and Instagram by Meta displays in the Product status section.
## Resolve product publishing errors
When you sync products after you set up Checkout on Facebook and Instagram, you might have product publishing errors. If your products are missing information that Facebook needs, then a warning displays in the Products section on the Overview page of Facebook and Instagram by Meta. When a product has errors associated with it, you need to resolve those errors before you can try to sync the product again with Facebook and Instagram by Meta.
#### Steps:
-
From your Shopify admin, go to Sales channels > Facebook & Instagram .
-
In the Products section, click View products to open the bulk product editor. Learn how to use the bulk product editor .
-
Review any publishing errors for products, and make the required changes to product information.
-
Click Save .
## Common product publishing errors
Use this reference to help resolve product errors that prevent products from syncing to Facebook.
Common product publishing errors and their solutions
Error | Solution |
Add a product image | Click the placeholder image to upload or select an image for your product. |
Select a product category | Enter a Google product category that matches the product. Some categories also require additional information, such as age. |
Fix product variant errors | Add information for each product variant, such as the variant’s size and color. |
Leave feedback
