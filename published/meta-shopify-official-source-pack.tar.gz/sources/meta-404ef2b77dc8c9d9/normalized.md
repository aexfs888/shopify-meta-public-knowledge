-
Meta Blueprint : Learn new skills to build your brand or business
Skip to main content
This site uses cookies to provide you with a greater user experience. By using Exceed LMS, you accept our use of cookies .
Search
Topics
##
All Topics
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
Log In
# Meta Blueprint
Be the expert
## Get started with campaign recommendations from opportunity score
Opportunity score helps you identify campaign recommendations in near real time. Your recommendations are proven, personalized and prioritized, based on your business profile and campaign characteristics.
-
###
Introduction to opportunity score
Discover how opportunity score provides recommendations that can help improve campaign performance.
-
Duration
3m
-
Rating 4.6
- Beginner
-
###
Include Reels placements in your campaigns
Discover how to get started with the Reels ad placement to help improve your campaign performance.
-
Duration
1m
-
Rating 4.6
- Intermediate
-
###
Use Advantage+ audience to connect with the right people
Learn about how Advantage+ audience can help you reach the people who are likely to be interested in your business and how to get started.
-
Duration
1m
-
Rating 4.8
- Intermediate
-
###
Understanding ad fragmentation: Tips to optimize your ads for better results
Learn how reducing ad fragmentation can help you optimize your ads for better results.
-
Duration
2m
-
Rating 4.7
- Intermediate
What's new
Protect your accounts and brand assets across Meta technologies
Learn to secure, monitor and recover your accounts across Meta technologies.
Start course
If this list is too long for the page, you can scroll it left and right
-
###
How to create a Facebook Page
-
Duration
1m
-
Rating 4.8
-
Credential
-
###
How to post on a Facebook Page
-
Duration
1m
-
Rating 4.8
-
Credential
-
###
Get started with Ads Manager
-
Rating 4.6
-
Credential
-
###
Create ads from a Facebook Page
-
Rating 4.7
-
Credential
Increase Sales
Learn how you can use social media to drive in-store purchases and increase onlines sales.
Get started with advertising
Build lasting connections with customers with ads on Facebook, Instagram, WhatsApp and Messenger.
Your guide to audience targeting
Learn how to target people most likely to respond to your ad.
Manage ads with automated tools
Meta Advantage+ offers tools to help you advertise your business while saving you time and effort.
Get results that matter to your business
Whether your goal is to increase online sales, generate qualified leads or get more traffic to your
website, we can help.
Optimize your campaigns
Connect your marketing data with the systems that optimize ad targeting to better measure outcomes
and
decrease costs.
If this list is too long for the page, you can scroll it left and right
-
###
Setting up your ad account for success with the Conversions API
-
Duration
3m
-
Rating 4.6
-
###
6 tips on how to optimize campaigns in Meta Ads Manager
-
Duration
2m
-
Rating 4.7
-
###
How to personalize your campaigns with Advantage+ catalog ads
-
Duration
2m
-
Rating 4.8
-
###
How to use messaging tools to build deeper connections with customers
-
Duration
2m
-
Rating 4.7
If this list is too long for the page, you can scroll it left and right
-
###
5:00 AM - EDT
#### Getting creative with Catalog Product Video - September 9 | EMEA | English
Omer Ozsever
Enroll Now
-
###
Sep 10 - 10:00 AM - EDT
#### Measure channel impact with Meta Conversion Lift - Sept 10 | NORAM | English
Martha Pena
Enroll Now
-
###
Sep 10 - 1:00 PM - EDT
#### Increase campaign performance with partnership ads - Sep 10 | NORAM | English
Brian Marilla
Enroll Now
-
###
Sep 11 - 11:00 AM - EDT
#### Creative Strategies to Succeed This Holiday Season - Sep 11 | NORAM | English
Felipe Barrientos
Enroll Now
-
###
Sep 14 - 9:00 AM - EDT
#### Grow your business with ads that click to Instagram Direct - September 14 | EMEA | English
Lina Poka
Enroll Now
-
###
Sep 14 - 1:00 PM - EDT
#### Get Holiday Ready: Maximize Peak Season Performance with Meta Advantage+ - Sep 14 | NORAM | English
Brian Marilla
Enroll Now
-
###
Sep 15 - 1:00 AM - EDT
#### Increase campaign performance with partnership ads - Sep 15 | APAC | English
Adam Sugihto
Enroll Now
-
###
Sep 15 - 11:00 AM - EDT
#### Opportunity score: experimentally proven recommendations to help improve your campaign performance - Sep 15 | NORAM | English
Felipe Barrientos
Enroll Now
-
###
Sep 15 - 12:00 PM - EDT
#### Prove It, Then Scale It: Measuring Your Holiday Ad Performance - Sept 15 | NORAM | English
Martha Pena
Enroll Now
-
###
Sep 16 - 9:00 AM - EDT
#### Best practices to improve the performance of ads that click to WhatsApp - September 16 | EMEA | English
Lina Poka
Enroll Now
-
###
Sep 17 - 1:00 AM - EDT
#### Increase campaign performance with partnership ads - Sep 17 | APAC | English
Su Zen Low
Enroll Now
-
###
Sep 17 - 11:00 AM - EDT
#### Optimize your ad creative with Advantage+ - Sep 17 | NORAM | English
Felipe Barrientos
Enroll Now
##
All Topics
-
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
