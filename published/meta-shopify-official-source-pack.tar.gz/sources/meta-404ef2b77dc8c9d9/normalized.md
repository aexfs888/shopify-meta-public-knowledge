-
Meta Blueprint : Learn new skills to build your brand or business
Skip to main content
This site uses cookies to provide you with a greater user experience. By using Exceed LMS, you accept our use of cookies .
Search
Topics
##
All Topics
Increase sales
-
Get started with advertising
-
Your guide to audience strategy
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
Log In
# Meta Blueprint
## Meta Blueprint is your one-stop training resource for Facebook, Messenger, Instagram and WhatsApp
###
Explore free online courses, live webinars and videos to get more out of Meta technologies.
Get certified
Create an ad
If this list is too long for the page, you can scroll it left and right
-
###
Use Meta Business Agent to help grow your business
-
Duration
10m
- Intermediate
-
Credential
-
###
Enhancing your workflow with new AI creative tools and features
-
Rating 4.0
- Intermediate
-
Credential
-
###
Opportunity score: experimentally proven recommendations to help improve your campaign performance
-
Duration
30m
-
Rating 4.8
- Intermediate
-
Credential
Based
on your role
## Take the next step with Meta Certification
Meta Certification recognizes advanced-level proficiency in Meta technologies, so you can master digital marketing
skills and stand out in your field.
Beginner
### Digital Marketing Associate
Earn a certification in foundational advertising concepts for Facebook, Instagram and
Messenger and establish industry-ready skills.
Learn more
Intermediate
### Media Planning Professional
Earn a certification in designing end-to-end marketing strategies across Meta
technologies that align with business goals.
Learn more
Intermediate
### Media Buying Professional
Earn a certification in buying ads and meet business goals by targeting, creating and
managing campaigns across Meta technologies.
Learn more
If this list is too long for the page, you can scroll it left and right
-
###
Use Advantage+ audience to connect with the right people
-
Duration
1m
-
Rating 4.8
- Intermediate
-
###
Include Reels placements in your campaigns
-
Duration
1m
-
Rating 4.7
- Intermediate
-
###
Understanding ad fragmentation: Tips to optimize your ads for better results
-
Duration
2m
-
Rating 4.7
- Intermediate
If this list is too long for the page, you can scroll it left and right
-
###
5:00 AM - EST
#### AI for advertising: faster answers, smarter spend, stronger results - November 3 | EMEA | English
Lina Poka
Enroll Now
-
###
5:00 AM - EST
#### Fundamentals - November 3 | EMEA | Turkish
Omer Ozsever
Enroll Now
-
###
10:00 AM - EST
#### Best practices to improve the performance of ads that click to WhatsApp - November 3 | EMEA | English
Lina Poka
Enroll Now
-
###
11:00 AM - EST
#### Certification Prep Virtual Training | Business Marketing Strategy - Part 2 - Nov 3 | NORAM | English
Brian Marilla
Enroll Now
-
###
1:00 PM - EST
#### Optimize for the conversions you value - Nov 3 | NORAM | English
Felipe Barrientos
Enroll Now
-
###
Nov 4 - 5:00 AM - EST
#### Measure the true impact of Meta ads on search traffic with Conversion Lift - November 4 | EMEA | English
Tamara Al Amad
Enroll Now
-
###
Nov 4 - 11:00 AM - EST
#### Certification Prep Virtual Training | Business Marketing Strategy - Part 3 - Nov 4 | NORAM | English
Brian Marilla
Enroll Now
-
###
Nov 4 - 1:00 PM - EST
#### Meta Advantage+ leads campaigns: generating high-quality leads with AI - Nov 4 | NORAM | English
Diana Muzquiz
Enroll Now
-
###
Nov 6 - 11:00 AM - EST
#### Getting creative with Catalog Product Video - Nov 6 | NORAM | English
Felipe Barrientos
Enroll Now
-
###
Nov 6 - 1:00 PM - EST
#### Optimize Meta Conversions API - Nov 6 | NORAM | English
Felipe Barrientos
Enroll Now
-
###
Nov 9 - 9:00 AM - EST
#### Practice Test Review - Business Messaging - November 9 | EMEA | English
Lina Poka
Enroll Now
-
###
Nov 9 - 2:30 PM - EST
#### AI for advertising: faster answers, smarter spend, stronger results - Nov 9 | NORAM | English
Brian Marilla
Enroll Now
What's new
Protect your accounts and brand assets across Meta technologies
Learn to secure, monitor and recover your accounts across Meta technologies.
Start course
Increase sales
Learn how you can use social media to drive in-store purchases and increase onlines sales.
Get started with advertising
Build lasting connections with customers with ads on Facebook, Instagram, WhatsApp and Messenger.
Your guide to audience strategy
Learn how to reach people most likely to respond to your ad.
Manage ads with automated tools
Meta Advantage+ offers tools to help you advertise your business while saving you time and effort.
Get results that matter to your business
Whether your goal is to increase online sales, generate qualified leads or get more traffic to your
website, we can help.
Optimize your campaigns
Connect your marketing data with the systems that optimize ad targeting to better measure outcomes
and
decrease costs.
##
All Topics
-
Increase sales
-
Get started with advertising
-
Your guide to audience strategy
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
