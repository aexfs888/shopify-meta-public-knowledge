API Graph - Documentación - Meta for Developers
-
API Graph
Información general
- Primeros pasos
- Solicitudes por lotes
- Solicitudes de depuración
- Administrar errores
- Field Expansion
- Secure Requests
- Registro de cambios
- Reference
Si eres usuario de Facebook y tienes problemas para iniciar sesión en tu cuenta, visita nuestro servicio de ayuda .
# API Graph
La versión más reciente es :
| v26.0 |
La API Graph es la principal herramienta que permite a las apps leer y escribir en la gráfica social de Facebook. Todos nuestros SDK y productos interactúan de algún modo con la API Graph, y las demás API son extensiones de esta. Por esta razón, es fundamental entender cómo funciona.
Si no estás familiarizado con la API Graph, te recomendamos que empieces con esos documentos:
- Información general : obtén información sobre cómo está estructurada la API Graph y cómo funciona.
- Primeros pasos: explora los puntos de conexión de la API Graph con la herramienta de exploración de la API Graph y realiza la primera solicitud.
- Solicitudes por lotes: obtén información sobre cómo enviar solicitudes múltiples a la API en una sola llamada.
- Solicitudes de depuración: obtén información sobre cómo depurar las solicitudes a la API.
- Manejo de errores: obtén información sobre cómo manejar errores comunes que se producen cuando se usa la API Graph.
- Expansión de campo: obtén información sobre cómo limitar el número de objetos que se devuelven en una solicitud y cómo realizar solicitudes anidadas.
- Solicitudes seguras: obtén información sobre cómo hacer solicitudes seguras a la API Graph.
- API de cargas reanudables: obtén información sobre cómo subir archivos a la API Graph.
#### Referencias
Obtén información sobre cómo leer los documentos de referencia para que puedas encontrar fácilmente lo que buscas.
## ¿Dónde empezar?
Te recomendamos que comiences con la información general de la API Graph para que obtengas información sobre la estructura de la gráfica social de Facebook.
