Standard API Skip to main content
analytics
Provides access to Shopify's customer event API
browser
Provides access to specific browser methods that asynchronously execute in the top frame (cookie, localStorage, sessionStorage)
customer Privacy
Provides access to the customerPrivacy API to track whether or not customers have given consent.
init
A JSON object containing a snapshot of the page at time of page render.
settings
Provides access to the settings JSON object as set by the GraphQL Admin API (Web pixel app extensions only).
Was this page helpful?
Yes No
