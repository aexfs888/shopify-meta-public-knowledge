---
title: Standard API
source_url:
html: 'https://shopify.dev/docs/api/web-pixels-api/standard-api'
md: 'https://shopify.dev/docs/api/web-pixels-api/standard-api.md'
api_name: web-pixels
---
# Standard API
[analytics](https://shopify.dev/docs/api/web-pixels-api/standard-api/analytics)
[Provides access to Shopify's customer event API](https://shopify.dev/docs/api/web-pixels-api/standard-api/analytics)
[browser](https://shopify.dev/docs/api/web-pixels-api/standard-api/browser)
[Provides access to specific browser methods that asynchronously execute in the top frame (cookie, localStorage, sessionStorage)](https://shopify.dev/docs/api/web-pixels-api/standard-api/browser)
[customer​Privacy](https://shopify.dev/docs/api/web-pixels-api/standard-api/customerprivacy)
[Provides access to the customerPrivacy API to track whether or not customers have given consent.](https://shopify.dev/docs/api/web-pixels-api/standard-api/customerprivacy)
[init](https://shopify.dev/docs/api/web-pixels-api/standard-api/init)
[A JSON object containing a snapshot of the page at time of page render.](https://shopify.dev/docs/api/web-pixels-api/standard-api/init)
[settings](https://shopify.dev/docs/api/web-pixels-api/standard-api/settings)
[Provides access to the settings JSON object as set by the GraphQL Admin API (Web pixel app extensions only).](https://shopify.dev/docs/api/web-pixels-api/standard-api/settings)
***
