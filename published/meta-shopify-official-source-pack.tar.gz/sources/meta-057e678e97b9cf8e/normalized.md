# Lookalike Audiences
**Warning:** Beginning September 2, 2025, we will start to roll out more proactive restrictions on custom audiences that may suggest information not permitted under our terms. For example, any custom audience or lookalike audience suggesting specific health conditions (e.g., &quot;arthritis&quot;, &quot;diabetes&quot;) or financial status (e.g., &quot;credit score&quot;, &quot;high income&quot;) will be flagged and prevented from being used to run ad campaigns.
**What these restrictions mean for your campaigns:**
* You won&#039;t be able to use flagged custom audiences when creating new campaigns.
* If you have an active campaign using flagged custom audiences, you should edit or pause it and choose a different audience to avoid performance and delivery issues.
**For API developers:**
* Beginning September 2, 2025, `operation_statu`s will return `471` to signal if your custom audiences have been flagged.
More information on this update and how to resolve flagged custom audiences can be found [here](https://www.facebook.com/business/help/1055828013359808).
Target people most like your established customers. Lookalike audiences take several sets of people as &quot;seeds&quot; then Facebook builds an audience of similar people. You can use lookalikes for any business objective: Targeting people similar to your customers for fan acquisition, site registration, off-Facebook purchases, coupon claims, or to drive awareness of a brand.
Seed audiences can be:
* [Existing Custom Audiences](#custom-audience)
* [Campaign or ad set conversions](#campaign)
* [Page fans](#page_fan_lookalikes)
Facebook refreshes members in a lookalike every 3 days if the lookalike belongs to an ad set.
## Create &#123;#create&#125;
**Lookalike audiences can take 1-6 hours to fully populate.** While audiences populate, you can create and run ad sets targeting the audience. Once the audience is ready, Facebook delivers to people populated in the audience and ads delivery will catch up and work as normal. See [Delivery Status](#delivery-status). Create a new lookalike audience at: `https://graph.facebook.com/&#123;API_VERSION&#125;/act_&#123;AD_ACCOUNT_ID&#125;/customaudiences`.
Example creation call for lookalike from a custom audience:
```bash
curl \
-F &#039;name=My lookalike audience&#039; \
-F &#039;subtype=LOOKALIKE&#039; \
-F &#039;origin_audience_id=&lt;SEED_AUDIENCE_ID&gt;&#039; \
-F &#039;lookalike_spec=&#123;&quot;type&quot;:&quot;similarity&quot;,&quot;country&quot;:&quot;US&quot;&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/customaudiences
```
To create lookalike audiences with [PHP Ads SDK](https://github.com/facebook/facebook-php-ads-sdk) or [Python Ads SDK](https://github.com/facebook/facebook-python-ads-sdk), use `CustomAudience`.
The response contains:
| Name | Description |
| --- | --- |
| `id`&lt;br&gt;&lt;br&gt;type: integer | ID of lookalike audience |
### Custom Audience lookalike &#123;#custom-audience&#125;
If you have a Custom Audience with at least 100 people, you can build lookalike audiences based on it. This includes Custom Audiences for your Website and Custom Audiences for your Mobile App.
| Name | Description |
| --- | --- |
| `name`&lt;br&gt;&lt;br&gt;type: string | **Required.**&lt;br&gt;&lt;br&gt;Custom Audience name |
| `origin_audience_id`&lt;br&gt;&lt;br&gt;type: long | **Required.**&lt;br&gt;&lt;br&gt;ID of Custom Audience. Origin audiences must have at least 100 members. |
| `lookalike_spec`&lt;br&gt;&lt;br&gt;type: array | **Required.**&lt;br&gt;&lt;br&gt;See description below. |
| `lookalike_spec.type`&lt;br&gt;&lt;br&gt;type: string | **Required. Set either `type` or `ratio`.**&lt;br&gt;&lt;br&gt;`similarity` or `reach` |
| `lookalike_spec.starting_ratio`&lt;br&gt;&lt;br&gt;type: float | **Optional.**&lt;br&gt;&lt;br&gt;Start percentage for lookalike. For example, `starting_ratio` 0.01 and `ratio` 0.02 creates a lookalike from 1% to 2% of a lookalike segment. `starting_ratio` must be less than ratio |
| `lookalike_spec.ratio`&lt;br&gt;&lt;br&gt;type: float | **Required. Set either `type` or `ratio`.**&lt;br&gt;&lt;br&gt;`0.01`-`0.20` incremented by 0.01. Top x% of original audience in a selected country |
| `lookalike_spec.allow_international_seeds`&lt;br&gt;&lt;br&gt;type: boolean | **Optional.**&lt;br&gt;&lt;br&gt;At least 100 seed audience members from a country. If not, `allow_international_seeds` set to `true` means Facebook finds this minimum number of audience members in another country. Default `false`. |
| `lookalike_spec.country`&lt;br&gt;&lt;br&gt;type: string | **Required. Set `country` or `location_spec`.**&lt;br&gt;&lt;br&gt;Find lookalike audience members in this country |
| `lookalike_spec.location_spec`&lt;br&gt;&lt;br&gt;type: array | **Required. Either `country` or `location_spec`.**&lt;br&gt;&lt;br&gt;Find audience members in these locations. List of countries or country groups such as `Asia` |
| `lookalike_spec.location_spec.geo_locations`&lt;br&gt;&lt;br&gt;type: array | **Required. At least one entry under `countries` or `country_groups`.**&lt;br&gt;&lt;br&gt;Include these locations |
| `lookalike_spec.location_spec.geo_locations.countries`&lt;br&gt;&lt;br&gt;type: array of strings | **Optional.**&lt;br&gt;&lt;br&gt;Target countries. Array of country codes, see [Targeting Search API, Countries](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/targeting-search#countries).&lt;br&gt;**Example**: `&#039;countries&#039;: [&#039;US&#039;]` |
| `lookalike_spec.location_spec.geo_locations.country_groups`&lt;br&gt;&lt;br&gt;type: array of strings | **Optional.**&lt;br&gt;&lt;br&gt;Target countries in global regions and free trade areas. Array of country group codes. For full options, see [Targeting, Location, `country_groups`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/basic-targeting#location) and [Targeting Search, `country_groups`](https://developers.facebook.com/docs/marketing-api/targeting-search/v2.8#country_group).&lt;br&gt;**Example**: `&#039;country_groups&#039;: [&#039;asia&#039;,&#039;mercosur&#039;]` |
| `lookalike_spec.location_spec.excluded_geo_locations`&lt;br&gt;&lt;br&gt;type: array | **Optional.**&lt;br&gt;&lt;br&gt;Locations to exclude |
| `lookalike_spec.location_spec.excluded_geo_locations.countries`&lt;br&gt;&lt;br&gt;type: array of strings | **Optional.**&lt;br&gt;&lt;br&gt;Same as `countries` under `geo_locations` |
| `lookalike_spec.location_spec.excluded_geo_locations.country_groups`&lt;br&gt;&lt;br&gt;type: array of strings | **Optional.**&lt;br&gt;&lt;br&gt;Same as `country_groups` under `geo_locations` |
### Types &#123;#types&#125;
Optimize your audience for &quot;Similarity&quot; or &quot;Greater reach&quot;.
* Similarity - Audience includes the top 1% of people in a selected country who are most similar to the seed Custom Audience. The new audience&#039;s reach is smaller, matching is more precise.
* Greater Reach - Audience includes the top 5% of people in the selected country that are similar to the seed Custom Audience, but with a less precise match.
**Instead of using types you can manually set `ratio` to represent the top x% of the audience in the selected country.** `ratio` should be from 1%-20% and in intervals of 1%.
### Campaign or ad set conversion lookalikes &#123;#campaign&#125;
Facebook has campaign and ad set conversion lookalikes to target people similar to those converting from previous or current campaigns, or ad sets; for example, campaigns or ads that are optimizing for conversions. Meta measures conversions based on a campaign or ad set type in [Conversion Specs](https://developers.facebook.com/documentation/ads-commerce/marketing-api/tracking-specs). For example, target people that took action on your website or installed your app within 28 days of clicking your ad.
```bash
curl \
-F &#039;subtype=LOOKALIKE&#039; \
-F &#039;lookalike_spec=&#123;
&quot;origin_ids&quot;: &quot;&lt;CAMPAIGN_ID&gt;&quot;,
&quot;starting_ratio&quot;: 0.03,
&quot;ratio&quot;: 0.05,
&quot;conversion_type&quot;: &quot;campaign_conversions&quot;,
&quot;country&quot;: &quot;US&quot;
&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/customaudiences
```
You need at least 100 unique conversions from your campaigns or ad sets. More converters result in a better predictive model, and 200 or more members who converted is recommended. You should also select campaigns or ad sets with similar objectives.
To create this lookalike, specify one or more of your campaigns or ad sets. For example, specify one campaign and two ad sets of another campaign.
Facebook uses up to 180 days of past conversion data and identifies people converting on your campaigns and ad sets as examples. Meta trains a prediction model, then creates a lookalike audience. Facebook constantly updates the underlying prediction model as campaigns or ad sets get new conversions.
| Name | Description |
| --- | --- |
| `lookalike_spec`&lt;br&gt;&lt;br&gt;type: array | **Required.**&lt;br&gt;&lt;br&gt;See description below. |
| `lookalike_spec.origin_ids`&lt;br&gt;&lt;br&gt;type: array of integers | **Required.**&lt;br&gt;&lt;br&gt;Array of ad object ids. People who convert on these ads are used to model a lookalike. One or more __campaign IDs or ad set IDs__, or a mix of them. |
| `lookalike_spec.conversion_type`&lt;br&gt;&lt;br&gt;type: string | **Required.**&lt;br&gt;&lt;br&gt;`campaign_conversions`. Indicates audience is a campaign conversion lookalike |
| `lookalike_spec.country`&lt;br&gt;&lt;br&gt;type: string | **Required.**&lt;br&gt;&lt;br&gt;Country to find lookalike members. |
| `lookalike_spec.allow_international_seeds`&lt;br&gt;&lt;br&gt;type: boolean | **Optional.**&lt;br&gt;&lt;br&gt;At least 100 seed audience members from a country. If not, `allow_international_seeds` set to `true` means Facebook finds this minimum number of members in another country. Defaults to `false`. |
| `lookalike_spec.starting_ratio`&lt;br&gt;&lt;br&gt;type: float | **Optional.**&lt;br&gt;&lt;br&gt;Start percentage for lookalike. For example, `starting_ratio` 0.01 and `ratio` 0.02 creates a lookalike from 1% to 2% of a lookalike segment. `starting_ratio` must be less than `ratio` |
| `lookalike_spec.ratio`&lt;br&gt;&lt;br&gt;type: float | **Required.**&lt;br&gt;&lt;br&gt;Range of `0.01`-`0.20`. Top x% of original audience in the selected country. |
Currently, the following campaign conversion types are eligible for Lookalike Audiences:
* Link clicks
* Offer ads
* Page likes
* Canvas App installs
* Event responses
* Post engagement
* Website conversions
* Mobile app installs
* Mobile app engagement
* Video views
* Local awareness
### Page fan lookalikes &#123;#page_fan_lookalikes&#125;
Create a lookalike audience based on people who like your Page:
```bash
curl \
-F &#039;subtype=LOOKALIKE&#039; \
-F &#039;lookalike_spec=&#123;
&quot;ratio&quot;: 0.01,
&quot;country&quot;: &quot;US&quot;,
&quot;page_id&quot;: &quot;&lt;PAGE_ID&gt;&quot;,
&quot;conversion_type&quot;: &quot;page_like&quot;
&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/customaudiences
```
| Name | Description |
| --- | --- |
| `lookalike_spec`&lt;br&gt;&lt;br&gt;type: array | **Required.**&lt;br&gt;&lt;br&gt;See description below. |
| `lookalike_spec.page_id`&lt;br&gt;&lt;br&gt;type: int | **Required.**&lt;br&gt;&lt;br&gt;Facebook ID of the page whose fans will be used for the lookalike |
| `lookalike_spec.conversion_type`&lt;br&gt;&lt;br&gt;type: string | **Required.**&lt;br&gt;&lt;br&gt;`page_like` - Indicates that this is a page fan lookalike |
| `lookalike_spec.country`&lt;br&gt;&lt;br&gt;type: string | **Required.**&lt;br&gt;&lt;br&gt;The country to find the lookalike people. The default is `US`. |
| `lookalike_spec.allow_international_seeds`&lt;br&gt;&lt;br&gt;type: boolean | **Optional.**&lt;br&gt;&lt;br&gt;You need at least 100 seed audience members from a country. If this minimum is not satisfied, `allow_international_seeds` set to `true` means Facebook finds this minimum number of seed audience members in another country. Defaults to `false`. |
| `lookalike_spec.starting_ratio`&lt;br&gt;&lt;br&gt;type: float | **Optional.**&lt;br&gt;&lt;br&gt;Starting percentage of the lookalike. For example, a `starting_ratio` of 0.01 and a `ratio` of 0.02 would create a lookalike from the 1% to 2% lookalike segment. The value of `starting_ratio` should always be less than that of `ratio` |
| `lookalike_spec.ratio`&lt;br&gt;&lt;br&gt;type: float | **Required.**&lt;br&gt;&lt;br&gt;Range 0.01-0.20. How much of the country the lookalike should target. |
### Flagged custom and lookalike audiences &#123;#flagged-audiences&#125;
If the seed audience is flagged with an `operation_status` of `471`, attempts to create a lookalike audience based on the seed audience will fail with an error.
```json
&#123;
&quot;error&quot;: &#123;
&quot;message&quot;: &quot;Invalid parameter&quot;,
&quot;code&quot;: 100,
&quot;error_subcode&quot;: 1713232,
&quot;error_user_title&quot;: &quot;Seed audience restricted&quot;,
&quot;error_user_msg&quot;: &quot;The seed audience you selected cannot be used to create a lookalike audience because it has integrity restrictions. Please use a different seed audience&quot;,
&#125;,
&#125;
```
## Targeting &#123;#targeting&#125;
Targeting lookalikes is the same as targeting __Custom Audiences__. See [Custom Audiences, Targeting](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience#targeting). This also applies for exclusion targeting and conjunctive `AND` targeting. To target when you create an ad:
```bash
curl \
-F &#039;name=My AdSet&#039; \
-F &#039;optimization_goal=REACH&#039; \
-F &#039;billing_event=IMPRESSIONS&#039; \
-F &#039;bid_amount=2&#039; \
-F &#039;daily_budget=1000&#039; \
-F &#039;campaign_id=&lt;CAMPAIGN_ID&gt;&#039; \
-F &#039;targeting=&#123;
&quot;custom_audiences&quot;: [&#123;&quot;id&quot;:&quot;&lt;LOOKALIKE_AUDIENCE_ID&gt;&quot;&#125;],
&quot;geo_locations&quot;: &#123;&quot;countries&quot;:[&quot;US&quot;]&#125;
&#125;&#039; \
-F &#039;status=ACTIVE&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/adsets
```
More examples at [Targeting Specs](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/advanced-targeting).
## Managing audiences &#123;#read&#125;
Get details on custom audiences used to create lookalikes as well as lookalikes. Meta returns the same fields as [Custom Audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience#read). Below is a sample response for a Custom Audience used to create lookalikes. `lookalike_audience_ids` specifies which lookalike audiences were generated from this audience.
```json
&#123;
&quot;id&quot;: &quot;6006164557194&quot;,
&quot;account_id&quot;: 12345,
&quot;approximate_count&quot;: 816400,
&quot;lookalike_audience_ids&quot;: [
6006183285954,
6006183285955
],
&quot;name&quot;: &quot;Boys Apparel&quot;,
&quot;parent_audience_id&quot;: 0,
&quot;parent_category&quot;: &quot;Custom&quot;,
&quot;status&quot;: &quot;ready&quot;,
&quot;subtype&quot;: &quot;CUSTOM&quot;,
&quot;type&quot;: 4,
&quot;type_name&quot;: &quot;Advertiser Generated&quot;,
&quot;time_updated&quot;: 1362439491
&#125;,
```
Lookalike audiences contain a `subtype` of 2. Meta also returns `lookalike_spec`, an array in this format:
| Name | Description |
| --- | --- |
| `type`&lt;br&gt;&lt;br&gt;type: string | `similarity`, `reach` or `custom_ratio` - Always returned |
| `starting_ratio`&lt;br&gt;&lt;br&gt;type: float | Returned if `starting_ratio` specified |
| `ratio`&lt;br&gt;&lt;br&gt;type: float | Multiple of `0.01`. Returned if `type` is `custom_ratio` |
| `country`&lt;br&gt;&lt;br&gt;type: string | Country code |
| `origin`&lt;br&gt;&lt;br&gt;type: array | See description below. |
| `origin.deleted`&lt;br&gt;&lt;br&gt;type: boolean | `true`, Returned when the origin deleted |
| `origin.id`&lt;br&gt;&lt;br&gt;type: int | Origin ID |
| `origin.name`&lt;br&gt;&lt;br&gt;type: string | Origin name |
| `origin.type`&lt;br&gt;&lt;br&gt;type: string | `custom_audience` or `page` |
| `target_countries`&lt;br&gt;&lt;br&gt;type: array of strings | All countries used to create audience |
Another audience below where `subtype` is `LOOKALIKE`:
```json
&#123;
&quot;id&quot;: &quot;6006183285954&quot;,
&quot;account_id&quot;: 12345,
&quot;approximate_count&quot;: 1782100,
&quot;name&quot;: &quot;Boys Apparel_lookalike_US_Similarity&quot;,
&quot;origin_audience_id&quot;: 6006567610735,
&quot;parent_audience_id&quot;: 0,
&quot;parent_category&quot;: &quot;Custom&quot;,
&quot;status&quot;: &quot;ready&quot;,
&quot;subtype&quot;: &quot;LOOKALIKE&quot;,
&quot;type&quot;: 4,
&quot;type_name&quot;: &quot;Advertiser Generated&quot;,
&quot;time_updated&quot;: 1362506552
&#125;,
```
### Delivery status &#123;#delivery-status&#125;
After you create a lookalike audience, Meta returns a Custom Audience ID. It can take about one hour to fully populate an audience. You can get the status at: `/&#123;lookalike_audience_ID&#125;?fields=delivery_status`. This returns a JSON response with `delivery_status` or code 200 if an audience populates:
```json
&quot;delivery_status&quot;: &#123;
&quot;code&quot;: 200,
&quot;description&quot;: &quot;This audience is ready for use.&quot;
&#125;,
```
For testing, you should check the status of the list with [Ads Manager](https://www.facebook.com/ads/audience_manager/).
To delete a lookalike audience, follow the same process as for [Custom Audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience).
## Inactive audiences &#123;#inactive&#125;
A lookalike audience is considered inactive when it has not been used in active ads for 90 days. Inactive lookalike audiences have different `approximate_count`, `operation_status`, and `delivery_estimate`.
| Field | Changes for Inactive Lookalikes |
| --- | --- |
| `approximate_count` | You are not able to retrieve a size. A call for this field returns `-1` for inactive lookalikes. |
| `operation_status` | `450`: This lookalike audience is inactive. It can be used in ads but will not have an estimate till the campaign is published.&lt;br&gt;&lt;br&gt;`100`: If an audience hasn&#039;t been used in an active ad set for over 2 years, it will begin to expire. Expiring audiences that remain unused for 90 days will be deleted.&lt;br&gt;&lt;br&gt;`471`: The lookalike audience has been flagged for integrity reasons. |
| `delivery_estimate` | You are not able to retrieve a delivery estimate. A call for this field returns `-1` for inactive lookalikes. This field is available under Ad Account and Ad Set nodes. Both exhibit the same behavior for inactive lookalikes. |
| `delete_time` | When an audience&#039;s `operation_status` has been marked as expiring (code `100`), the `delete_time` field tells you in Unix time when the audience will be deleted. |
You can still start a campaign using an inactive lookalike audience. The reach estimate information is available after your new ad gets published.
### Deletion
For all advertisers beginning June 8, 2021, and going forward, audiences will be moved automatically to the &quot;Expiring Audience&quot; stage once they have been inactive for over two years. This means that once an audience meets the threshold of not being used in an active ad set for over two years, it will be flagged automatically as an &quot;Expiring Audience&quot;, and the `delete_time` field will be marked with the estimated deletion time (that is, 90 days from the time of flagging) when the audience is scheduled to be deleted.
You will then be able to either proactively delete the audience or use the audience in an active ad set to prevent deletion. You can see which of your audiences are in the expiring stage at any time by filtering on their `operation_status` or `delete_time` fields.
For more information, see the [Custom Audiences Overview](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/overview#custom-audiences-deletion) documentation.
## Best practices &#123;#bestpractices&#125;
* Seed Custom Audience - Make it as large as possible so Meta has enough data to find similar people.
* Combine Lookalikes — Combine with other Facebook targeting for additional demographics or interests.
* If your seed audience has attributes such as gender or geography, the lookalikes generated may not adhere to those attributes.
## Upcoming lookalike changes &#123;#changes&#125;
**Warning:** **UPDATED APRIL 28, 2021:** The removal of the `location_spec` and `country` parameters from lookalike audience creation is currently delayed. Updates on when this change will go into effect will be forthcoming.
Meta will remove the `location_spec` and `country` parameters from lookalike audience creation. The location for the lookalikes will be defined by the country location in the campaign&#039;s targeting specification. The target location won&#039;t be a part of the lookalike audience specification. The reach estimate of the campaign using a newly created lookalike will be populated only in a few hours after the ad being published.
There will be no impact on existing campaigns given this change. This requirement will only impact new and edited campaigns.
Meta automatically converts legacy lookalike audiences into new lookalikes without target locations.
### Changes to lookalike creation
#### Location parameter changes
**Endpoint:** `act_&#123;AD_ACCOUNT_ID&#125;/customaudiences`
**Example Request**
```
curl POST \
-F &#039;name=My lookalike audience&#039; \
-F &#039;subtype=LOOKALIKE&#039; \
-F &#039;origin_audience_id=&lt;SEED_AUDIENCE_ID&gt;&#039; \
-F &#039;lookalike_spec=&#123;
&quot;is_financial_service&quot;:false,
&quot;allow_international_seeds&quot;:true,
&quot;ratio&quot;:0.01,
&quot;type&quot;:&quot;custom_ratio&quot;&#125;
&#039;&#125;\
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v2.11/act_&lt;AD_ACCOUNT_ID&gt;/customaudiences
```
The following parameters will be ignored if passed during creation:
* `lookalike_spec.country`
* `lookalike_spec.location_spec`
* `lookalike_spec.location_spec.geo_locations`
* `lookalike_spec.location_spec.geo_locations.countries`
* `lookalike_spec.location_spec.geo_locations.country_groups`
* `lookalike_spec.location_spec.excluded_geo_locations`
* `lookalike_spec.location_spec.excluded_geo_locations.countries`
* `lookalike_spec.location_spec.excluded_geo_locations.country_groups`
#### Size parameter changes
**Endpoint:** `act_&#123;AD_ACCOUNT_ID&#125;?fields=approximate_count`
There will be no size associated with new lookalike audiences, and the `approximate_count` field will return `-1` for all lookalike audiences.
**Example Response**
```
&#123;
&quot;approximate_count&quot;: -1,
&quot;id&quot;: &quot;6126486105659&quot;,
&#125;
```
#### Delivery and operation status
**Endpoints:**
* `&#123;AD_ACCOUNT_ID&#125;?fields=delivery_status`
* `&#123;AD_ACCOUNT_ID&#125;?fields=operation_status`
The `delivery_status` field for old lookalike audiences with location specifications will return a code `400` with a `This audience is disabled.` description. For new lookalike audiences it will return a code `200` response.
The `operation_status` field will return a retirement notification for old lookalike audiences with location specifications. For new lookalike audiences it will return a code `200` and `Normal` description response.
See [Custom Audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience) for more information about these fields.
### Changes to ad sets
#### Ad creation and editing
Meta automatically upgrades ads to use new lookalikes if the targeting of the existing campaigns containing the legacy lookalike is edited. The legacy lookalike will no longer be available for use in newly created ad campaigns.
With location specifications removed from lookalike audience creation, you will need to set location targets during Ad Set creation. Attempting to create an Ad Set without location targeting will result in an error.
All the above changes will also be applicable when audiences are included in `excluded_custom_audiences`, `flexible_spec`, and `exclusions` in the campaign.
**Endpoint:** `act_&#123;AD_ACCOUNT_ID&#125;/adsets`
**Example Request**
```
curl POST \
-F &#039;targeting=&#123;
&quot;geo_locations&quot;:&#123;
&quot;countries&quot;:[&quot;US&quot;],
&#125;,
&quot;age_min&quot;:25,
&quot;age_max&quot;:40,
&quot;custom_audiences&quot;:[&#123;&quot;id&quot;: &lt;CUSTOM_AUDIENCE_ID&gt;&#125;]
&#039;&#125;\
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v2.11/act_&lt;AD_ACCOUNT_ID&gt;/adsets
```
Attempting to create an Ad Set without location targeting will result in an error.
```json
&#123;
&quot;error&quot;: &#123;
&quot;message&quot;: &quot;Invalid parameter&quot;,
&quot;type&quot;: &quot;FacebookApiException&quot;,
&quot;code&quot;: 100,
&quot;error_data&quot;: &#123;
&quot;blame_field_specs&quot;: [[&quot;targeting&quot; ] ]
&#125;,
&quot;error_subcode&quot;: 192342134,
&quot;is_transient&quot;: false,
&quot;error_user_title&quot;: &quot;Missing Location while using Lookalike&quot;,
&quot;error_user_msg&quot;: &quot;You need to use a location with your lookalike audience.&quot;,
&quot;fbtrace_id&quot;: &quot;F78cCCJoZPx&quot;
&#125;,
&quot;__fb_trace_id__&quot;: &quot;F78cCCJoZPx&quot;,
&quot;__www_request_id__&quot;: &quot;AcwlIc7_uK5uTXjzjIa38yc&quot;
&#125;
```
If you try to edit an Ad Set containing a shared legacy lookalike and don&#039;t have a corresponding new lookalike in the owning ad account, an error will occur. Request the owning ad account share the new lookalike audience with you to resolve the issue.
```json
&#123;
&quot;error&quot;: &#123;
&quot;message&quot;: &quot;Invalid parameter&quot;,
&quot;type&quot;: &quot;FacebookApiException&quot;,
&quot;code&quot;: 100,
&quot;error_data&quot;: &#123;
&quot;blame_field_specs&quot;: [[&quot;targeting&quot; ] ]
&#125;,
&quot;error_subcode&quot;: 192342135,
&quot;is_transient&quot;: false,
&quot;error_user_title&quot;: &quot;&quot;,
&quot;error_user_msg&quot;: &quot;Please ask the owner of the audience 1234 to share the new lookalike which does not contain location with you. You will be able to use the new audience&quot;,
&quot;fbtrace_id&quot;: &quot;F78cCCJoZPx&quot;
&#125;,
&quot;__fb_trace_id__&quot;: &quot;F78cCCJoZPx&quot;,
&quot;__www_request_id__&quot;: &quot;AcwlIc7_uK5uTXjzjIa38yc&quot;
&#125;
```
#### Sharing lookalike audiences
During the rollout period of these changes, sharing lookalikes between ad accounts in the rollout and ad accounts not in the rollout is not supported via the API. Use Audience Manager to handle the sharing. After May 24, 2021, you can continue to use sharing via API in the following developer document to share new lookalike audiences between ad accounts.
**Endpoint:** `&#123;AD_ACCOUNT_ID&#125;/adaccounts?adaccounts=&#123;SHARED_TO_AD_ACCOUNT_ID&#125;`
### Reach and delivery estimate changes
**Endpoints:**
* `act_&#123;AD_ACCOUNT_ID&#125;/reachestimate`
* `act_&#123;AD_ACCOUNT_ID&#125;/delivery_estimate`
These endpoints will return a new `targeting_status` parameter with one of the following descriptions:
* `lookalike_container_without_country` — A new lookalike does not have a country specified in the campaign targeting. A country is needed to see the estimated users number.
* `lookalike_container_without_delivery_lookalike` — A new lookalike does not have a corresponding backend lookalike. The new lookalike needs to be used in an Ad Set for it to actually have reach.
* `none` — There is no issue with the reach.
The `reachestimate` endpoint will return `-1` for the `users` parameter the first time a new lookalike audience and country target is used; thereafter the estimated user count will be returned.
The `estimate_dau` and `estimate_mau` parameters will return `-1` for the `users` parameter the first time a new lookalike audience and country target is used; thereafter the estimated user count will be returned.
**Example Responses**
```json
// Reach estimate response
&#123;
&quot;users&quot;: -1,
&quot;estimate_ready&quot;: true,
&quot;targeting_status&quot;: &quot;lookalike_container_without_delivery_lookalike&quot;
&#125;
// Delivery estimate response
&#123;
&quot;data&quot;: [&#123;
&quot;daily_outcomes_curve&quot;: [&#123;
&quot;spend&quot;: 0,
&quot;reach&quot;: 0,
&quot;impressions&quot;: 0,
&quot;actions&quot;: 0
&#125;],
&quot;estimate_dau&quot;: -1,
&quot;estimate_mau&quot;: -1,
&quot;estimate_ready&quot;: true ,
&quot;targeting_status&quot;: &quot;lookalike_container_without_delivery_lookalike&quot;
&#125;]
&#125;
```
### FAQ
**When will these changes go into affect?**
**UPDATED APRIL 28, 2021:** The removal of the`location_spec` and `country` parameters from lookalike audience creation is currently delayed. Updates on when this change will go into effect will be forthcoming.
**Will I be able to share the new Lookalikes that don&#039;t have location specs with other ad accounts still under legacy Lookalikes during the release?**
**UPDATED APRIL 28, 2021:** The removal of the`location_spec` and `country` parameters from lookalike audience creation is currently delayed. Updates on when this change will go into effect will be forthcoming.
During the period between Marketing API v10 and v11, sharing lookalikes between ad accounts in the rollout and ad accounts not in the rollout is not supported via the API. Please use Audience Manager to handle the sharing.
After the release of Marketing API v11, you can continue to use sharing via the API to share new lookalike audiences between ad accounts.
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
