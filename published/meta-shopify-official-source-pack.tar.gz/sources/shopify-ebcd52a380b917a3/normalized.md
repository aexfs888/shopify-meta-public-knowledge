Catalog
Searching...
Plans
Paths
Courses
Lessons
# Explore the catalog
Search by keyword or filter for a curated view.
Shopify Developer
A Shopify Developer delivers Shopify Plus projects, from initial setup to merchant handover.
Developer
Track
Recently added
[Video] What is Shopify?
Learn how Shopify's unified commerce platform grows with every business. From first-time entrepreneurs to global enterprises, see how our features, integrations, and partner ecosystem help sell across every channel and solve commerce challenges.
2
Marketing
Admin
Video
Developer
Sales
Getting Started
[Video] Leading Total Cost of Ownership Discussions
Hear practical strategies for when and how to use TCO in your conversations with prospects, directly from Shopify's enterprise sales team.
8
Video
Video Series
Sales
Partner Program
[Video] Optimizing your Shopify Theme with PageSpeed
Discover why fast Shopify stores matter for both conversions and SEO. This video covers how to audit your Shopify store using tools like Google's PageSpeed Insights, understand core web vitals, and implement strategic improvements for faster load times and better SEO.
17
Video
Developer
[Video] Building Accessible Themes
Create inclusive Shopify experiences through accessibility best practices: semantic HTML, keyboard nav., and compliance standards.
15
Video
Developer
Creating an App for Shopify
Create a basic Shopify App from scratch that allows merchants to create and track issues for products within their Shopify admin.
FREE
25
Apps
Developers
Free
Developer
Custom Apps
Course
Recently added
Developing Apps for Shopify
Learn the essentials of Shopify app development, from building your first functional app to successfully launching on the Shopify App Store while meeting platform standards and enhancing merchant experiences.
FREE
5 Courses
Apps
Learning Path
Developers
Free
APIs
Developer
Custom Apps
Path
App Development Fundamentals
Learn the fundamentals of Shopify app development and how to extend the platform.
FREE
35
Apps
Developers
Free
Developer
Course
App Surfaces Examples
Discover how apps can extend Shopify's functionality across multiple surfaces.
FREE
30
Apps
Developers
Free
App Bridge
App Extensions
Developer
Custom Apps
Shopify CLI
Polaris
Course
[Video] Shopify Payments Architecture
Discover how Shopify Payments works as a four-layer system that helps you process, pay, protect, and grow your business.
2
Checkout
Video
Developer
POS
Solutions Architect
[Video] Setting Up Your Workflow for Theme Development
Develop Shopify themes confidently with proper workflows: local development, version control, and staging environments.
17
Video
Developer
Shopify Commerce Consultant
A Shopify Commerce Consultant expertly assesses prospects' needs, positions Shopify's unique strengths across diverse business models, and delivers compelling pitches that connect challenges to solutions, ultimately aligning our platform with merchants’ specific business objectives.
Sales
Track
Recently added
[Video] Optimizing Images for Themes
Improve Shopify store performance with image optimization: compression, Liquid filters, responsive images, and lazy loading.
14
Video
Developer
Getting Started
[Video] Making the Most of Payment Extensions
Learn how Shopify payment extensions expand your checkout options. Discover buy now pay later, local payments, subscriptions & crypto integrations that boost conversions and support global scaling with flexible, secure, centralized management.
3
Apps
Checkout
Video
Sales
Solutions Architect
[Video] How to Create a Development Store
Learn the differences between client transfer stores and test and build stores. Follow step-by-step setup instructions for both types through the Shopify Partner Dashboard, and discover when to use each store type for your specific development needs.
2
Video
Developer
Partner Program
Solutions Architect
Recently added
Shopify B2B: Foundations, Discovery and Solution Design
Build the expertise to engage, advise, and begin designing scalable B2B solutions for wholesale merchants on Shopify.
FREE
5 Courses
Learning Path
B2B
Free
Commercial
Sales
Solutions Architect
Path
Recently added
The B2B Commerce Landscape
Gain a foundational understanding of the B2B commerce landscape in order to effectively engage with wholesale clients.
35
B2B
Free
Course
Shopify Solutions Architect
A Shopify Solutions Architect uses a combination of technical and commerce knowledge to translate merchant needs into practical solutions, design and integrate technical architectures that solve problems, and bridge gaps between strategy and technology.
Track
[Video] Selling Shopify: The Demo
Learn how to deliver a compelling Shopify product demo that builds merchant confidence and drives deals forward. This series covers how to address integration complexity, empower creative control with low-code tools, and connect features to revenue growth. Watch now to learn how to structure your demo around merchant challenges and demonstrate clear business value.
10
Video
Video Series
Sales
[Video] Selling Shopify: Two Ways to Sell
Discover two powerful approaches to selling Shopify. Build independently with development stores for full project ownership, or collaborate with Shopify's sales resources for complex projects.
2
featured-video
resource-video
Video
Sales
Recently added
[Video] Shopify Integrations
Understand Shopify integration patterns, app architecture, and API connections for building connected commerce solutions.
8
featured-video
resource-video
Video
Shopify Flow Fundamentals: Building Powerful Automation for a Store
Learn about the Shopify Flow interface and its core components to build powerful automations that streamline an ecommerce business.
FREE
3 Courses
Learning Path
Shopify Flow
Automation
Path
[Video] Shopify Function Decision Framework
Learn how to quickly determine whether Shopify Functions are the right solution for a merchant's checkout customization, and when to use JavaScript or Rust to build it. This video walks through a practical decision tree you can use when planning solutions to assess whether the need truly belongs at checkout, how complex the business logic is, and whether it involves heavy computation.
4
Checkout
Video
Developer
Solutions Architect
[Video] Shopify Flow fundamentals
Learn about the Shopify Flow Fundamentals and how to build powerful automation for your store. You'll learn what Shopify Flow is and how to build your first flow with a pre-built template.
2
auto-registration
resource-video
Video
Video Series
Automation
Liquid Storefronts for Theme Developers
Learn how to use Liquid, Shopify's templating language, to optimize Shopify themes and deliver exceptional user experiences.
FREE
3 Courses
Learning Path
Storefronts
Developers
credentialed
Free
Liquid
Developer
Path
Search Engine Optimization with Shopify
Learn how to conduct a complete SEO audit to identify areas of opportunity including on-page and off-page improvements, keyword strategy, and addressing technical SEO issues.
FREE
7 Courses
Marketing
Learning Path
Paid
Analyze
Path
Recently added
[Video] The power of Shopify's new customer account extensibility
Discover Shopify’s customer account extensibility features. You'll explore benefits of the new system, learn to transition from legacy accounts, and use UI extensions and APIs for personalized experiences.
27
auto-registration
resource-video
Video
[Video] Learn Theme Customization With Theme Blocks
Join Educational Partner, Jan Frey, as he dives into theme blocks. You will learn to create custom, reusable theme blocks to capture virtually any look or functionality you can think of. Follow along with Jan as builds a custom "coffee strength" indicator, from storing custom data, to building a basic block, to styling the block and surfacing it in the right place.
10
Storefronts
featured-video
resource-video
Video
Video Series
Developer
Recently added
[Video] Peak season: Tips from experts
Hear directly from experts on how to maximize this year's peak season. These seasoned partners have successfully guided countless merchants through one of the most exhilarating and busy times of the year. Watch the series to learn their top tips and strategies.
12
Marketing
auto-registration
resource-video
Video
Video Series
Free
Navigating the Shopify Admin
Tour the Shopify admin with interactive demos and articles covering key features and tools.
FREE
20
Admin
Course
Getting Started
Create a Diagram for an Employee Stipend Program
Apply Shopify Extensions concepts in a practical workshop on checkout extensibility.
60
Checkout
Project
resource-project
Free
Solutions Architect
Activating Your Partnership
Learn actionable tips and best practices to successfully complete your letter of intent requirements and graduate into the Shopify Partner Program.
FREE
25
Partners
[Video] Get started with B2B on Shopify
Join fictional B2B merchants Zone Furnishings, Maison, and Home Haven as they discover how Shopify’s B2B features help improve their operations.
8
B2B
auto-registration
resource-video
Video
Free
Getting Started
[Video] Horizon Theme Demos for Merchants
Follow along with Nick, product manager at Shopify, as he walks through how to select and tailor the Horizon theme. Learn how to transform your store’s header, homepage, and footer. Get actionable insights to reflect your brand’s identity and enhance your online presence. Build flexible layouts from scratch, including how to how to build flexible layouts from scratch and utilize grouped blocks.
27
Storefronts
resource-video
Video
Video Series
Developer
Theme Architecture with Liquid for Developers
Explore Shopify's theme architecture from layout files to theme blocks.
FREE
45
Storefronts
Developer
[Video] The Shopify Partner Opportunity
Join Shopify Partner, Tidal Commerce, to discover how Shopify’s unique platform architecture provides a launchpad for growth. Gain an insider perspective on how agencies can innovate on the Shopify platform, while driving growth for clients.
3
resource-video
Video
Partner Program
[Video] Getting Started With Building on Shopify
Follow along with an applied framework that you can apply to your own business or clients.
9
Developers
auto-registration
resource-video
Video
Video Series
Free
Getting Started
Conversion Rate Optimization with Shopify
Learn how to effectively maximize your Shopify store's potential from applying CRO best practices to personalizing customer experiences.
FREE
4 Courses
Marketing
Learning Path
Path
[Video] Business Shipping Challenges: Mid-market & Enterprise Merchants
Follow along with real Shopify merchants and get a firsthand look at their shipping challenges. This series explores common shipping issues for both mid-market and enterprise businesses and how they overcome those obstacles.
4
auto-registration
resource-video
Video
Free
Shipping
Sales
[Video] Conversion Rate Optimization with Shopify
The video introduces Conversion Rate Optimization (CRO) as a vital tool for online stores, emphasizing its role in understanding consumer behavior on websites. It highlights how CRO can reveal effective strategies for product presentation. The content aims to assist Clone Station and Co in enhancing their business performance by leveraging these insights.
17
Marketing
resource-video
Video
[Video] Checkout Extensibility
Shopify offers a high-converting checkout, right out of the box. Some businesses have unique needs that require extending on top of native capabilities. In this series, you’ll learn about all the available technologies to offer a unique and customized Shopify checkout experience.
10
Checkout
auto-registration
resource-video
Video
Video Series
Free
Developer
[Video] Full Episode: How Shopify Partners Are Using Education to Succeed
In an industry that never stops changing, keeping up is key—join real Shopify Partners as they share how they stay ahead of the game by harnessing the educational  resources available on Shopify Academy.
43
resource-video
Video
[Video] International selling: Bathorium Case Study
Join Bathorium Founder, Greg MacDonald, as he breaks down how they approach selling into new international markets and leverage Shopify’s International Selling Tools.
10
Internationalization
auto-registration
resource-video
Video
Video Series
Free
[Video] How to find success with B2B on Shopify as a Shopify Partner
Discover why partners name Shopify as their top choice for building custom B2B experiences for clients.
5
B2B
auto-registration
resource-video
Video Series
[Article] Using AI in your SEO strategy
Use AI tools responsibly to help you be more efficient without hindering SEO ranking
5
Marketing
Article
resource-article
The Anatomy of a Shopify Flow Workflow
Learn the three essential components that power every Shopify Flow automation workflow.
FREE
30
Courses
Shopify Flow
Free
Automation
Setup
Course
[Video] Become a migration master: Accelerate the Thank You and Order Status Page upgrade
This webinar focused on the Thank You and Order Status page upgrade, highlighting efficient techniques for migrating a larger number of merchants. The session aimed to enhance technical skills, improve support for current clients, and identify opportunities to attract new business. It served as a guide for becoming a reliable partner for merchants in their Thank You and Order Status page upgrades.
60
Checkout
auto-registration
resource-video
Video
Free
[Video] Crafting Your Campaign
This video series outlines four key steps for creating a successful marketing campaign.
12
Marketing
auto-registration
resource-video
Video
Video Series
Free
[Article] Understanding the Competitive Landscape
Confidently address comparison questions and position Shopify's unique advantages against major competing platforms.
10
[Article] Using strategic promotions to drive sales and customer retention
Craft promotions that drive immediate sales and create lasting customer loyalty.
5
Marketing
auto-registration
Article
resource-article
Solutions Architect
B2B Foundational Features
Unpack the essentials of Shopify B2B store formats and features to confidently guide merchants on their wholesale journey.
30
B2B
Building B2B Solutions the Shopify Way
Learn to design, build, and support scalable B2B solutions on Shopify using built-in features and best practices.
FREE
30
B2B
Free
Course
[Video] Agency success: The foundations for scaling – Positioning, pipeline & pitching
In this session, Rachel, an experienced agency consultant, shares her insights on agency growth through effective positioning, pipeline management, and pitching strategies.
90
auto-registration
resource-video
Video
Sales
[Article] Shopify Collective: Getting started as a supplier
As a supplier with Shopify Collective, you can make your products available to other Shopify merchants to sell.
Article
resource-article
Recently added
[Article] Shopify Collective: Getting started as a retailer
As a retailer with Shopify Collective, you can connect with vetted suppliers to expand your product catalog - without purchasing any inventory upfront.
Article
resource-article
[Video] Shopify products marketing journey
Join Naomi, a newly hired e-commerce marketing manager, as she transforms her skincare brand's marketing strategy using Shopify's marketing tools. Discover how she boosts conversion rates through targeted ad campaigns, influencer collaborations, and automated email sequences, setting a new benchmark for success.
3
Marketing
auto-registration
resource-video
Video
Free
Understanding Conversion Rate Optimization
Use conversion rate optimization (CRO) to maximize a Shopify store’s potential.
35
Paid
Course
Analyze
Solutions Architect
[Video] Integrating an ERP system
In this video we’ll review a practical example of how integrating Shopify with an ERP system can enhance the efficiency of a particular task. Learn more about technical implementation planning as part of Shopify Academy’s Solution Planning Fundamentals learning path, plus earn your Shopify Verified Skill badge today.
3
auto-registration
resource-video
Video
Free
[Article] Selling fractional quantities
Learn how to enable fractional and non-traditional quantity sales in your Shopify store
5
auto-registration
Article
resource-article
[Article] Reframing Platform Fees with Total Cost of Ownership
Transform price objections into value conversations by revealing the true cost story behind platform decisions.
10
Researching Keywords for SEO
Discover keywords that will drive qualified traffic to your store and boost your search visibility.
20
Marketing
Putting Keywords to Work with On-Page SEO
Implement on-page SEO techniques specifically designed for Shopify stores to improve your search visibility and drive targeted traffic.
20
Marketing
[Article] Implementing file attachments with DropZone component
This article will guide you through the process of implementing file attachment functionality within Shopify’s Customer Account and Checkout UI extensions using the new DropZone UI component.
7
auto-registration
Article
resource-article
[Article] Conditional delivery instructions input
Read a real-world example that uses checkout UI extensions to provide a delivery instructions input at checkout.
6
Checkout
auto-registration
Article
resource-article
Free
Developer
[Video] Learn with Scott | Supercharge shopify development with AI
In this session, Scott Dixon, a partner solutions engineer at Shopify, discusses the transformative impact of AI on web development, particularly within the Shopify ecosystem. The session includes practical demonstrations of using AI for tasks such as building a spend bar and optimizing store performance. Ultimately, Scott encourages developers to embrace AI as a powerful ally in their work.
40
Developers
auto-registration
resource-video
Video
Free
Developer
[Video] Agency success with scalable systems: Projects, people, process & profit
In the second session on agency success, Rachel, a recognized authority in scaling e-commerce agencies, shares her insights on creating scalable systems. She emphasizes the importance of project management, profitability, and effective team structures, highlighting the need for clear communication and accountability.
90
auto-registration
resource-video
Video
[Article] Building customer loyalty programs
Learn about the many ways to design and implement effective loyalty programs that transform one-time buyers into dedicated brand advocates and drive sustainable business growth.
5
Marketing
auto-registration
Article
resource-article
Getting Started with Liquid for Developers
Build dynamic Shopify themes with Liquid templating.
45
Storefronts
Developers
Free
Liquid
Themes
Developer
Course
Getting Started
[Article] Building a store finder
Surface physical locations and build a store finder on your Shopify store
Article
[Video] Development workflows: Partner webinar
This webinar provides an overview of Shopify deployment methods, covering general setup best practices, staging and testing, optimizing performance, the process of pushing changes and feature updates to production, and the differences between Headed Development and Headless Development.
60
auto-registration
resource-video
Video
Developer
[Video] Shopify Subscriptions
Find out how to set up subscriptions, pick the best model for your clients, avoid common mistakes, and deliver lasting value.
10
featured-video
resource-video
Video
Solutions Architect
Recently added
Analyzing a Business
Explore how to analyze a business when planning new software or technology implementations.
60
Courses
Partners
Platform
Free
Course
Visualizing Technical Solutions for Shopify
Build an implementation plan based on a business’s needs.
FREE
60
Courses
Partners
Platform
Solutions Architect
[Video] Navigating a Volatile Macroeconomic Backdrop
Join Alison Collins and Jessica Ramirez, co-founders of the Consumer Collective, as they unpack how inflation and tariffs are shaping today’s shopping habits.
40
resource-video
Video
[Video] Riess Group: Adding POS to your partner portfolio
Watch now to hear how the Riess Group transformed their partner portfolio with Shopify Point of Sale.
9
Point of Sale
resource-video
Video
Video Series
[Article] Built for Shopify Standards
Understand the Built for Shopify Standards and their importance for app development.
6
Article
resource-article
Developer
Outbound Sales Strategies for Shopify Partners
Learn how to build a reliable outbound sales engine and take control of your client pipeline.
FREE
90
Partners
Free
Course
Sales
[Video] The Pathways Podcast: Leading with Checkout
Join our Shopify team to discuss how Partners and Business Consultants are able to lead with checkout when pitching and selling Shopify to new prospective brands.
30
Checkout
Webinar
auto-registration
resource-video
Video
Free
[Video] Surfaces to create apps for
You can create public apps to list on the Shopify App Store, or create custom ones for a single merchant. Apps interact with different areas of the shop by platform and extend its functionality.
4
Apps
Developers
auto-registration
resource-video
Video
Free
Developer
Developing Solutions with Shopify Customer Account Extensions
Build expertise in extending customer account functionality and capabilities for enhanced user experiences.
FREE
Developer
Course
Solutions Architect
[Video] Building a Custom Workflow With Shopify Flow
Build a powerful custom workflow in Shopify Flow to automatically add a special welcome gift for customers who place their first order.
15
auto-registration
resource-video
Video
Automation
Solutions Architect
Liquid Optimization for Performance
Optimize Liquid theme performance using diagnostic tools like Theme Check.
30
Storefronts
Developer
Customizing Themes
Customize Shopify themes through hands-on practice with structure, editing, and code.
FREE
120
Courses
Storefronts
Developers
Free
Themes
Developer
Course
Lab
[Video] Storefront Web Components
You’ll learn how to turn any website into a shoppable storefront using Storefront Web Components. Explore live coding, custom elements, and AI-powered tools to enhance your online store.
37
Storefronts
resource-video
Video
[Video] Learn with Darryn | Internationalisation + Markets
The video discusses the importance of international expansion for e-commerce. It emphasizes the need for businesses to manage unique catalogs, currencies, and inventory across different markets, with Shopify providing tools to simplify this process. The video also touches on the significance of choosing the right domain strategy and managing multiple business entities for successful internationalization.
35
Internationalization
auto-registration
resource-video
Video
Free
[Video] Checkout: New discount functions
Discover how to customize your Shopify checkout and add powerful Discount Functions. Learn practical strategies to migrate smoothly, boost performance, and scale your business—especially during high-traffic sales events.
25
Checkout
Webinar
auto-registration
resource-video
Video
Developer
Solutions Architect
[Video] Shopify Admin Guided Tour
Build your unique online store with customizable themes, AI tools, and your own domain. Learn to add products, set up payments and shipping, and use Shopify Sidekick for extra support. Get ready to launch and grow your business with confidence!
12
Admin
resource-video
Video Series
Getting Started
Choosing the Right Shopify Functions Strategy: Rust, JavaScript, and Alternatives
Assess when to use Shopify Functions and guide teams to successful implementations.
FREE
Course
Solutions Architect
Removing Barriers to Search Performance with Technical SEO
Build the technical framework search engines reward with better rankings.
20
Marketing
Building Your Store's Authority with Off-Page SEO
Learn how off-page SEO and link building can boost your store's authority and search engine rankings.
20
Marketing
Paid
Course
Analyze
[Video] Building Your SEO Strategy
See how each stage of your SEO strategy work together to help customers find your products when searching online, increasing organic traffic and sales.
43
Marketing
resource-video
Video
[Video] Unlock Growth Potential: How Shopify Payments Supercharges Revenue (EMEA)
In this session, Shopify experts share how agency teams can drive more revenue and higher conversion across their merchant portfolios using Shopify Payments. Topics include built-in conversion and fraud tools, global scalability, and merchant-friendly pricing, followed by a live Q&A. Watch to learn how Shopify Payments can help your agency close more deals and deliver greater value to clients.
55
resource-video
Video
Building a Workflow with Shopify Flow
Build custom Shopify Flow workflows using a proven framework with hands-on practice and real-world examples.
FREE
45
Courses
Shopify Flow
Free
Automation
Course
Shopify B2B: Launch and Customization
Learn how to start selling wholesale by setting up and customizing B2B features in a Shopify store.
FREE
3 Courses
Learning Path
B2B
Platform
Free
Path
B2B Positioning and Pricing
Learn how to match B2B merchant types to Shopify’s B2B solutions and clearly communicate value and pricing to prospective clients.
30
B2B
Sales
B2B Discovery
Learn a proven framework to assess B2B clients, spot complexity early, and determine if Shopify is the right fit for their needs.
20
B2B
Free
Course
Sales
[Video] Partner solutions: Combined Listings
In this webinar, Senior Partner Solutions Engineer Kevin Horner and special guests Wes Baker and Gemma Curl from the Shopify Combined Listings product management and development team discuss the fundamentals of the Shopify Combined Listings app. Learn how to boost conversions for merchant clients by effectively managing product models and enhancing SEO.
19
Webinar
auto-registration
resource-video
Video
The Shopify Agency Growth Framework
Learn proven, step-by-step strategies to build, scale, and sustain a thriving agency. Discover how to position your business, generate leads, pitch with confidence, deliver projects profitably, and build a high-performing team.
FREE
90
Partners
Partner Program
Recently added
Shopify POS Launch and Operations
Learn about Shopify POS launch and operations to effectively set up and manage hardware, train staff, execute operations, and optimize growth for seamless business operations.
FREE
5 Courses
Point of Sale
Learning Path
Retail
Platform
credentialed
Free
POS
Path
CRO Implementation and Testing
Learn how to apply testing methodologies to create data-driven improvements that will help increase your conversion rates.
45
Marketing
Paid
Course
Analyze
CRO Targeting and Personalization
Learn how to improve conversion rates by personalizing the customer experience using techniques such as customized landing pages and targeted messaging.
45
Marketing
Paid
Course
Analyze
Converting Site Visitors to First-Time Buyers
Learn about some of the specific challenges associated with getting potential customers to convert to first-time buyers
45
Marketing
Free
Course
[Video] Building with POS UI Extensions: Marsello
Join Brady, co-founder and Chief Product Officer at Marsello, as he shares how their app seamlessly connects online and in-store loyalty using Shopify’s POS UI Extensions. Plus, get insider tips on innovating with new Shopify technologies.
8
Point of Sale
auto-registration
resource-video
Video
Developer
Shopify Development Fundamentals
Learn Shopify's framework and the necessary steps to start developing on Shopify’s platform.
FREE
4 Courses
Learning Path
Fundamentals
Free
Developer
[Video] Building with POS UI Extensions: Zapiet
Join Andy, founder of the popular POS apps Zapiet and Zapiet Eats, as he dives into their approach to app development using Shopify's POS UI Extensions. Plus, discover insider tips on developing apps with POS UI Extensions.
8
Point of Sale
auto-registration
resource-video
Video
Developer
[Video] Working with Graph QL on Shopify
This video series introduces the basic concepts of GraphQL to help developers think about finding and working with data in Shopify differently from REST API.
7
auto-registration
resource-video
Video
[Video] Getting started with POS UI Extensions: Demo
A concise walkthrough on generating and previewing a POS UI extension using the Shopify CLI tool. The process includes generating a template for the extension, configuring it through a toml file, and starting a development server to preview the extension.
4
Point of Sale
auto-registration
resource-video
Video
Developer
Introduction to Shopify
Get to know Shopify: our mission, core features of the platform, and how we help businesses of all sizes start, run, and grow.
FREE
20
Partners
Platform
Free
Course
Partner Program
Getting Started
Marketing Fundamentals
Learn how to optimize your use of Shopify’s marketing tools and products to expand your customer base, increase sales, and grow your business.
FREE
4 Courses
Marketing
Learning Path
credentialed
Free
Path
Selling and Positioning Shopify Marketing Products
This learning path empowers Shopify partners to understand the full spectrum of Shopify's marketing products.
FREE
2 Courses
Partners
Learning Path
Selling Shopify
credentialed
Free
Commercial
Sales
Path
Customizing the POS Experience
Learn how to design and implement personalized solutions for a business's needs using POS UI extensions.
FREE
3 Courses
Point of Sale
Learning Path
Retail
Developers
Free
App Extensions
Developer
Path
Creating a Digital Marketing Strategy
From unified commerce foundations to strategic seasonal campaigns, learn the essentials of marketing with Shopify to build your brand, engage your audience, and drive conversions.
FREE
6 Courses
Marketing
Learning Path
Free
Getting Started
Path
Expanding Your Shopify Business Internationally
Learn to guide your business through the key steps of an international expansion.
FREE
7 Courses
Internationalization
Learning Path
Free
Path
Introduction to POS UI Extensions
Learn how to take advantage of POS UI extensions by exploring practical applications, learning to navigate developer documentation, and gaining hands-on experience in creating innovative extensions.
FREE
40
Point of Sale
Retail
Developers
Developer
Solutioning with POS UI Extensions
Learn how to develop tailored solutions using POS UI extensions to address specific business challenges.
25
Point of Sale
Retail
Developers
Developer
Building Custom POS Interfaces with UI Extensions
Learn how to design and develop custom POS interfaces by engaging in comprehensive, hands-on practice with UI extensions.
45
Point of Sale
Retail
Developers
Free
App Extensions
Developer
Course
Expanding Your Developer Toolkit
This course will introduce you to more advanced or multi-function tools, commerce-pillar specific extensions, and cover how to stay up to date on product changes relevant to developers.
20
Developer
Foundations of Unified Commerce Marketing
Gain a foundational understanding of unified commerce by exploring its key components, sales channels, and performance metrics in this course.
60
Marketing
Digital Marketing Essentials
Learn how to create effective digital marketing strategies that drive customer engagement, increase conversions, and build long-term loyalty through optimized content, email, and SMS campaigns.
65
Marketing
Free
Setup
Course
Branding, Positioning, and Building an Effective Online Presence
Learn to create a powerful brand identity that resonates with your audience by defining your mission, vision, and values while crafting unique value propositions and engaging storytelling.
45
Marketing
Platform
Free
Setup
Course
Social Media and Content Marketing
Discover effective strategies for leveraging social media and content marketing to enhance your brand's presence and foster business growth through a well-structured content calendar.
80
Marketing
Free
Setup
Course
[Video] Packaging 101 with Arka
Discover the best practices for packaging products to make success-oriented decisions.
20
auto-registration
resource-video
Video
Video Series
Influencer and Affiliate Marketing
Explore the essentials of influencer and affiliate marketing to grow your business by identifying suitable influencers, building strong partnerships, and utilizing performance-based strategies.
30
Marketing
Paid
Setup
Course
Seasonal and Event-Based Marketing
Learn to create a holiday-specific marketing strategy that resonates with your audience by tailoring campaigns to each holiday's unique themes and understanding the psychological triggers of urgency and scarcity.
FREE
30
Marketing
Free
Course
[Article] Adding a product in the Shopify admin
Add products to your online or retail store with the Shopify Admin.
8
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
Getting Started
[Article] Why automation is essential for ecommerce
Understand how ecommerce automation and Shopify Flow streamline operations, reduce manual work, and create room for growth.
8
auto-registration
Article
resource-article
Automation
[Article] Gift cards in the Shopify admin
Gift cards can be added to your store from the admin just like any other product, providing a convenient option for your customers to share their enthusiasm for your brand with friends and family.
4
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
Aligning Shopify Marketing Products to the Customer Life Cycle
Explore how Shopify’s marketing products help you find new customers and grow your business
FREE
45
Marketing
Free
Course
Finding New Customers with Shopify
Focus on how Shopify's marketing tools can simplify the complexity of finding new customers, building brand awareness, and targeting quality leads
FREE
45
Marketing
Free
Course
Analyze
Staying Engaged with Customers to Boost LTV
Leverage Shopify's email solutions, marketing tools, and automations to maintain engagement, identify high-value customer segments, and enhance retargeting strategies to boost customer lifetime value and loyalty.
20
Marketing
Free
Setup
Course
Customizing the Appearance of Shopify Checkout
Add visual design elements to your checkout with the checkout and accounts editor and Checkout Branding API.
FREE
25
Checkout
Platform
Free
Developer
Course
Solutions Architect
Creating Solutions for Shopify Checkout
Learn what’s possible with customizing checkout beyond what’s available out-of-the-box.
FREE
7 Courses
Learning Path
Checkout
Free
Developer
Technical
Solutions Architect
Path
Getting Started with International Selling
Dive into the fundamentals of international selling and discover global market opportunities.
25
Internationalization
Free
Setup
Course
Researching Your International Target Market
Learn how to identify market demand when selling to a new region.
FREE
20
Internationalization
Free
Course
Analyze
Analyzing the International Competitive Landscape
Explore how to assess international competition when entering a new market.
FREE
25
Internationalization
Platform
Free
Course
Analyze
Developing Your International Go-to-Market Strategy
Explore how to set goals and make a plan for international expansion.
20
Internationalization
Marketing
Free
Setup
Course
Localization Strategies
Learn how to make your brand feel like it belongs across borders.
25
Internationalization
Free
Setup
Course
Pricing Your Products When Selling Cross-Border
Discover how to manage pricing and payments when selling to international customers.
15
Internationalization
Free
Setup
Course
Shipping Products Internationally
Explore how to select the right shipping strategies when fulfilling international orders.
20
Free
Shipping
Setup
Course
Analyzing Conversion Rate Optimization
Analyze your Shopify store using reports and create a CRO roadmap.
45
Marketing
Paid
Course
Analyze
Solutions Architect
Positioning International Selling with Shopify
Learn how Shopify supports international selling and how you can identify and align the right merchant with the right solution.
FREE
2 Courses
Internationalization
Partners
Learning Path
Selling Shopify
credentialed
Free
Commercial
Sales
Path
[Article] Adding web pixels
Learn how web pixels track user behavior and explore the two types of pixels you can set up on Shopify.
Marketing
Checkout
auto-registration
Article
resource-article
Free
[Article] Adjust prices with Shopify Functions and Checkout UI Extensions
Read a real-world example that uses Checkout UI extensions and Shopify Functions to adjust pricing in the cart.
11
Checkout
auto-registration
Article
resource-article
Free
Developer
Solutions Architect
[Article] Auditing SEO performance
Implement regular SEO audits to measure performance, identify opportunities, and maintain visibility in search results.
5
Marketing
Article
resource-article
[Article] Benefits of the Shopify Partner Program
Evaluate the key business development, education, and marketing advantages of partnering with Shopify.
5
Partners
Article
resource-article
Partner Program
[Article] Building Your SEO Strategy
Create an effective search optimization strategy tailored to your business stage, from new brands to established companies.
5
Marketing
Article
resource-article
[Article] Creating variants in the Shopify admin
Add variants and collections using the Shopify admin.
6
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
[Article] Creating metaobjects and metafields in the Shopify admin
Learn to create metaobjects and use metafields to customize product information in your Shopify store.
5
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
[Article] Creating a draft order in the Shopify admin
Discover how to create and manage draft orders and send invoices to customers.
4
Platform
Admin
auto-registration
Article
resource-article
Free
[Article] Driving sales with smart product recommendations
5
auto-registration
Article
resource-article
[Article] Introduction to Shopify’s development resources
Learn about the tools and resources available to you as a Shopify developer.
8
auto-registration
Article
resource-article
Free
Developer
Getting Started
[Article] Managing inventory in the Shopify admin
Whether you're receiving new stock, conducting an inventory audit, or holding inventory for an upcoming product launch, you can efficiently manage your inventory for all your locations from the Shopify admin.
4
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
[Article] Managing your Shopify pipeline as a partner
Learn how to qualify, submit, and manage Shopify leads to maximize your success in the Shopify ecosystem.
8
auto-registration
Article
resource-article
Free
Partner
Sales
[Article] Navigating the Shopify Partner ecosystem
Understand the tools and resources in the Shopify Partner ecosystem and how to use them to succeed.
8
auto-registration
Article
resource-article
Free
Partner
Partner Program
[Article] Pitching retainers effectively
Learn how to pitch retainers effectively to your clients.
Article
resource-article
Sales
[Article] Publishing to the Shopify App Store
Learn what to consider and prepare before submitting your app to the Shopify App Store.
4
Apps
Article
resource-article
Developer
[Article] Service Partner Program Requirements
Understand the Commercial Impact and Credential Attainment required to progress through the Service Partner program.
5
Article
resource-article
Partner Program
[Article] Setting up role-based access controls in the Shopify admin
Discover how to manage user permissions using role-based access controls in the Shopify admin.
4
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
[Article] Setting up sales channels for social media in the Shopify admin
Learn how to reach more customers by adding social media sales channels to your store.
4
Marketing
Platform
Admin
auto-registration
Article
resource-article
Free
Setup
[Article] Shopify Integrations Explained: Tools and Tactics for a Smarter Store
This article covers Shopify's architecture, key integration methods (Webhooks, APIs), data models, and various solutions for optimizing store functionality and performance
4
integrations
architecture
article
[Article] Shopify Partner Program overview
Learn about the Shopify Partner Program for Service and Technology partners and how each type of partner supports merchants throughout their journey, providing diverse opportunities to earn. Discover how Shopify's Service and Technology Partners deliver unique value to merchants.
5
Partners
Article
resource-article
Partner Program
Marketing Your Shopify Services as a Partner
Unlock the full potential of marketing your Shopify offerings
FREE
45
Partners
Sales
Partner Program
[Video] Selling Shopify: The Pitch
Learn how to craft a winning Shopify value pitch that drives sales momentum. This series covers how to frame the challenge, why Shopify is different and how Shopify delivers value. Watch now to learn how to tailor your pitch with details about a prospects GMV, complexity and pain points.
15
auto-registration
resource-video
Video
Video Series
Free
commercial
Sales
[Video] Selling Shopify: Merchant Prospecting
Learn how to determine merchant fit, lead effective discovery, and prepare to handle some of the most common objections. This series explores three different market segments: Mid market, Large account, and Enterprise. Watch now to learn more about evaluating prospects, identify merchant challenges and priorities, and predict common objections.
12
auto-registration
resource-video
Video
Video Series
Free
commercial
Sales
[Video] POS: Solution Based Selling
Walk through an applied scenario to understand product positioning for Shopify POS and create tailored solutions to meet merchant needs for successful retail operations.
9
Point of Sale
resource-video
Video
Video Series
Sales
Selling Shopify
Optimize your Shopify sales approach to boost earnings, strengthen merchant relationships, and grow as a partner.
FREE
60
Courses
Partners
Selling Shopify
Sales
Solution Planning Fundamentals
Learn how to analyze, visualize, and plan technical implementations with Shopify.
FREE
3 Courses
Partners
Learning Path
Platform
credentialed
Free
Solutions Architect
Path
[Video] Shorts: How Shopify Partners Are Using Education to Succeed
In an industry that never stops changing, keeping up is key—join real Shopify Partners as they share how they stay ahead of the game by harnessing the educational  resources available on Shopify Academy.
9
resource-video
Video Series
Using the Partner Dashboard
Learn about the Partner Dashboard so you can effectively collaborate with merchants and Shopify.
FREE
15
Partners
Partner Program
[Article] What is Shopify Collective
Shopify Collective, the game-changer that lets you grow your business without the typical growing pains.
Article
resource-article
[Article] Retainers for Shopify Partners
Create retainer models to secure long-term relationships with your clients.
Article
resource-article
[Article] Shopify Analytics: From data to decisions
Answer key business questions and measure your success with Shopify Analytics.
Article
resource-article
[Article] Strategies to accelerate the sales cycle as a partner
Learn how to build a sustainable pipeline by focusing on different strategies to engage with prospects at the top, middle, and bottom of the funnel.
8
auto-registration
Article
resource-article
Free
Partner
Sales
[Video] Shopify Admin Essentials: A Day With Kaycee
Join Kaycee as she walks you through how she uses the Shopify admin in her day-to-day work. She oversees shipping and fulfillment, rotating products, and ensuring a seamless shopping experience for customers. Because the Shopify admin is the central hub for managing a business, she will be spending lots of time there. Join us as Kaycee takes you on a guided tour of the Shopify admin.
3
Admin
auto-registration
resource-video
Video
Free
[Video] Why unified commerce?
Physical retail is back! In store and online are now effectively one continuous experience and no longer separate lanes of business. Watch to learn more about how Shopify empowers you to make a seamless shopping experience for your customers with Unified Commerce.
4
auto-registration
resource-video
Video
Free
Working with Merchants
Be prepared to work with Shopify merchants of all types.
30
Partners
Partner Program
[Video] Shopify Apps and Integrations
Explore Shopify integrations, including various types like pre-built and custom solutions, as well as how they optimize Shopify stores for efficiency and enhanced customer experience.
4
Apps
resource-video
Video
integrations
Building Backend Logic for Shopify Checkout
Extend your Shopify store's checkout capabilities by mastering metafields and Shopify Functions.
FREE
30
Checkout
Discount
Functions
Metafields
Free
App Extensions
Developer
Course
Shopify Functions
Build a Custom Storefront with Hydrogen
Discover how to build essential ecommerce storefront pages using Hydrogen and the Mock.shop API.
60
Storefronts
Developers
Crafting a Tailored Discovery Approach
Learn how to ask the right questions that uncover merchant needs and position Shopify as their perfect solution.
FREE
20
Craft the POS Solution
Learn to craft a solution that meets merchant needs and sets them up for continued success.
FREE
60
Courses
Partners
Point of Sale
Retail
Communicating Shopify Plus Value
Translate Plus features into compelling business outcomes that justify the investment.
FREE
20
Sales
Customizing Business Logic with Shopify Functions
Use Shopify Functions to apply unique business processes to checkout.
FREE
30
Checkout
B2B
Platform
Free
Course
Solutions Architect
Deciding on Your B2B Store Format
Learn about the two B2B storefront formats available on Shopify, and how to choose the right setup for specific business needs.
30
B2B
Platform
Free
Setup
Course
Developing on Shopify
Get started on your journey developing on Shopify.
FREE
60
Courses
Developers
Developer
Course
Solutions Architect
Enhancing Checkout with UI Extensions
Discover how UI extensions create unique shopping experiences in the checkout.
25
Checkout
Platform
Free
Developer
Course
Extend
Solutions Architect
Exploring and Extending Shopify’s Data Model
Explore Shopify's data model and learn to extend it with metafields and metaobjects for custom data storage.
FREE
90
Courses
Developers
Developer
Solutions Architect
Exploring Checkout Extensibility for Advanced Customization Needs
Learn how to position Checkout Extensibility features to merchant goals
20
Partners
Checkout
Developer
Extending Checkout with the Checkout Blocks App
Tailor your checkout experience with Checkout Blocks.
FREE
30
Checkout
Platform
Free
Developer
Course
Extend
Solutions Architect
Fulfillment and Order Routing
Examine factors to decide which fulfillment methods to offer for your products and orders
30
Free
Shipping
Course
Analyze
Getting Started on Shopify Plus
Learn about Shopify Plus exclusive features, education and community resources.
FREE
30
Plus
Partners
Platform
Getting Started
Getting Started with Selling Shopify Retail
This course will teach you how to talk about Shopify POS’s features and benefits to retail merchants.
FREE
30
Partners
Point of Sale
Retail
Platform
Sales
Identifying Features that Customize Shopify Checkout
Learn use cases and features of checkout customization technologies.
FREE
45
Checkout
Platform
Free
Developer
Course
Extend
Solutions Architect
Identifying Fit for Shopify Checkout
Explore Shopify Checkout’s features and benefits to identify merchant fit
FREE
15
Partners
Integrating with Shopify
Develop expertise in the fundamentals of backend development with Shopify's APIs, webhooks, GraphQL, and app ecosystem.
FREE
120
Courses
Developers
Developer
Introduction to International Selling with Shopify
Explore the many features and benefits available to Shopify merchants with international selling tools and Managed Markets.
FREE
30
Partners
Introduction to Shipping & Fulfillment with Shopify
Gain a comprehensive understanding of Shopify’s shipping and fulfillment tools.
FREE
30
Free
Shipping
Setup
Course
Introduction to Shopify Liquid
Learn Shopify theme development basics: choosing, installing, customizing themes, and making minor code changes.
FREE
30
Storefronts
Developer
Course
Solutions Architect
Introduction to Storefronts
Discover the four different storefronts that all work seamlessly with and within the Shopify platform.
FREE
20
Storefronts
Developers
Solutions Architect
Introduction to Shopify’s Marketing Products
Explore tools and strategies Shopify Partners can use to enhance merchant marketing programs.
FREE
15
Partners
Solutions Architect
Mastering the Art of Positioning Shopify Checkout
Learn how to promote Shopify Checkout to prospective brands
FREE
40
Partners
Sales
Optimization and Growth with POS
Explore advanced strategies to optimize operations and drive business growth with Shopify POS.
FREE
60
Point of Sale
Retail
Platform
Free
Course
Analyze
Extend
POS
Perfecting Your Shopify Pitch
Craft compelling pitches that turn prospects into customers.
FREE
60
Courses
Partners
Selling Shopify
Sales
Personalizing the B2B Buying Experience
Learn how to create a personalized buying experience for wholesale customers.
30
B2B
Platform
Free
Setup
Course
Pitch to Win for POS
Learn how to identify retail opportunities and craft a winning pitch.
FREE
30
Courses
Partners
Point of Sale
Retail
Sales
POS Hardware and Payments
Optimize the customer experience in your retail store through innovative hardware and payments solutions.
FREE
60
Point of Sale
Retail
Platform
Free
Setup
Course
POS
POS Operations
Discover how to streamline your business operations and focus on business growth with Shopify POS.
FREE
50
Point of Sale
Retail
Platform
Free
Setup
Course
POS
POS Setup and Configuration
Learn the foundational steps for selling in person with Shopify POS, including secure data migration, Shopify admin setup, app installation and configuration, and effective issue troubleshooting.
FREE
35
Point of Sale
Retail
Platform
Free
Setup
Course
POS
Positioning Business Growth with Marketing Products
This course will demonstrate how to introduce, position, and sell Shopify’s marketing products to merchants based on their needs and goals.
FREE
30
Partners
Sales
Positioning International Selling Tools & Managed Markets
Learn how to address common merchant challenges and discover how Shopify helps merchants expand and grow across borders.
FREE
60
Partners
Sales
Positioning the Shopify Advantage
Learn how to position Shopify as the preferred commerce platform for prospective merchants.
FREE
60
Courses
Partners
Selling Shopify
Positioning the value of Shopify Checkout
Learn how to pitch and position Shopify Checkout and checkout extension features to prospective and existing merchants.
FREE
3 Courses
Learning Path
credentialed
Free
Commercial
Sales
Product Positioning for POS
Gain the product knowledge you need to position Shopify POS as a key part of a unified commerce approach.
FREE
40
Courses
Partners
Point of Sale
Retail
Sales
Prospecting For High Value Opportunities
Find and qualify prospective clients who will thrive on Shopify.
FREE
20
Sales Prospecting and Discovery
Learn how to determine merchant fit, lead effective discovery, and prepare to handle some of the most common objections.
60
Courses
Partners
Sales
Selling Shopify Fundamentals
Learn how to effectively co-sell with Shopify teams from efficient prospect discovery to delivering a winning pitch.
FREE
4 Courses
Partners
Learning Path
credentialed
Free
Commercial
Sales
Path
Shipping Settings and Strategies
Learn how to align business goals to fulfillment strategies
60
Free
Shipping
Setup
Course
Shipping and Fulfillment Fundamentals
Learn the art of configuring and optimizing shipping settings and strategies in Shopify to enhance operational efficiency and customer satisfaction.
FREE
3 Courses
Learning Path
style-general-assessments
Free
Shipping
Path
Setting up a B2B Store
Learn how to implement key B2B on Shopify features, including: companies, locations, catalogs, sales staff, and themes.
FREE
30
B2B
Platform
Free
Setup
Course
Shopify Admin Guided Tour
In this course we’ll explore the different parts of the Shopify Admin, and how Sidekick, Shopify’s built-in AI assistant, can help you on your journey creating your first Shopify Store.
FREE
Admin
Solution-Based Selling with Shopify POS
Learn ways to partner with Shopify as well as how to understand product positioning for Shopify POS.
FREE
4 Courses
Point of Sale
Learning Path
Retail
credentialed
Free
Commercial
POS
Sales
Solutions Architect
Recently added
Storefront API Customization
Understand the purpose, structure, and capabilities of the Storefront API.
60
Storefronts
Developers
Technical Implementation Planning
Accounting for technical considerations when planning implementation with Shopify.
60
Courses
Partners
Platform
Solutions Architect
Understanding Shopify Sales Tax Configuration
Learn to evaluate and configure Shopify tax systems and match merchants with the right solution for their business.
FREE
30
Course
Solutions Architect
Turning Objections into Opportunities
Navigate objections to build stronger, more confident customer relationships.
FREE
45
Training and Managing Staff for POS
Enhance your skills in training and managing employees effectively with Shopify POS, focusing on onboarding, continuous improvement training, and using roles and permissions.
20
Point of Sale
Retail
Platform
Free
Course
POS
[Article] B2B Quantity Rules
Learn how to set up and optimize quantity rules for B2B buyers in Shopify.
15
B2B
auto-registration
Article
resource-article
Free
[Article] B2B Volume Pricing
Learn to design and launch tailored B2B volume pricing using Shopify’s native features.
15
B2B
auto-registration
Article
resource-article
Free
[Article] Configuring B2B Quick Order Lists
Learn to configure and optimize Quick order lists in Shopify to streamline bulk procurement for B2B buyers.
15
B2B
auto-registration
Article
resource-article
Free
[Article] B2B Quoting Workflows
Learn how to set up, manage, and optimize quoting workflows for B2B buyers in Shopify, from native features to advanced solutions.
15
B2B
Admin
auto-registration
Article
resource-article
Free
[Separator] Grow with Shopify POS
Learn how to grow as a Shopify Partner, with Shopify POS
FREE
separator
[External Resource] Pitching Shopify POS
Watch this 3 minute video to see an example of how to pitch Shopify POS, as a Partner.
FREE
External Resource
auto-registration
hide-search
Strategic Merchandising for Ecommerce
Transform online stores into sales engines with merchandising techniques that increase conversions, order value, and trust.
45
Marketing
Course
Commerce Models on Shopify
Explore diverse commerce models to build successful strategies across any business type.
15
Course
[Separator] Commerce and the competitive landscape
Build your expertise in competitive positioning, diverse commerce models—from direct-to-consumer (DTC) and business-to-business (B2B) to retail and unified commerce—and merchandising strategies to guide clients through complex, multi-channel opportunities.
FREE
separator
Merchandising with Bundles
Scope, price, and implement bundles on Shopify so they drive revenue without creating inventory and catalog chaos.
FREE
Course
Solutions Architect
Advanced App Development
Develop integrated Shopify apps using advanced techniques for custom functionality and merchant solutions.
FREE
Developer
Course
Create a Solution for Shopify Plus
Build growth-ready Shopify Plus solutions, from global expansion to customer segmentation and fulfillment.
FREE
Project
Solutions Architect
Checkout and Cart Validation with Shopify Functions
Enforce cart and checkout rules server‑side with Shopify Functions so merchants can block invalid orders instead of just warning customers.
FREE
Course
Solutions Architect
Shopify Payments Fundamentals
Get an overview of Shopify Payments, processors, and providers so you can design secure, high‑performing payment solutions on Shopify.
FREE
Course
Solutions Architect
Site Audit Walkthrough
Walk through an 8 minute site audit of the 6 key areas to focus on when optimizing your ecommerce site for conversion.
FREE
10
Store Design
Partners
Platform
Shopify B2B: Launch and Customization Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Shopify B2B: Launch and Customization learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$149
40
Exam
B2B
AI_PROCTORED
Verified Skills
Badge
link_retake_3bz4ngp3wle03
link_1hidk5expxuyq
Standard
TikTok x Cheekbone Beauty Case Study: Optimizing Paid Campaigns on TikTok
Follow along with Plus merchant, Cheekbone Beauty, as the TikTok Creative Team conducts an audit of their current TikTok strategy.
FREE
40 min
Partners
Marketing
Platform
How to Increase Customer Conversions with Shopify POS
5 features a retailer may want to use to increase their efficiency and in-store conversion.
FREE
40
Point of Sale
Retail
Platform
Free
Course
Analyze
POS
Building Interactive Cart Operations in Themes
Build interactive shopping carts using Shopify's lightweight AJAX API.
FREE
60
Article
APIs
Cart
[Separator] Shopify platform foundations
Establish foundational expertise in Shopify's platform capabilities, admin tools, strategic positioning, and extensibility features to confidently guide prospects from initial assessment through customized implementations.
FREE
separator
layout--track-template
[Separator] Shopify Plus features
Navigate the complexities of launching Shopify Plus projects with confidence. Gain essential knowledge of launch-critical tools, APIs, and automation workflows, including Shopify Flow, to streamline deployment and deliver efficient, high-impact solutions.
FREE
separator
[Separator] Shopify platform foundations
Establish foundational expertise in Shopify's platform capabilities, developer environments, tools, resources, and Admin configuration options.
FREE
separator
layout--track-template
Positioning the Value of Shopify Checkout Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Positioning the Value of Shopify Checkout learning path content.
$149
Partners
Exam
Checkout
AI_PROCTORED
Verified Skills
Badge
Selling Shopify
Consulting
link_39te4dbsjvok5
link_retake_1wb8oh18zjtb9
Standard
Developing Apps for Shopify Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Developing Apps for Shopify learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$249
35
Apps
Exam
AI_PROCTORED
Verified Skills
Badge
Developers
Advanced
APIs
App Bridge
App Extensions
[Separator] Leading the sales motion
Guide sales conversations through prospecting, tailored discovery, strategic plan recommendations, and value-based pricing discussions. Learn to navigate Shopify's sales model and build sustainable client relationships that drive long-term growth.
FREE
separator
Marketing Fundamentals Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Marketing Fundamentals learning path content.
$149
Marketing and Sales
Exam
AI_PROCTORED
Verified Skills
Badge
Platform
link_retake_2umucr9qwot9d
link_53dg9hhm7dkk
Standard
Building Data Collection Solutions with Shopify Web Pixels
Design data collection solutions with Shopify Web Pixels that are performant, privacy‑first, and aligned to real merchant tracking needs.
FREE
Solutions Architect
Create a Solution for Shopify Core Features
Design and implement a full Shopify solution, including subscriptions, bundles, tracking, and automation, for new online merchants.
FREE
Project
Solutions Architect
Customizing the POS Experience Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Customizing the POS Experience learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$249
45
Point of Sale
Exam
AI_PROCTORED
Retail
Verified Skills
Badge
link_16338ym2gy1hk
link_retake_3ruuv73s0e5in
Advanced
Expanding Your Shopify Business Internationally Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Expanding Your Shopify Business Internationally learning path content. We recommend that you complete all the courses in the learning path prior to attempting the assessment.
$149
40
Internationalization
Exam
AI_PROCTORED
Verified Skills
Badge
Platform
link_j36lh0waz6jf
link_retake_19yzke6u1u8kd
Standard
Shopify開発の基礎 認定試験 (Development Fundamentals Assessment)
このバッジを取得するには、Shopify開発の基本学習パスのコンテンツに関する知識をテストする監視付き評価に合格してください。
$149
Exam
AI_PROCTORED
Verified Skills
Badge
Standard
lang-ja
[Separator] Solution design
Build your understanding of the solution design and planning process. See how the platform fits together, from products and checkout to APIs. Then chart the path: Pick the right mix of native features, apps, APIs, and integrations to sketch the architecture that brings a business on Shopify to life.
FREE
separator
layout--track-template
[External Resource] Partner Marketing Toolkit
Marketing and brand guidelines
FREE
External Resource
auto-registration
hide-search
[Doc] Shopify POS total cost of ownership report
FREE
resource-doc
Document
hide-search
Shopify B2B: Foundations, Discovery and Solution Design Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of Shopify B2B: Foundations, Discovery and Solution Design learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$149
45
Exam
B2B
AI_PROCTORED
Verified Skills
Badge
Consulting
link_128k71p0ezpdz
link_retake_1edz1yo7p19tx
Standard
[Separator] Technical Solution Architecture
Develop the technical expertise to translate business requirements into custom Shopify solutions.
FREE
separator
separator-small
[Separator] Extensibility
Extend Shopify with customizations and integrations like Functions, Checkout Extensibility, apps, and APIs to meet specific requirements and connect systems. Decide when to write code, install an app, or integrate back‑office platforms, and ship with fewer surprises.
FREE
separator
[Separator] Shopify Plus
Explore how Shopify Plus features solve for scale and complexity and unlock new opportunities with upmarket merchants and how apps can enhance your Shopify Plus store.
FREE
separator
Shopify POS Launch and Operations Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Shopify POS Launch and Operations learning path content.
$149
Point of Sale
Exam
AI_PROCTORED
Retail
Verified Skills
Badge
link_2rho7ug6w4tcx
Platform
link_retake_1l6tj7uyz9sm9
Standard
[External Resource] 4 Ways to Use Shopify POS to Grow Your Partner Business
Learn from successful retail partners how to use Shopify POS to gain new clients, solve common commerce challenges, and boost your agency's growth.
FREE
External Resource
auto-registration
hide-search
Platform Capabilities & Strategic Fit
Match Shopify's powerful platform capabilities to business needs, transforming challenges into strategic business growth opportunities.
FREE
30
Course
Sales
Recommending the Right Shopify Plan
Guide merchants to the right Shopify plan with confidence and strategic insight.
FREE
40
Course
[Separator] What's New
FREE
separator
style-hidden
[Separator] Get Started with Shopify Academy
FREE
separator
style-hidden
Creating a Digital Marketing Strategy Assessment
To earn this badge, pass a proctored assessment that evaluates your understanding of the Creating a Digital Marketing Strategy learning path content. We recommend completing all courses within the learning path before attempting the assessment.
$149
30
Exam
AI_PROCTORED
Verified Skills
Badge
link_retake_11gd3x24nro51
link_3fp1u528jklmt
Standard
[Separator] Value-Based Selling
Show the value of your solution, not just the features by building and delivering demos and stories that focus on real business impact.
FREE
separator
separator-small
[Doc] Partner Marketing Lead Generation Playbook
resource-doc
hide-search
Leveraging Shopify Extensibility
Explore Shopify extensibility through metafields and metaobjects, and select approaches based on business needs.
15
Course
Sales
[External Resource] Shopify POS Opportunity for Partners
A short guide outlining the opportunities Shopify Partners have, with Shopify POS
FREE
External Resource
auto-registration
hide-search
[External Resource] Shopify POS Walkthrough
Click through the Shopify POS app to learn about it's features and functionality.
FREE
External Resource
auto-registration
hide-search
[External Resource] EY Report: Future Proofing Retail
Share this EY unified commerce research report summary with your prospects.
FREE
External Resource
auto-registration
hide-search
Liquid Storefronts for Theme Developers Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Liquid Storefronts for Theme Developers learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$249
Exam
Storefronts
AI_PROCTORED
Verified Skills
Badge
link_retake_1ynyb512uxjel
link_2e168rgrscqfq
Advanced
[Doc] TCO Briefing for Partners
resource-doc
Document
hide-search
[External Resource] Lightspeed Switcher Toolkit
Resources to help Partners migrate merchants from Lightspeed to Shopify POS
FREE
External Resource
auto-registration
hide-search
[External Resource] Why RedIron chose Shopify POS to power in-store retail success
Learn why this retail expert chose to partner with Shopify, providing a unified commerce platform fit for enterprise brands.
External Resource
hide-search
[Separator] Launch
FREE
separator
no-search
[Separator] Technical Sales
FREE
separator
[Separator] Marketing
FREE
separator
[Doc] Checkout study sales play
resource-doc
Document
hide-search
[Doc] Analyst sales play
resource-doc
hide-search
[Doc] Retail pitch deck
resource-doc
Document
hide-search
[Separator] B2B Launch and Customization
Learn how to set up and optimize a store to sell to wholesale customers using B2B on Shopify features.
FREE
separator
separator-small
[Separator] Procurement
FREE
separator
[Separator] Merchant Discovery
Go beyond surface needs, and earn the trust that turns conversations into high-value consulting engagements.
FREE
separator
separator-small
[Separator] Procurement overview
From your Partner Dashboard, click "Stores", then "Add store", then "Create reseller store".
FREE
separator
separator-small
[Separator] Launching Shopify Plus
Launch with Plus Development Stores while managing project timelines, and key milestones.
FREE
separator
separator-small
[Doc] Shopify Plus Partner Launch Handbook
resource-doc
Document
hide-search
[Separator] Partner marketing
Develop strategies to effectively promote your Shopify expertise and attract the right clients for your services.
FREE
separator
separator-small
[Separator] Solution-Based Selling B2B
Learn how to effectively engage with wholesale clients and position Shopify's B2B features to meet their unique needs.
FREE
separator
separator-small
[Separator] Sales
FREE
separator
no-search
Understanding Shopify's International Selling Features' Value
Explore how Shopify's Managed Markets helps merchants localize experiences and scale global revenue with less complexity.
FREE
Course
Solutions Architect
[Doc] Partner Marketing Toolkit
resource-doc
Document
hide-search
[Separator] Solution-Based Selling POS
Learn ways to partner with Shopify as well as how to understand product positioning for Shopify POS, craft winning pitches, and create tailored solutions to meet merchant needs for successful retail operations.
FREE
separator
no-search
separator-small
[External Resource] 4 Strategies For Pitching and Solutioning Shopify POS
Learn from Shopify retail partners how to effectively pitch and customize Shopify POS for your clients while growing your business.
FREE
External Resource
auto-registration
hide-search
[External Resource] Briefing: POS Total Cost of Ownership
Leverage these resource to show your clients how Shopify POS reduces retail operation costs better than the competition.
FREE
External Resource
auto-registration
hide-search
[Separator] Sell & Market Shopify POS
Resources to help you market, pitch, and sell Shopify POS to merchants.
FREE
separator
[Separator] Shopify Platform & Values
Learn how the platform works, what makes it different, and how to explain these benefits to your clients with confidence.
FREE
separator
no-search
separator-small
layout--track-template
[Separator] Solution Mapping
Find the right solutions for every situation by matching business needs to Shopify’s products, features, and your services.
FREE
separator
separator-small
[Doc] Shopify pitch deck
resource-doc
Document
hide-search
ソリューションプランニングの基礎評価 (Solution Planning Fundamentals Assessment)
このバッジを取得するには、Solution Planning Fundamentals学習パスの内容に関する知識をテストする監視付き評価に合格する必要があります。
$149
Exam
AI_PROCTORED
Verified Skills
Badge
Standard
lang-ja
Shopify販売の基礎評価 (Selling Shopify Fundamentals Assessment)
このバッジを取得するには、Selling Shopify Fundamentals学習パスの内容に関する知識をテストする監視付き評価に合格する必要があります。
$149
Exam
AI_PROCTORED
Verified Skills
Badge
Consulting
Standard
lang-ja
Positioning International Selling with Shopify Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Positioning International Selling with Shopify learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$149
Internationalization
Exam
AI_PROCTORED
Verified Skills
Badge
link_retake_ykqkxk3v8qjz
link_135c8e34grk7o,
Consulting
Standard
Selling Shopify Fundamentals Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Selling Shopify Fundamentals learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$149
Partners
Exam
AI_PROCTORED
Verified Skills
Badge
link_110lb6naeh4c6
link_retake_2xqgu5l3nqb2r
Standard
Creating Solutions for Shopify Checkout Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Creating Solutions for Shopify Checkout learning path content. We recommend you complete all the courses in the learning path prior to attempting the assessment.
$149
30
Exam
Checkout
AI_PROCTORED
Verified Skills
Badge
link_retake_2uk4uqil5u2kr
link_3ctdvbl8hy7de
Standard
Selling and Positioning Shopify Marketing Products Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Selling and Positioning Shopify Marketing Products learning path content.
$149
Partners
Exam
AI_PROCTORED
Verified Skills
Badge
Selling Shopify
link_2wvv8wae4o9tu
link_retake_k359d5utnpzm
Consulting
Standard
POS for Partners
Learn about partnering with Shopify to offer your clients retail solutions.
FREE
30
Courses
Partners
Point of Sale
Retail
Scale Your Shipping Strategy
This course explores consumer expectations for shipping, how to develop the right shipping strategy for your business, and how to put your strategy into action.
FREE
45 mins
Operations
Platform
Free
Shipping
Setup
Course
Analyze
[Separator] POS Launch and Operations
Effectively set up and manage POS hardware, train staff, execute operations, and optimize growth for seamless business operations.
FREE
separator
separator-small
Solution Planning Fundamentals Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Solution Planning Fundamentals learning path content.
$149
Partners
Exam
AI_PROCTORED
Verified Skills
Badge
link_11pqlwtdfwb91
link_retake_e8vwkmw62uuu
Standard
Shopify Development Fundamentals Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Shopify Development Fundamentals learning path content.
$149
Exam
AI_PROCTORED
Verified Skills
Badge
Developers
link_22q6s891qbbbc
link_retake_3uqlui80igptv
Standard
[External Resource] Shopify POS Sales Sheet
A pdf to help Shopify Partners present Shopify POS to merchants
FREE
External Resource
auto-registration
hide-search
[External Resource] Square Switcher Toolkit
Resources to help Partners migrate merchants from Square to Shopify POS
FREE
External Resource
auto-registration
hide-search
[External Resource] Video: How to earn with Shopify POS
There’s a new way to earn as a Shopify partner. We’ve introduced profit sharing.
FREE
External Resource
auto-registration
hide-search
[External Resource] Shopify POS Demo Kit
This kit is loaded with resources and guidance to help you demo Shopify POS.
FREE
External Resource
auto-registration
hide-search
Data Migration for Shopify
Execute data migration, enterprise integrations, and inventory management techniques for smooth Shopify platform transitions.
FREE
Developer
Course
[Separator] Partner Essentials
FREE
separator
Create a Landing Page That Converts
A great landing page helps you delight your visitors and convert them into leads.
FREE
3 mins
Plus
Partners
Marketing
Platform
[Separator] Value-based selling
Elevate your sales approach by using Shopify's value pillars as your strategic framework, learning to structure and deliver tailored sales pitches that connect business challenges to platform solutions. Apply proven techniques to turn objections into productive conversations that build credibility and move deals forward.
FREE
separator
Introduction to Headless Storefronts Solutions
Explore custom storefront solutions available to Shopify merchants, including features and benefits of Hydrogen, Oxygen, and the Storefront API.
FREE
70
Partners
Storefronts
Developers
[Separator] Shopify features
Learn which features like orders, shipping, themes, apps, and Shopify Flow will resolve merchant challenges. A strong understanding of what’s available will help you confidently suggest features and know when to recommend alternatives.
FREE
separator
[External Resource] Unified Commerce Marketing Deck
This deck provides guidelines + resources for Partners to effectively market Shopify's Unified Commerce platform to medium to large retailers.
FREE
External Resource
auto-registration
hide-search
[External Resource] Riess Group increased deal sizes by 3-4x with Shopify POS
Riess Group, a commerce consulting agency, has had a long-standing partnership with Shopify. They boosted their deal sizes by 3-4x by incorporating Shopify POS into their service offerings.
External Resource
auto-registration
hide-search
Solution-Based Selling with Shopify POS Assessment
To earn this badge, pass a proctored assessment that tests your knowledge of the Shopify POS Solution-Based Selling learning path content.
$149
Point of Sale
Exam
AI_PROCTORED
Retail
Verified Skills
Badge
link_3d43bmkm9wtna
link_retake_3uyed375zite6
Consulting
Standard
[Demo] Introduction to the Shopify Admin
Take a guided tour of the Shopify admin to learn how to navigate the platform and its key features.
FREE
5
Admin
auto-registration
resource-demo
Getting started as a Shopify Partner
Begin your journey as a Shopify Partner by exploring essential courses that provide foundational knowledge for your success.
FREE
3 Courses
Partners
Learning Path
Free
Commercial
Getting Started
[Separator] App development
Design, build, and deploy Shopify apps and extensions. From embedded app architecture to API integration, extensibility, and checkout customization, deliver seamless, merchant-specific functionality.
FREE
separator
The Shopify Platform: Architecture and Design Principles
Discover how Shopify's architecture balances core infrastructure with extensibility.
Developer
Systems Integration and Advanced Inventory Management
Navigate the inventory hierarchy and system integration strategies that enable seamless multi-location operations.
30
Developer
Shopify Plus: What Developers Need to Know
Explore Shopify Plus architecture, APIs, and the developer tools needed to build enterprise solutions.
5
Developer
Course
Launching on Shopify Plus
Learn the basics about replatforming to Shopify Plus.
FREE
30
Plus
Partners
Platform
Course
[Separator] Data migration and integration
Develop expertise in migrating complex data to Shopify and integrating key business systems. Learn techniques for analyzing, mapping, and securely moving ecommerce data, and automate real-time syncs with ERPs and fulfillment platforms to ensure smooth, streamlined merchant operations.
FREE
separator
[Separator] Theme development
Build comprehensive theme customization skills, from environment setup through advanced Liquid development. This area emphasizes modern workflows, theme architecture understanding, and performance-optimized coding practices.
FREE
separator
[External Resource] Expanding your service offerings with Shopify POS
This guide will help you learn how to incorporate Shopfy POS into your existing business
FREE
External Resource
auto-registration
hide-search
Ambient Commerce and the Rise of Conversational AI Shopping
Discover the building blocks and infrastructure needed for AI shopping assistants and frictionless commerce.
10
Course
Sales
Solutions Architect
Create a Data Solution with Shopify Extensions
Build a no-code checkout solution that enhances branding, trust, and incentives using Shopify apps.
FREE
Project
Solutions Architect
[External Resource] POS Pro Yearly Subscription
Introduce your prospects to the new POS offer so that they can benefit, and you can close more deals.
FREE
External Resource
auto-registration
hide-search
Hydrogen Best Practices
Learn best practices to optimize a custom storefront
FREE
60
Storefronts
Developers
Introduction to custom storefronts for developers
Learn about Shopify’s headless framework, tooling, and hosting options.
FREE
45
Storefronts
Developers
Developer
Liquid to Hydrogen Migration
Learn the steps to successfully transition from a Liquid storefront to Hydrogen.
FREE
40
Storefronts
Developers
Developer
[Separator] Learn about Shopify POS
Complete the POS learnings paths & get your Verified Skill Badge
FREE
separator
[External Resource] POS Partner Accelerator Webinar - Part 1
Learn from successful retail partners how to grow your business with Shopify POS
FREE
External Resource
hide-search
Part of:
