Standard Events Skip to main content
alert _displayed
The alert_displayed event records instances when a user encounters an alert message, whether it's an inline validation message on an input field or a warning banner.
cart _viewed
The cart_viewed event logs an instance where a customer visited the cart page.
checkout _address _info _submitted
The checkout_address_info_submitted event logs an instance of a customer submitting their mailing address.
checkout _completed
The checkout_completed event logs when a visitor completes a purchase.
checkout _contact _info _submitted
The checkout_contact_info_submitted event logs an instance where a customer submits a checkout form.
checkout _shipping _info _submitted
The checkout_shipping_info_submitted event logs an instance where the customer chooses a shipping rate.
checkout _started
The checkout_started event logs an instance of a customer starting the checkout process.
collection _viewed
The collection_viewed event logs an instance where a customer visited a product collection index page.
page _viewed
The page_viewed event logs an instance where a customer visited a page.
payment _info _submitted
The payment_info_submitted event logs an instance of a customer submitting their payment information.
product _added _to _cart
The product_added_to_cart event logs an instance where a customer adds a product to their cart.
product _removed _from _cart
The product_removed_from_cart event logs an instance where a customer removes a product from their cart.
product _viewed
The product_viewed event logs an instance where a customer visited a product details page.
search _submitted
The search_submitted event logs an instance where a customer performed a search on the storefront.
ui _extension _errored
The ui_extension_errored event logs occurrences when an extension fails to render due to an uncaught exception in the extension code.
Was this page helpful?
Yes No
