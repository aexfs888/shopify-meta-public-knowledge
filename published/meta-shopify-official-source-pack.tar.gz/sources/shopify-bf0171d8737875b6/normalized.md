---
title: Standard Events
source_url:
html: 'https://shopify.dev/docs/api/web-pixels-api/standard-events'
md: 'https://shopify.dev/docs/api/web-pixels-api/standard-events.md'
api_name: web-pixels
---
# Standard Events
[alert​\_displayed](https://shopify.dev/docs/api/web-pixels-api/standard-events/alert_displayed)
[The alert\_displayed event records instances when a user encounters an alert message, whether it's an inline validation message on an input field or a warning banner.](https://shopify.dev/docs/api/web-pixels-api/standard-events/alert_displayed)
[cart​\_viewed](https://shopify.dev/docs/api/web-pixels-api/standard-events/cart_viewed)
[The cart\_viewed event logs an instance where a customer visited the cart page.](https://shopify.dev/docs/api/web-pixels-api/standard-events/cart_viewed)
[checkout​\_address​\_info​\_submitted](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_address_info_submitted)
[The checkout\_address\_info\_submitted event logs an instance of a customer submitting their mailing address.](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_address_info_submitted)
[checkout​\_completed](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_completed)
[The checkout\_completed event logs when a visitor completes a purchase.](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_completed)
[checkout​\_contact​\_info​\_submitted](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_contact_info_submitted)
[The checkout\_contact\_info\_submitted event logs an instance where a customer submits a checkout form.](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_contact_info_submitted)
[checkout​\_shipping​\_info​\_submitted](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_shipping_info_submitted)
[The checkout\_shipping\_info\_submitted event logs an instance where the customer chooses a shipping rate.](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_shipping_info_submitted)
[checkout​\_started](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_started)
[The checkout\_started event logs an instance of a customer starting the checkout process.](https://shopify.dev/docs/api/web-pixels-api/standard-events/checkout_started)
[collection​\_viewed](https://shopify.dev/docs/api/web-pixels-api/standard-events/collection_viewed)
[The collection\_viewed event logs an instance where a customer visited a product collection index page.](https://shopify.dev/docs/api/web-pixels-api/standard-events/collection_viewed)
[page​\_viewed](https://shopify.dev/docs/api/web-pixels-api/standard-events/page_viewed)
[The page\_viewed event logs an instance where a customer visited a page.](https://shopify.dev/docs/api/web-pixels-api/standard-events/page_viewed)
[payment​\_info​\_submitted](https://shopify.dev/docs/api/web-pixels-api/standard-events/payment_info_submitted)
[The payment\_info\_submitted event logs an instance of a customer submitting their payment information.](https://shopify.dev/docs/api/web-pixels-api/standard-events/payment_info_submitted)
[product​\_added​\_to​\_cart](https://shopify.dev/docs/api/web-pixels-api/standard-events/product_added_to_cart)
[The product\_added\_to\_cart event logs an instance where a customer adds a product to their cart.](https://shopify.dev/docs/api/web-pixels-api/standard-events/product_added_to_cart)
[product​\_removed​\_from​\_cart](https://shopify.dev/docs/api/web-pixels-api/standard-events/product_removed_from_cart)
[The product\_removed\_from\_cart event logs an instance where a customer removes a product from their cart.](https://shopify.dev/docs/api/web-pixels-api/standard-events/product_removed_from_cart)
[product​\_viewed](https://shopify.dev/docs/api/web-pixels-api/standard-events/product_viewed)
[The product\_viewed event logs an instance where a customer visited a product details page.](https://shopify.dev/docs/api/web-pixels-api/standard-events/product_viewed)
[search​\_submitted](https://shopify.dev/docs/api/web-pixels-api/standard-events/search_submitted)
[The search\_submitted event logs an instance where a customer performed a search on the storefront.](https://shopify.dev/docs/api/web-pixels-api/standard-events/search_submitted)
[ui​\_extension​\_errored](https://shopify.dev/docs/api/web-pixels-api/standard-events/ui_extension_errored)
[The ui\_extension\_errored event logs occurrences when an extension fails to render due to an uncaught exception in the extension code.](https://shopify.dev/docs/api/web-pixels-api/standard-events/ui_extension_errored)
***
