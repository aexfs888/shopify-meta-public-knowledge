- Shopify Help Center | Navigating the Shopify admin
Help
Start for free
Log in
Contents
# Navigating the Shopify admin
The Shopify admin is your central hub for managing your online store. Using the Shopify admin sidebar or search functionality on all pages, you can navigate through the various functions of Shopify and efficiently manage your store.
## On this page
Sections of the Shopify admin
- Switching between stores
- Shopify Home page
- Alerts feed
- Searching your Shopify admin
- Staff permissions for accessing the Shopify admin
- Apps and channels
## Sections of the Shopify admin
You can access the different sections of the Shopify admin by using the sidebar. Sections of the Shopify admin include:
- Core aspects of your Shopify business, including orders , products , and customers , analytics and reports, marketing and promotions , and discounts .
- Sales channels and apps , which are optional extensions that help you expand your business into other platforms or improve your business' operations.
- Settings applied to your Shopify store and account.
Current design
You can also navigate through your Shopify admin by using the search bar in the top bar. The top bar also contains buttons to access Sidekick and your store's Alerts feed . If you have accounts in more than one Shopify store, then you can use the store switcher in the top bar to navigate to those stores.
Refreshed design
You can also navigate through your Shopify admin by using the search bar in the sidebar. The sidebar also contains your store's Alerts feed , and Sidekick is available from every page. If you have accounts in more than one Shopify store, then you can use the store switcher in the sidebar to navigate to those stores.
## Switching between stores
If you have multiple Shopify stores associated with the same email address, then you can use the store switcher in the top bar to navigate between them. If you have access to the Dev Dashboard or Partner Dashboard, then you can also reach them from the store switcher. Learn more about switching between stores .
#### Steps:
Desktop
- Log in to the Shopify admin of one of your stores.
- Click the name of your store.
- Select one of your recent stores from the list.
If the store you're looking for isn't listed, then click View all to open a searchable list of all your stores without leaving the page. Use the search field to find a store by name, then select it.
Mobile
- From the Shopify app, tap your store name.
- Select a different store to view.
## Shopify Home page
The Home page of the Shopify admin displays real-time metrics such as sales and traffic, as well as task reminders and growth tips for your business.
Shopify Home highlights urgent actions or events, such as unpaid orders that still need to be captured. Click any of the actions to be directed to the appropriate page.
Learn more about the Shopify Home page .
## Alerts feed
The Alerts feed notifies you of important, time-sensitive information or required actions in your store. These alerts are sent to the store owner and any staff with relevant permissions .
You might receive alerts for the following scenarios:
- A task that can prevent a disruption to your business activities or regular use of Shopify.
- A disruption to your business activities or regular use of Shopify.
- A communication of product compliance.
- Confirmation of a monetary transaction between you and Shopify.
- Confirmation that a time-consuming process that you initiated has been completed.
Click the icon to open the Alerts feed. The number of unseen alerts is displayed next to the icon.
Within the Alerts feed, you can click a specific alert to take action on that alert. You can toggle specific alerts as read or unread, or mark all alerts as read.
## Searching your Shopify admin
Use the search bar in your Shopify admin (keyboard shortcut: ctrl + K on a PC, or command + K on a Mac) to help you find results based on your search. Click a search result to be directed to the appropriate page in your admin.
You can filter your search results by category, such as Orders or Apps , to help you find a more relevant list of results. Based on your search keywords, suggested filters can display at the top of the search results list, including the number of total results within that category.
Your recent searches are maintained in a search history, which you can clear at any time.
Learn more about searching your Shopify admin .
## Staff permissions for accessing the Shopify admin
Account owners and administrators control which areas of the Shopify admin staff members can access by assigning permissions. This ensures staff can view and perform only the tasks they need, although it prevents access to unnecessary pages and actions.
Permissions are assigned through roles. Each role is a collection of permissions. You can assign staff a Shopify-defined system role, or create a custom role with specific permissions (for example, Merchandiser or Customer support).
The following list includes example permissions you can add to a custom role:
- View orders
- Create and edit products
- Manage inventory
- Export customer lists
- Edit themes
- View reports
Learn more about roles and staff permissions .
## Apps and channels
Your apps and sales channels are located in the sidebar of your Shopify admin. Items in this area include:
- Sales channels , including Online Store .
- Apps installed on your account.
Sales channels and apps are optional extensions to the Shopify admin that allow your business to expand into other sales platforms, or improve your business' operations. By default, new Shopify stores begin with only the Online Store sales channel installed.
You can install new sales channels and app from the Shopify App Store , or from the recommended apps in your Shopify admin search results.
### Pinning apps and channels
You can pin your favorite apps and channels. A pinned app is added to the bottom of the item list (for example, Sales channels or Apps ), and always displays in that list for quick navigation. You can rearrange your pinned apps and channels by clicking and dragging an item to a new position in the corresponding list.
To pin an app or channel, open the app or channel from your admin. Click the icon to keep the app or channel in your list. Click and drag the item to change its position. You can also pin an app or channel by dragging it directly to the preferred position in the side bar after opening it.
To unpin an app or channel, click the icon at the top of the app or sales channel header. To navigate to this app or channel in the future, use the search bar or the left sidebar navigation.
### Apps and sales channels settings
To access the Settings pages for your apps and sales channels, go to Settings > Apps or Settings > Sales channels .
On the Apps and Sales channels settings pages, you can Uninstall the app or sales channel, visit the Shopify App Store , or Get support for the app or sales channel. Access the About page through the overflow menu in the header of any currently open embedded app. Clicking the name of an app or sales channel opens the item in your Shopify admin.
Leave feedback
