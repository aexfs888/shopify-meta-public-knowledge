-
Navigating the Shopify Admin
There was an issue with saving this content. Please try again.
There was an issue with removing this item from your saved content. Please try again.
# Navigating the Shopify Admin
## Tour the Shopify admin with interactive demos and articles covering key features and tools.
Register | FREE
Already registered?
Sign In
Cancel
Apply
rate limit
Code not recognized.
Activate
(opens in new tab)
### About this course
A collection of interactive demos and articles that provides an overview of the capabilities of the Shopify admin. You&rsquo;ll explore the features and tools that will help you maximize your success with the admin.
### Curriculum 20
Adding a product
-
Setting up role-based access controls in the Shopify admin
-
Setting up Sales Channels for Social Media in the Shopify Admin
-
Creating Metaobjects and Metafields in the Shopify Admin
-
Managing inventory in the Shopify Admin
-
Gift Cards in the Shopify Admin
-
Creating a Draft Order in the Shopify Admin
-
Variants and Collections in the Shopify Admin
About this course
A collection of interactive demos and articles that provides an overview of the capabilities of the Shopify admin. You&rsquo;ll explore the features and tools that will help you maximize your success with the admin.
Curriculum 20
-
Adding a product
-
Setting up role-based access controls in the Shopify admin
-
Setting up Sales Channels for Social Media in the Shopify Admin
-
Creating Metaobjects and Metafields in the Shopify Admin
-
Managing inventory in the Shopify Admin
-
Gift Cards in the Shopify Admin
-
Creating a Draft Order in the Shopify Admin
-
Variants and Collections in the Shopify Admin
