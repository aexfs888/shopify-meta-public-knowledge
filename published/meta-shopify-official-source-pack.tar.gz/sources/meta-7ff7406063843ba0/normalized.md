# Ad
Contains information to display an ad and associate it with an ad set. Each ad is associated with an ad set and all ads in a set have the same daily or lifetime budget, schedule, and targeting. Creating multiple ads in an ad set helps optimize their delivery based on variations in images, links, video, text or placements.
Note that results returned by `synchronous_ad_review` does not represent the final decision made during full review of your ad.
### Ads with Political Content
To increase transparency of ads on Facebook, we require advertisers running ads with political content to complete authorization. We will begin enforcing this in the next few weeks. You must also indicate that your ad has political content and provide the name of the funding source for the ad:
- Your ad account must be authorized by a Page admin to run political ads for this Page. This is done by a Page admin on the `Issue, Electoral or Political Ads` tab under `Page Settings`.
- Ad account users must go through a verification process.
### Ads with Page Mentions
With Facebook&#039;s ads tools such as [Ads Manager](https://www.facebook.com/ads/manager/accounts) or light-weight interfaces, you can create an ad with a *Page Mention*. This displays a link in your ad which opens an advertiser&#039;s Facebook page. **We do not provide this functionality in Marketing API**. If you try to create an ad with the API with a Page Mention it will succeed, however we will deliver the ad without the mention. Instead, use one of Facebook&#039;s ads tools.
### Targeting DSA Regulated Locations (European Union)
To create or copy an ad which is in an ad set targeted in the European Union&#039;s Digital Services Act (DSA) regulated locations, please set the payor/beneficiary information first. For your convenience, if the `default_dsa_payor` and `default_dsa_beneficiary` are set in an ad account, during the copying process, even if the original ad set does not set payor or beneficiary, it will be filled with saved default values. For more information on copying ads that target DSA regulated locations in the EU, see the [Ad Copies reference documentation](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/adgroup/copies#targeting-dsa-regulated-locations--european-union-).
### Targeting Youth in European Union (EU), European Economic Area (EEA), and Switzerland
Meta will stop showing ads to youth in the EU, EEA, and Switzerland as early as the week of November 6, 2023. When creating new ad sets or updating existing ones that target youth in the EU, EEA, and Switzerland, they will be prevented. Existing ad sets targeting youth in the EU, EEA and Switzerland, will pause delivery as early as the week of November 6, 2023. Existing ad sets targeting youth in the EU, EEA, and Switzerland and in other regions will see a warning that the ads in the ad sets will no longer be delivered to youth in the EU, EEA, and Switzerland.
### Examples
Creating an ad:
```html
curl -X POST \
-F &#039;name=&quot;My Ad&quot;&#039; \
-F &#039;adset_id=&quot;&lt;AD_SET_ID&gt;&quot;&#039; \
-F &#039;creative=&#123;
&quot;creative_id&quot;: &quot;&lt;CREATIVE_ID&gt;&quot;
&#125;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/ads
```
To create a political ad, provide `authorization_category` with the value `POLITICAL` . For example:
```html
curl -X POST \
-F &#039;name=&quot;My AdGroup&quot;&#039; \
-F &#039;adset_id=&quot;&lt;AD_SET_ID&gt;&quot;&#039; \
-F &#039;creative=&#123;
&quot;creative_id&quot;: &quot;&lt;CREATIVE_ID&gt;&quot;
&#125;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;authorization_category=&quot;POLITICAL&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/ads
```
See:
- [Ad Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group), [Ad Set](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign), and [Ad Creative](https://developers.facebook.com/docs/reference/ads-api/adcreative)
- [Storing Ad Objects](https://developers.facebook.com/documentation/ads-commerce/marketing-api/best-practices/manage-your-ad-object-status)
## Reading
An ad object contains the data necessary to visually display an ad and associate it with a corresponding ad set.
### By ad ID &#123;#read-ad&#125;
```html
curl -X GET \
-d &#039;fields=&quot;id,name&quot;&#039; \
-d &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_ID&gt;/
```
### By ad account &#123;#read-adaccount&#125;
To read all ads from one ad account:
### PHP Business SDK
```
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\Fields\AdFields;
$account = new AdAccount($account_id);
$ads = $account-&gt;getAds(array(
AdFields::NAME,
));
// Outputs names of Ads.
foreach ($ads as $ad) &#123;
echo $ad-&gt;name;
&#125;
```
### Python Business SDK
```
from facebookads.objects import AdAccount, Ad
account_id = &#039;act_&lt;AD_ACCOUNT_ID&gt;&#039;
ad_account = AdAccount(account_id)
ad_iter = ad_account.get_ads(fields=[Ad.Field.name])
for ad in ad_iter:
print ad[Ad.Field.name]
```
### cURL
```
curl -G \
-d &quot;fields=name&quot; \
-d &quot;access_token=&lt;ACCESS_TOKEN&gt;&quot; \
&quot;https://graph.facebook.com/&lt;API_VERSION&gt;/act_&lt;AD_ACCOUNT_ID&gt;/ads&quot;
```
### By ad campaign &#123;#read-ad-campaign&#125;
Read all ads from a campaign:
```html
curl -X GET \
-d &#039;fields=&quot;name&quot;&#039; \
-d &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_CAMPAIGN_ID&gt;/ads
```
### By ad set &#123;#read-campaign&#125;
To read all ads from one ad set:
### PHP Business SDK
```
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdSetFields;
$adset = new AdSet($adset_id);
$ads = $adset-&gt;getAds(array(
AdFields::NAME,
));
// Outputs names of Ads .
foreach ($ads as $ad) &#123;
echo $ad-&gt;name;
&#125;
```
### Python Business SDK
```
from facebookads.objects import AdSet, Ad
adset_id = &lt;AD_SET_ID&gt;
ad_set = AdSet(adset_id)
ad_iter = ad_set.get_ads(fields=[Ad.Field.name])
for ad in ad_iter:
print ad[Ad.Field.name]
```
### cURL
```
curl \
-F &quot;fields=name&quot; \
-F &quot;access_token=&lt;ACCESS_TOKEN&gt;&quot; \
&quot;https://graph.facebook.com/&lt;API_VERSION&gt;/&lt;AD_SET_ID&gt;/ads&quot;
```
#### Example
### HTTP
```
GET /v25.0/&lt;ADGROUP_ID&gt;/?fields=id%2Cname HTTP/1.1
Host: graph.facebook.com
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;get(
&#039;/&lt;ADGROUP_ID&gt;/?fields=id%2Cname&#039;,
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;/&lt;ADGROUP_ID&gt;/&quot;,
&#123;
&quot;fields&quot;: &quot;id,name&quot;
&#125;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
Bundle params = new Bundle();
params.putString(&quot;fields&quot;, &quot;id,name&quot;);
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;/&lt;ADGROUP_ID&gt;/&quot;,
params,
HttpMethod.GET,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
NSDictionary *params = &#064;&#123;
&#064;&quot;fields&quot;: &#064;&quot;id,name&quot;,
&#125;;
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;/&lt;ADGROUP_ID&gt;/&quot;
parameters:params
HTTPMethod:&#064;&quot;GET&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
### cURL
```
curl -X GET -G \
-d &#039;fields=&quot;id,name&quot;&#039; \
-d &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;ADGROUP_ID&gt;/
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=GET&amp;path=%3CADGROUP_ID%3E%2F%3Ffields%3Did%252Cname&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
| Parameter | Description |
| --- | --- |
| `date_preset`&lt;br&gt;&lt;br&gt;*enum&#123;today, yesterday, this_month, last_month, this_quarter, maximum, data_maximum, last_3d, last_7d, last_14d, last_28d, last_30d, last_90d, last_week_mon_sun, last_week_sun_sat, last_quarter, last_year, this_week_mon_today, this_week_sun_today, this_year&#125;* | Date Preset&lt;br&gt; |
| `review_feedback_breakdown`&lt;br&gt;&lt;br&gt;*boolean* | **Default value: **`false`&lt;br&gt;review_feedback_breakdown&lt;br&gt; |
| `time_range`&lt;br&gt;&lt;br&gt;*&#123;&#039;since&#039;:YYYY-MM-DD,&#039;until&#039;:YYYY-MM-DD&#125;* | Time Range. Note if time range is invalid, it will be ignored.&lt;br&gt;&lt;br&gt;&lt;br&gt;`since` *datetime*&lt;br&gt;A date in the format of &quot;YYYY-MM-DD&quot;, which means from the beginning midnight of that day.&lt;br&gt;&lt;br&gt;&lt;br&gt;`until` *datetime*&lt;br&gt;A date in the format of &quot;YYYY-MM-DD&quot;, which means to the beginning midnight of the following day.&lt;br&gt; |
#### Fields
| Field | Description |
| --- | --- |
| `id`&lt;br&gt;&lt;br&gt;*numeric string* | id&lt;br&gt;&lt;br&gt;&lt;br&gt;**[default]**&lt;br&gt; |
| `account_id`&lt;br&gt;&lt;br&gt;*numeric string* | account_id&lt;br&gt; |
| `ad_active_time`&lt;br&gt;&lt;br&gt;*numeric string* | ad_active_time&lt;br&gt; |
| `ad_review_feedback`&lt;br&gt;&lt;br&gt;*[AdgroupReviewFeedback](https://developers.facebook.com/docs/marketing-api/reference/adgroup-review-feedback)* | ad_review_feedback&lt;br&gt; |
| `ad_schedule_end_time`&lt;br&gt;&lt;br&gt;*datetime* | ad_schedule_end_time&lt;br&gt; |
| `ad_schedule_start_time`&lt;br&gt;&lt;br&gt;*datetime* | ad_schedule_start_time&lt;br&gt; |
| `adlabels`&lt;br&gt;&lt;br&gt;*[list&lt;AdLabel&gt;](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-label)* | adlabels&lt;br&gt; |
| `adset`&lt;br&gt;&lt;br&gt;*[AdSet](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign)* | adset&lt;br&gt; |
| `adset_id`&lt;br&gt;&lt;br&gt;*numeric string* | adset_id&lt;br&gt; |
| `bid_amount`&lt;br&gt;&lt;br&gt;*int32* | bid_amount&lt;br&gt; |
| `bid_info`&lt;br&gt;&lt;br&gt;*map&lt;string, unsigned int32&gt;* | bid_info&lt;br&gt; |
| `bid_type`&lt;br&gt;&lt;br&gt;*enum &#123;CPC, CPM, MULTI_PREMIUM, ABSOLUTE_OCPM, CPA&#125;* | bid_type&lt;br&gt; |
| `campaign`&lt;br&gt;&lt;br&gt;*[Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group)* | campaign&lt;br&gt; |
| `campaign_id`&lt;br&gt;&lt;br&gt;*numeric string* | campaign_id&lt;br&gt; |
| `configured_status`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | configured_status&lt;br&gt; |
| `conversion_domain`&lt;br&gt;&lt;br&gt;*string* | conversion_domain&lt;br&gt; |
| `conversion_specs`&lt;br&gt;&lt;br&gt;*[list&lt;ConversionActionQuery&gt;](https://developers.facebook.com/docs/marketing-api/reference/conversion-action-query)* | conversion_specs&lt;br&gt; |
| `created_time`&lt;br&gt;&lt;br&gt;*datetime* | created_time&lt;br&gt; |
| `creative`&lt;br&gt;&lt;br&gt;*[AdCreative](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-creative)* | creative&lt;br&gt; |
| `creative_asset_groups_spec`&lt;br&gt;&lt;br&gt;*[AdCreativeAssetGroupsSpec](https://developers.facebook.com/docs/marketing-api/reference/ad-creative-asset-groups-spec)* | creative_asset_groups_spec&lt;br&gt; |
| `demolink_hash`&lt;br&gt;&lt;br&gt;*string* | demolink_hash&lt;br&gt; |
| `display_sequence`&lt;br&gt;&lt;br&gt;*int32* | display_sequence&lt;br&gt; |
| `effective_status`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, DELETED, PENDING_REVIEW, DISAPPROVED, PREAPPROVED, PENDING_BILLING_INFO, CAMPAIGN_PAUSED, ARCHIVED, ADSET_PAUSED, IN_PROCESS, WITH_ISSUES&#125;* | effective_status&lt;br&gt; |
| `engagement_audience`&lt;br&gt;&lt;br&gt;*bool* | engagement_audience&lt;br&gt; |
| `failed_delivery_checks`&lt;br&gt;&lt;br&gt;*[list&lt;DeliveryCheck&gt;](https://developers.facebook.com/docs/marketing-api/adgroup/deliverychecks)* | failed_delivery_checks&lt;br&gt; |
| `is_autobid`&lt;br&gt;&lt;br&gt;*bool* | is_autobid&lt;br&gt; |
| `issues_info`&lt;br&gt;&lt;br&gt;*[list&lt;AdgroupIssuesInfo&gt;](https://developers.facebook.com/docs/marketing-api/reference/adgroup-issues-info)* | issues_info&lt;br&gt; |
| `last_updated_by_app_id`&lt;br&gt;&lt;br&gt;*id* | last_updated_by_app_id&lt;br&gt; |
| `name`&lt;br&gt;&lt;br&gt;*string* | name&lt;br&gt; |
| `preview_shareable_link`&lt;br&gt;&lt;br&gt;*string* | preview_shareable_link&lt;br&gt; |
| `priority`&lt;br&gt;&lt;br&gt;*unsigned int32* | priority&lt;br&gt; |
| `recommendations`&lt;br&gt;&lt;br&gt;*list&lt;AdRecommendation&gt;* | recommendations&lt;br&gt; |
| `source_ad`&lt;br&gt;&lt;br&gt;*[Ad](https://developers.facebook.com/docs/graph-api/reference/adgroup)* | source_ad&lt;br&gt; |
| `source_ad_id`&lt;br&gt;&lt;br&gt;*numeric string* | source_ad_id&lt;br&gt; |
| `special_ad_categories`&lt;br&gt;&lt;br&gt;*list&lt;enum&gt;* | special_ad_categories&lt;br&gt; |
| `status`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | status&lt;br&gt; |
| `targeting`&lt;br&gt;&lt;br&gt;*Targeting* | targeting&lt;br&gt; |
| `tracking_and_conversion_with_defaults`&lt;br&gt;&lt;br&gt;*TrackingAndConversionWithDefaults* | tracking_and_conversion_with_defaults&lt;br&gt; |
| `tracking_specs`&lt;br&gt;&lt;br&gt;*[list&lt;ConversionActionQuery&gt;](https://developers.facebook.com/docs/marketing-api/reference/conversion-action-query)* | tracking_specs&lt;br&gt; |
| `updated_time`&lt;br&gt;&lt;br&gt;*datetime* | updated_time&lt;br&gt; |
#### Edges
| Edge | Description |
| --- | --- |
| [`adcreatives`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/adcreatives)&lt;br&gt;&lt;br&gt;*Edge&lt;AdCreative&gt;* | adcreatives&lt;br&gt; |
| [`adrules_governed`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/adrules_governed)&lt;br&gt;&lt;br&gt;*Edge&lt;AdRule&gt;* | adrules_governed&lt;br&gt; |
| [`copies`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/copies)&lt;br&gt;&lt;br&gt;*Edge&lt;Adgroup&gt;* | copies&lt;br&gt; |
| [`insights`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/insights)&lt;br&gt;&lt;br&gt;*Edge&lt;AdsInsights&gt;* | insights&lt;br&gt; |
| [`leads`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/leads)&lt;br&gt;&lt;br&gt;*Edge&lt;UserLeadGenInfo&gt;* | leads&lt;br&gt; |
| [`previews`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/previews)&lt;br&gt;&lt;br&gt;*Edge&lt;AdPreview&gt;* | previews&lt;br&gt; |
| [`targetingsentencelines`](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/targetingsentencelines)&lt;br&gt;&lt;br&gt;*Edge&lt;TargetingSentenceLine&gt;* | targetingsentencelines&lt;br&gt; |
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 613 | Calls to this api have exceeded the rate limit. |
| 190 | Invalid OAuth 2.0 Access Token |
| 104 | Incorrect signature |
| 2635 | You are calling a deprecated version of the Ads API. Please update to the latest version. |
| 2500 | Error parsing graph query |
| 3018 | The start date of the time range cannot be beyond 37 months from the current date |
| 200 | Permissions error |
| 270 | This Ads API request is not allowed for apps with development access level (Development access is by default for all apps, please request for upgrade). Make sure that the access token belongs to a user that is both admin of the app and admin of the ad account |
## Creating
Before you create an ad, you need an existing [ad set](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign) and [ad creative](https://developers.facebook.com/docs/reference/ads-api/adcreative). You can create ads synchronously and asynchronously.
**New ads are in pending state and do not run until Facebook approves or rejects them**. After we approve an ad it runs. If you do not want an ad to automatically run after approval, create it and set its ad set to `paused` (see [ad set](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign)). Run the [ad set](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign) when you are ready.
**Success:** Due to iOS 14.5 changes, [Deferred Deep Linking](https://developers.facebook.com/docs/app-ads/deep-linking#deferred-deep-linking) is no longer available for [SKAdsNetwork Campaigns](https://developers.facebook.com/docs/audience-network/guides/SKAdNetwork).
### Synchronous Creation &#123;#syncadcreation&#125;
Creates one ad at a time:
```html
curl -X POST \
-F &#039;name=&quot;My Ad&quot;&#039; \
-F &#039;adset_id=&quot;&lt;AD_SET_ID&gt;&quot;&#039; \
-F &#039;creative=&#123;
&quot;creative_id&quot;: &quot;&lt;CREATIVE_ID&gt;&quot;
&#125;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/ads
```
### Asynchronous Creation &#123;#asyncadcreation&#125;
Create multiple ads at a time asynchronously. Receive a notification when all the ads in the request exist. Make an `HTTP POST` to: `https://graph.facebook.com/&#123;API_VERSION&#125;/act_&#123;AD_ACCOUNT_ID&#125;/asyncadrequestsets`
Use these fields:
| Field | Description |
| --- | --- |
| **name**&lt;br&gt;&lt;br&gt;type: string | Required. &lt;br&gt;&lt;br&gt;Name of ad set for newly created ads. |
| **ad_specs**&lt;br&gt;&lt;br&gt;type: array of ad specs | Required.&lt;br&gt;&lt;br&gt;Ads can be created for different ad sets inside the current ad account. To use images in ad creative, provide `image_hash` in ad spec after you upload the image at `https://graph.facebook.com/&#123;API_VERSION&#125;/act_&#123;AD_ACCOUNT_ID&#125;/adimages`. &lt;br&gt;`image_file` inside ad_specs. |
| **notification_uri**&lt;br&gt;&lt;br&gt;type: string | Optional.&lt;br&gt;&lt;br&gt;Async job completed. This URI notifies the caller with a `POST` and ad set id. |
| **notification_mode**&lt;br&gt;&lt;br&gt;type: string | Optional.&lt;br&gt;&lt;br&gt;Notification mode: &lt;br&gt;`OFF` – No notification &lt;br&gt;`ON_COMPLETE` – Send notification when all ads for set created. |
For information on asynchronous request sets, see [Asynchronous Requests](https://developers.facebook.com/documentation/ads-commerce/marketing-api/asyncrequests).
### Limits &#123;#limits&#125;
These are the maximum number of ads per object:
| Limit | Value |
| --- | --- |
| Ads in regular ad account | 5000 non-deleted ads |
| Ads in bulk ad account | 50000 non-deleted ads |
| Ads in an ad set | 50 non-deleted ads |
| Archived ads in an ad account | 100,000 archived ads |
### Examples
Download details for an ad:
```html
curl -X POST \
-F &#039;name=&quot;My AdGroup with Redownload&quot;&#039; \
-F &#039;adset_id=&quot;&lt;AD_SET_ID&gt;&quot;&#039; \
-F &#039;creative=&#123;
&quot;creative_id&quot;: &quot;&lt;CREATIVE_ID&gt;&quot;
&#125;&#039; \
-F &#039;redownload=1&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/ads
```
### /&#123;ad_id&#125;/copies
You can make a POST request to *copies* edge from the following paths:
- [/&#123;ad_id&#125;/copies](https://developers.facebook.com/documentation/ads-commerce/graph-api/reference/adgroup/copies)
When posting to this edge, an [Ad](https://developers.facebook.com/docs/graph-api/reference/adgroup) will be created.
#### Parameters
| Parameter | Description |
| --- | --- |
| `adset_id`&lt;br&gt;&lt;br&gt;*numeric string or integer* | Single ID of an adset object to make the parent of the copy. Ignore if you want to keep the copy under the original adset parent.&lt;br&gt; |
| `creative_parameters`&lt;br&gt;&lt;br&gt;*AdCreative* | Creative inputs which will be used to construct the creative in the new ad. Overwrites happen at the top level. If no input is provided, the new ad will be created with an identical ad creative. If some input is provided, those parameters will be assigned to the ad creative created by this API call.&lt;br&gt;&lt;br&gt;&lt;br&gt;Accepts all ad creative parameters as specified in /documentation/ads-commerce/marketing-api/reference/ad-account/adcreatives&lt;br&gt;&lt;br&gt;**[supports emoji]**&lt;br&gt; |
| `rename_options`&lt;br&gt;&lt;br&gt;*JSON or object-like arrays* | Rename options&lt;br&gt;&lt;br&gt;&lt;br&gt;`rename_strategy` *enum &#123;DEEP_RENAME, ONLY_TOP_LEVEL_RENAME, NO_RENAME&#125;*&lt;br&gt;&lt;br&gt;**Default value: **`ONLY_TOP_LEVEL_RENAME`&lt;br&gt;`DEEP_RENAME`: will change this object&#039;s name and children&#039;s names in the copied object. `ONLY_TOP_LEVEL_RENAME`: will change the this object&#039;s name but won&#039;t change the children&#039;s name in the copied object. `NO_RENAME`: will change no name in the copied object&lt;br&gt;&lt;br&gt;&lt;br&gt;`rename_prefix` *string*&lt;br&gt;A prefix to copy names. Defaults to null if not provided.&lt;br&gt;&lt;br&gt;&lt;br&gt;`rename_suffix` *string*&lt;br&gt;A suffix to copy names. Defaults to null if not provided and appends a localized string of `- Copy` based on the ad account locale.&lt;br&gt; |
| `status_option`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, INHERITED_FROM_SOURCE&#125;* | **Default value: **`PAUSED`&lt;br&gt;`ACTIVE`: the copied ad will have active status. `PAUSED`: the copied ad will have paused status. `INHERITED_FROM_SOURCE`: the copied ad will have the parent status.&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *copied_ad_id* in the return type.
```
Struct &#123;
copied_ad_id: numeric string,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 200 | Permissions error |
### /act_&#123;ad_account_id&#125;/ads
You can make a POST request to *ads* edge from the following paths:
- [/act_&#123;ad_account_id&#125;/ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account/ads)
When posting to this edge, an [Ad](https://developers.facebook.com/docs/graph-api/reference/adgroup) will be created.
#### Example
### HTTP
```
POST /v25.0/act_&lt;AD_ACCOUNT_ID&gt;/ads HTTP/1.1
Host: graph.facebook.com
name=My+Ad&amp;adset_id=%3CAD_SET_ID%3E&amp;creative=%7B%22creative_id%22%3A%22%3CCREATIVE_ID%3E%22%7D&amp;status=PAUSED
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;post(
&#039;/act_&lt;AD_ACCOUNT_ID&gt;/ads&#039;,
array (
&#039;name&#039; =&gt; &#039;My Ad&#039;,
&#039;adset_id&#039; =&gt; &#039;&lt;AD_SET_ID&gt;&#039;,
&#039;creative&#039; =&gt; &#039;&#123;&quot;creative_id&quot;:&quot;&lt;CREATIVE_ID&gt;&quot;&#125;&#039;,
&#039;status&#039; =&gt; &#039;PAUSED&#039;,
),
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;/act_&lt;AD_ACCOUNT_ID&gt;/ads&quot;,
&quot;POST&quot;,
&#123;
&quot;name&quot;: &quot;My Ad&quot;,
&quot;adset_id&quot;: &quot;&lt;AD_SET_ID&gt;&quot;,
&quot;creative&quot;: &quot;&#123;\&quot;creative_id\&quot;:\&quot;&lt;CREATIVE_ID&gt;\&quot;&#125;&quot;,
&quot;status&quot;: &quot;PAUSED&quot;
&#125;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
Bundle params = new Bundle();
params.putString(&quot;name&quot;, &quot;My Ad&quot;);
params.putString(&quot;adset_id&quot;, &quot;&lt;AD_SET_ID&gt;&quot;);
params.putString(&quot;creative&quot;, &quot;&#123;\&quot;creative_id\&quot;:\&quot;&lt;CREATIVE_ID&gt;\&quot;&#125;&quot;);
params.putString(&quot;status&quot;, &quot;PAUSED&quot;);
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;/act_&lt;AD_ACCOUNT_ID&gt;/ads&quot;,
params,
HttpMethod.POST,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
NSDictionary *params = &#064;&#123;
&#064;&quot;name&quot;: &#064;&quot;My Ad&quot;,
&#064;&quot;adset_id&quot;: &#064;&quot;&lt;AD_SET_ID&gt;&quot;,
&#064;&quot;creative&quot;: &#064;&quot;&#123;\&quot;creative_id\&quot;:\&quot;&lt;CREATIVE_ID&gt;\&quot;&#125;&quot;,
&#064;&quot;status&quot;: &#064;&quot;PAUSED&quot;,
&#125;;
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;/act_&lt;AD_ACCOUNT_ID&gt;/ads&quot;
parameters:params
HTTPMethod:&#064;&quot;POST&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
### cURL
```
curl -X POST \
-F &#039;name=&quot;My Ad&quot;&#039; \
-F &#039;adset_id=&quot;&lt;AD_SET_ID&gt;&quot;&#039; \
-F &#039;creative=&#123;
&quot;creative_id&quot;: &quot;&lt;CREATIVE_ID&gt;&quot;
&#125;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/ads
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=POST&amp;path=act_%3CAD_ACCOUNT_ID%3E%2Fads%3Fname%3DMy%2BAd%26adset_id%3D%253CAD_SET_ID%253E%26creative%3D%257B%2522creative_id%2522%253A%2522%253CCREATIVE_ID%253E%2522%257D%26status%3DPAUSED&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
| Parameter | Description |
| --- | --- |
| `ad_schedule_end_time`&lt;br&gt;&lt;br&gt;*datetime* | An optional parameter that defines the end time of an individual ad. If no end time is defined, the ad will run on the campaign’s schedule.&lt;br&gt;&lt;br&gt;&lt;br&gt;This parameter is only available for sales and app promotion campaigns.&lt;br&gt; |
| `ad_schedule_start_time`&lt;br&gt;&lt;br&gt;*datetime* | An optional parameter that defines the start time of an individual ad. If no start time is defined, the ad will run on the campaign’s schedule.&lt;br&gt;&lt;br&gt;&lt;br&gt;This parameter is only available for sales and app promotion campaigns.&lt;br&gt; |
| `adlabels`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | Ad labels associated with this ad&lt;br&gt; |
| `adset_id`&lt;br&gt;&lt;br&gt;*int64* | The ID of the ad set, required on creation.&lt;br&gt; |
| `adset_spec`&lt;br&gt;&lt;br&gt;*Ad set spec* | The ad set spec for this ad. When the spec is provided, adset_id field is not required.&lt;br&gt; |
| `audience_id`&lt;br&gt;&lt;br&gt;*string* | The ID of the audience.&lt;br&gt; |
| `bid_amount`&lt;br&gt;&lt;br&gt;*integer* | **Deprecated.** We no longer allow setting the `bid_amount` value on an ad. Please set `bid_amount` for the ad set.&lt;br&gt; |
| `conversion_domain`&lt;br&gt;&lt;br&gt;*string* | The domain where conversions happen. Required to create or update an ad in a campaign that shares data with a pixel. This field will be auto-populated for existing ads by inferring from destination URLs . Note that this field should contain only the first and second level domains, and not the full URL. For example `facebook.com`.&lt;br&gt; |
| `creative`&lt;br&gt;&lt;br&gt;*AdCreative* | This field is required for create. The ID or creative spec of the ad creative to be used by this ad. You can read more about creatives [here](https://developers.facebook.com/docs/marketing-api/adcreative). You may supply the ID within an object as follows:&lt;br&gt;&lt;br&gt;`&#123;&quot;creative_id&quot;: &lt;CREATIVE_ID&gt;&#125;`&lt;br&gt;or creative spec as follow:&lt;br&gt;&lt;br&gt; `&#123;&quot;creative&quot;: &#123;\&quot;name\&quot;: \&quot;&lt;NAME&gt;\&quot;, \&quot;object_story_spec\&quot;: &lt;SPEC&gt;&#125;&#125;`&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;**[supports emoji]**&lt;br&gt; |
| `creative_asset_groups_spec`&lt;br&gt;&lt;br&gt;*string (CreativeAssetGroupsSpec)* | creative_asset_groups_spec&lt;br&gt;&lt;br&gt;**[supports emoji]**&lt;br&gt; |
| `date_format`&lt;br&gt;&lt;br&gt;*string* | The format of the date.&lt;br&gt; |
| `display_sequence`&lt;br&gt;&lt;br&gt;*int64* | The sequence of the ad within the same campaign&lt;br&gt; |
| `engagement_audience`&lt;br&gt;&lt;br&gt;*boolean* | Flag to create a new audience based on users who engage with this ad&lt;br&gt; |
| `execution_options`&lt;br&gt;&lt;br&gt;*list&lt;enum&#123;validate_only, synchronous_ad_review, include_recommendations&#125;&gt;* | **Default value: **`Set`&lt;br&gt;An execution setting&lt;br&gt; `validate_only`: when this option is specified, the API call will not perform the mutation but will run through the validation rules against values of each field. &lt;br&gt;`include_recommendations`: this option cannot be used by itself. When this option is used, recommendations for ad object&#039;s configuration will be included. A separate section [recommendations](https://developers.facebook.com/docs/marketing-api/reference/ad-recommendation) will be included in the response, but only if recommendations for this specification exist.&lt;br&gt;`synchronous_ad_review`: this option should not be used by itself. It should always be specified with `validate_only`. When these options are specified, the API call will perform Ads Integrity validations, which include message language checking, image 20% text rule, and so on, as well as the validation logics.&lt;br&gt;If the call passes validation or review, response will be `&#123;&quot;success&quot;: true&#125;`. If the call does not pass, an error will be returned with more details. These options can be used to improve any UI to display errors to the user much sooner, e.g. as soon as a new value is typed into any field corresponding to this ad object, rather than at the upload/save stage, or after review.&lt;br&gt; |
| `include_demolink_hashes`&lt;br&gt;&lt;br&gt;*boolean* | Include the demolink hashes.&lt;br&gt; |
| `name`&lt;br&gt;&lt;br&gt;*string* | Name of the ad.&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;**[supports emoji]**&lt;br&gt; |
| `priority`&lt;br&gt;&lt;br&gt;*int64* | Priority&lt;br&gt; |
| `source_ad_id`&lt;br&gt;&lt;br&gt;*numeric string or integer* | ID of the source Ad, if applicable.&lt;br&gt; |
| `status`&lt;br&gt;&lt;br&gt;*enum&#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | Only `ACTIVE` and `PAUSED` are valid during creation. Other statuses&lt;br&gt;can be used for update. When an ad is created, it will first go through&lt;br&gt;ad review, and will have the ad status `PENDING_REVIEW` before it&lt;br&gt;finishes review and reverts back to your selected status of `ACTIVE`&lt;br&gt;or `PAUSED`. During testing, it is recommended to set ads to a `PAUSED`&lt;br&gt;status so as to not incur accidental spend.&lt;br&gt; |
| `tracking_specs`&lt;br&gt;&lt;br&gt;*Object* | With Tracking Specs, you log actions taken by people on your ad. See [Tracking and Conversion Specs](https://developers.facebook.com/documentation/ads-commerce/marketing-api/tracking-specs).&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *id* in the return type.
```
Struct &#123;
id: numeric string,
success: bool,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 200 | Permissions error |
| 613 | Calls to this api have exceeded the rate limit. |
| 368 | The action attempted has been deemed abusive or is otherwise disallowed |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 194 | Missing at least one required parameter |
| 500 | Message contains banned content |
| 2635 | You are calling a deprecated version of the Ads API. Please update to the latest version. |
| 190 | Invalid OAuth 2.0 Access Token |
| 105 | The number of parameters exceeded the maximum for this operation |
## Updating
Update certain fields:
```html
curl -X POST \
-F &#039;name=&quot;My New Ad&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_ID&gt;/
```
### Limitations
- Only update fields that were used during ad creation can be updated.
- `adset_id` and `social_prefs` can not be updated.
- Ads with `status = ARCHIVED` have only two mutable fields: `name` and `status`. You can only change the latter to `DELETED`.
- Ads with `status = DELETED` only can have `name` changed.
- Ads in an ad set with `creative_sequence` set cannot be changed to `PAUSED`, `ARCHIVED`, or `DELETED`.
- Trying to duplicate existing objective campaigns to use the new objective values (`OUTCOME_APP_PROMOTION`, `OUTCOME_AWARENESS`, `OUTCOME_ENGAGEMENT`, `OUTCOME_LEADS`, `OUTCOME_SALES`, `OUTCOME_TRAFFIC`) may throw an error.
### Examples
Update the name:
```html
curl -X POST \
-F &#039;name=&quot;My New Ad&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_ID&gt;/
```
Update the name and download ad information:
```html
curl -X POST \
-F &#039;adgroup_status=&quot;PAUSED&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_ID&gt;/
```
Update the status:
```html
curl -X POST \
-F &#039;adgroup_status=&quot;PAUSED&quot;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_ID&gt;/
```
You can&#039;t perform this operation on this endpoint.
## Deleting
#### Deleting an ad
You can remove values for any optional fields by [updating](#Updating) the value to empty. You cannot delete ads in ad set with `creative_sequence` settings.
```html
curl -X DELETE \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;AD_ID&gt;/
```
### /&#123;ad_id&#125;
You can delete an [Ad](https://developers.facebook.com/docs/graph-api/reference/adgroup) by making a DELETE request to [/&#123;ad_id&#125;](https://developers.facebook.com/docs/graph-api/reference/adgroup).
#### Example
### HTTP
```
DELETE /v25.0/&lt;ADGROUP_ID&gt;/ HTTP/1.1
Host: graph.facebook.com
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;delete(
&#039;/&lt;ADGROUP_ID&gt;/&#039;,
array (),
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;/&lt;ADGROUP_ID&gt;/&quot;,
&quot;DELETE&quot;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;/&lt;ADGROUP_ID&gt;/&quot;,
null,
HttpMethod.DELETE,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;/&lt;ADGROUP_ID&gt;/&quot;
parameters:params
HTTPMethod:&#064;&quot;DELETE&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
### cURL
```
curl -X DELETE -G \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/&lt;ADGROUP_ID&gt;/
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=DELETE&amp;path=%3CADGROUP_ID%3E%2F&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
This endpoint doesn&#039;t have any parameters.
#### Return Type
```
Struct &#123;
success: bool,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 200 | Permissions error |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 368 | The action attempted has been deemed abusive or is otherwise disallowed |
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/llms.txt
