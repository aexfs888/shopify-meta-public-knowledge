- Shopify Help Center | Manage your custom pixels
Help
Log in
Contents
# Manage your custom pixels
You can manage your custom pixels in the Customer events area of your Shopify admin. Before you add a custom pixel to your Shopify store, you need to create the code for your custom pixel .
## On this page
Add a custom pixel
- Connect a custom pixel
- Disconnect a custom pixel
- Delete a custom pixel
- Manage customer privacy settings
## Add a custom pixel
After you create the code for your custom pixel , you can add it to your Shopify store.
Before you add a custom pixel, remove or modify any existing pixels to ensure customer events aren't counted twice. Existing pixel code should be manually removed from any place it exists, such as theme.liquid , checkout.liquid (Stores on the Shopify Plus plan only), and the Additional scripts in your checkout settings.
#### Steps:
-
From your Shopify admin, go to Settings > Customer events .
-
Give your pixel a unique name. If you enter the name of a custom pixel that already exists, then you'll be prompted to give your pixel a different name.
-
Click Add pixel to open the event editor.
-
Optional: In the Customer privacy section, select the Permission and Data sale settings that you want to adjust. Learn more about managing app pixel customer privacy .
-
Paste your custom javascript pixel code into the Code window.
-
Click Save . If you're ready to connect your custom pixel now, then you can click Connect pixel to start tracking your events.
## Connect a custom pixel
After a custom pixel has been added, you need to connect the pixel to your store so that it can start tracking customer events.
#### Steps:
-
From your Shopify admin, go to Settings > Customer events .
-
Click Custom pixels .
-
Custom pixels that aren't currently connected are displayed under the heading Disconnected pixels . Click Connect on the appropriate custom pixel line.
-
After you confirm that your pixel satisfies the service requirements of Shopify's Terms of Service , click Connect .
## Disconnect a custom pixel
If you want to stop tracking the events you added a custom pixel for, then you need to manually disconnect the pixel from your online store. Disconnecting the pixel doesn't delete the pixel.
#### Steps:
-
From your Shopify admin, go to Settings > Customer events .
-
Click Custom pixels .
-
Click Disconnect on the custom pixel that you want to disconnect.
## Delete a custom pixel
You can delete custom pixels that you no longer need. Deleting a custom pixel can't be undone, so ensure that you're deleting the appropriate pixel.
#### Steps:
-
From your Shopify admin, go to Settings > Customer events .
-
Click Custom pixels .
-
Click the button on the custom pixel line that you want to delete.
-
Click Delete , and then in the dialog, click Delete .
## Manage customer privacy settings
You can manage the customer privacy settings for each of the custom pixels on your store. Your customer privacy settings determine when Pixels collects data, and for which purposes. The customer data that you collect can help provide insights about customer behavior on your website. Learn more about the impact of cookie-based customer data collection and analytics .
The following customer privacy settings apply to your custom pixels:
- The Permission setting lets you determine whether customer permission is required under applicable laws for your custom pixel to collect data for marketing, analytics, and preferences purposes. To request customer consent to collect data based on your Permission setting, you need to add a cookie banner to your store .
- The Data sale setting lets you manage how your custom pixel collects data in cases where the customer has opted out of their data being sold, as provided for in certain jurisdictions. Learn more about data sales opt-out .
#### Steps:
-
From your Shopify admin, go to Settings > Customer events .
-
Click the Custom pixels tab.
-
Click the custom pixel that you want to manage.
-
Optional: In the Customer privacy section, click Permission , and then do either of the following:
To require customer permission for your custom pixel to collect data, select Required , and then select the data purposes that you want to require customer permission for.
- If you don't want to require customer permission for your custom pixel to collect data, then select Not required .
-
Optional: In the Customer privacy section, click Data sale , and then select the data sale collection permissions that you want to set for your custom pixel.
-
Click Save .
Leave feedback
