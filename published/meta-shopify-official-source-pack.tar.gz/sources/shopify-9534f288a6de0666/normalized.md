- Shopify Help Center | Requirements and considerations for using Facebook and Instagram by Meta
Help
Log in
Contents
# Requirements and considerations for using Facebook and Instagram by Meta
You can review the eligibility requirements and the considerations for installing and using the Facebook and Instagram by Meta sales channel before setting up in your Shopify admin. Reviewing requirements before setup can help you avoid errors and ensure a smooth connection between your store and Meta's commerce platform.
## On this page
Requirements for using Facebook and Instagram by Meta
- Meta's Commerce eligibility requirements
- Considerations for using Facebook and Instagram by Meta
- Tax compliance considerations
## Requirements for using Facebook and Instagram by Meta
There are various criteria for being able to use the Facebook and Instagram by Meta sales channel. Review the following details:
- You must have a Shopify online store and it can’t be in private mode .
- The Sender email for your Shopify store must be a valid email address.
- You must have a Facebook account. If you don't have a Facebook account before you install the sales channel in your Shopify admin, then you're prompted to sign up for one.
- Your business must have its own published Facebook Page. You also need to have a business portfolio that's connected to your business's Facebook Page. Your personal Facebook account must have full control of both the business portfolio and the business’s Facebook Page. A single business portfolio can include multiple Facebook Pages.
- If you have a personal ad account, then you can connect it to your business portfolio. If you've never run ads with a personal ad account, then you need to add an ad account to your business portfolio before you can create Meta ad campaigns. You can only add an ad account if you have full control of the business portfolio.
## Meta's Commerce eligibility requirements
To set up a shop on Facebook and Instagram, and to be eligible to list your products for sale, you must meet Meta's Commerce eligibility requirements , which include the following details:
- If you want to sell on Instagram, then your account needs to be a professional account that's associated with the Facebook Page for your business. Learn how to convert an Instagram account to a professional profile or convert an Instagram account to a creator account from Instagram Help.
- Your Facebook Page must comply with Meta's Terms of Service , Commercial Terms , and Community Standards .
- Your Instagram professional account must comply with Instagram's Terms of Use , and Meta's Community Standards .
- Your products must be available for direct purchase from your verified domain.
- Your business must be located in one of the Supported countries for Shops on Facebook and Instagram .
## Considerations for using Facebook and Instagram by Meta
Review the following considerations for using the Facebook and Instagram by Meta sales channel:
- The Facebook and Instagram by Meta sales channel contains a single product catalog for shops on Facebook and Instagram, and for using with ads. All the products in your catalog are available to all three features. If you make a product unavailable to the sales channel, then the product is removed from all three features.
- If you install Facebook and Instagram by Meta and connect any associated Facebook accounts, then disconnecting any of those accounts can result in disconnecting all active Facebook features.
- All products sold on Facebook and Instagram need to comply with Meta’s Commerce Policy . If you want to advertise your products, then you must also comply with the Advertising Standards .
- All products that are uploaded to Facebook and Instagram by Meta go through Facebook's review process. If your product violates Facebook's policies, then your product might be removed from Facebook and Instagram by Meta. If you believe a product was incorrectly rejected or removed, then you can request a review of a rejected item from Facebook's support team .
- To sell on Meta technologies, you need to maintain a good feedback score for your business portfolio . Your feedback score is determined using feedback from the Audience Network and from customers who make purchases using Meta technologies, including on Instagram. If your business receives poor feedback scores on topics such as delivery speed, product quality, or customer service, then Meta might display your ads less frequently on Meta technologies.
- Your customers’ purchase and checkout experience can differ in the following ways depending on how they find your products:
A customer can follow a link from one of your adverts that takes them directly to a product page on your Shopify online store, from where they can add products to their cart and proceed to checkout as normal.
- A customer can also visit a product page directly in your Facebook or Instagram shop. They add products to their cart in the Facebook or Instagram mobile app, and then they select Checkout on seller’s website to be redirected to your Shopify online store where they can complete their purchase.
- The Shopify admin is unable to support arbitrary partial refunds on orders from Facebook and Instagram by Meta created before August 26th, 2025. If you're issuing a refund in the Shopify admin for an order placed before that date, then it should be for the entire order. If you need to provide a partial refund, then you can complete it in the Facebook Commerce Manager . If you're unable to complete a refund for a payment charged with Shopify Payments, then the store owner can contact Shopify Support for further assistance.
## Tax compliance considerations
As of August 26, 2025, you're responsible for the following tax practices:
- Collecting sales tax on orders placed through the Facebook and Instagram sales channel.
- Ensuring your Shopify tax settings are properly configured for all sales channels.
- Filing and remitting taxes according to your local requirements.
Meta is no longer a marketplace tax facilitator for new orders created as of August 26, 2025. Customers are now redirected to the online store to complete their purchase instead of Meta handling checkout natively on their platform.
For guidance on tax setup, refer to Setting up taxes .
If you meet these requirements and are still experiencing errors when you install or connect the channel, then refer to Onboarding error messages for troubleshooting steps.
Leave feedback
