---
title: DOM Pixel Events API
source_url:
html: 'https://shopify.dev/docs/api/web-pixels-api/dom-events'
md: 'https://shopify.dev/docs/api/web-pixels-api/dom-events.md'
api_name: web-pixels
---
# DOM Pixel Events API
***
## Track user interactions
The DOM Events API provides a subset of user interaction events. It can be used to better understand user journeys and interactions. The API provides these events across the Storefront, Checkout and Thank you pages.
**Unavailable on Customer Accounts:**
The DOM Events API is not available on Customer Account pages, and the Order status page shown after the Thank you page.
[clicked](https://shopify.dev/docs/api/web-pixels-api/dom-events/clicked)
[The clicked event logs an instance where a customer clicks on a page element.](https://shopify.dev/docs/api/web-pixels-api/dom-events/clicked)
[form​\_submitted](https://shopify.dev/docs/api/web-pixels-api/dom-events/form_submitted)
[The form\_submitted event logs an instance where a form on a page is submitted.](https://shopify.dev/docs/api/web-pixels-api/dom-events/form_submitted)
[input​\_blurred](https://shopify.dev/docs/api/web-pixels-api/dom-events/input_blurred)
[The input\_blurred event logs an instance where an input on a page loses focus.](https://shopify.dev/docs/api/web-pixels-api/dom-events/input_blurred)
[input​\_changed](https://shopify.dev/docs/api/web-pixels-api/dom-events/input_changed)
[The input\_changed event logs an instance where an input value changes.](https://shopify.dev/docs/api/web-pixels-api/dom-events/input_changed)
[input​\_focused](https://shopify.dev/docs/api/web-pixels-api/dom-events/input_focused)
[The input\_focused event logs an instance where an input on a page gains focus.](https://shopify.dev/docs/api/web-pixels-api/dom-events/input_focused)
***
