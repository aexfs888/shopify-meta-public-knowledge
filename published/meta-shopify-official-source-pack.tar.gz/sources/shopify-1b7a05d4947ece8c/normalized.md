DOM Pixel Events API Skip to main content
##
Anchor to Track user interactions Track user interactions
The DOM Events API provides a subset of user interaction events. It can be used to better understand user journeys and interactions. The API provides these events across the Storefront, Checkout and Thank you pages.
Unavailable on Customer Accounts
The DOM Events API is not available on Customer Account pages, and the Order status page shown after the Thank you page.
Unavailable on Customer Accounts :
The DOM Events API is not available on Customer Account pages, and the Order status page shown after the Thank you page.
clicked
The clicked event logs an instance where a customer clicks on a page element.
form _submitted
The form_submitted event logs an instance where a form on a page is submitted.
input _blurred
The input_blurred event logs an instance where an input on a page loses focus.
input _changed
The input_changed event logs an instance where an input value changes.
input _focused
The input_focused event logs an instance where an input on a page gains focus.
Was this page helpful?
Yes No
