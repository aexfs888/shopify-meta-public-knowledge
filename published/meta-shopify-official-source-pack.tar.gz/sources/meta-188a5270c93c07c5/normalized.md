-
API de marketing | Meta | Meta for Developers
Anuncios y comercio
# API de marketing
La API de marketing es una colección de puntos de conexión de la API Graph y otras funciones que puedes usar para anunciarte en las tecnologías de Meta. Antes de publicar anuncios en Facebook, Instagram, Messenger y WhatsApp, te recomendamos que aprendas sobre la estructura de las campañas publicitarias de Meta para entender los objetos con los que trabajas y cómo se relacionan entre sí.
Primeros pasos
## Empezar
Comienza a crear y administrar campañas publicitarias de Meta siguiendo la guía paso a paso para configurar campañas, conjuntos de anuncios y contenido creativo mediante la API de marketing
Creación básica de anuncios
Obtén una guía detallada sobre cómo configurar campañas, conjuntos de anuncios y contenidos, incluidos ejemplos de códigos que ilustran el proceso de implementación.
Más información
Administrar campañas
Obtén información sobre las operaciones clave que puedes realizar con la API de marketing, incluso cómo modificar, pausar y eliminar campañas.
Más información
Aspectos básicos de la optimización de anuncios
Usa los puntos de conexión de la API de marketing que sirven de herramientas esenciales para que los desarrolladores administren públicos y analicen las estadísticas de las campañas publicitarias.
Más información
## API relacionadas
Explora API adicionales para mejorar la segmentación de anuncios, administrar catálogos, mantener la presencia comercial e integrar herramientas comerciales en las tecnologías de Meta
API de conversiones
Conecta los datos de marketing de tus servidores con los sistemas de Meta que optimizan la segmentación de anuncios, reducen el costo por acción y miden los resultados.
Más información
API de catálogo
Crea un catálogo de artículos que quieras promocionar y úsalo para publicar anuncios, vender desde una tienda en Facebook o Instagram, y más.
Más información
API de administración comercial
Crea y mantén la presencia paga y orgánica de tu negocio en Facebook, Instagram, Messenger y WhatsApp.
Más información
API de comercio
Permite a las empresas integrar su infraestructura con las herramientas disponibles para vender productos en las tecnologías de Meta, incluidas las tiendas y Marketplace.
Más información
## Herramientas y recursos
Administrador de anuncios ⁠ .
- Administrador comercial ⁠
- Administrador de ventas ⁠
- Panel de apps
- SDK para empresas de Meta
- Estado de la API de marketing ⁠
- Meta Blueprint ⁠
- Foros de la comunidad de desarrolladores de Meta
