-
Marketing API | Meta | Meta for Developers
Ads and Commerce
# Marketing API
The Marketing API is a collection of Graph API endpoints and other features that can be used to help you advertise across Meta technologies. Before advertising on Facebook, Instagram, Messenger, and WhatsApp, we recommend you learn about Meta's ad campaign structure to understand the objects you're working with and how they relate to each other.
Get started
## Get Started
Begin creating and managing Meta ad campaigns by following step-by-step guidance on setting up campaigns, ad sets, and creatives using the Marketing API
Basic Ad Creation
Get detailed guidance on how to set up campaigns, ad sets, and ad creatives, including code samples that illustrate the implementation process.
Learn more
Manage Campaigns
Learn key operations you can perform using the Marketing API, including how to modify, pause and delete campaigns.
Learn more
Ad Optimization Basics
Use Marketing API endpoints that serve as essential tools for developers to manage audiences and analyze ad campaign insights.
Learn more
## Related APIs
Explore additional APIs to enhance ad targeting, manage catalogs, maintain business presence, and integrate commerce tools across Meta technologies
Conversions API
Connect the marketing data on your servers to the Meta systems that optimize ad targeting, decrease cost per action, and measure results.
Learn more
Catalog API
Create a catalog of items you want to promote and use it to run ads, sell from a shop on Facebook or Instagram, and more.
Learn more
Business Management API
Create and maintain your business's organic and paid presence on Facebook, Instagram, Messenger, and WhatsApp.
Learn more
Commerce API
Enables businesses to integrate their infrastructure with the tools available to sell products across Meta technologies, including shops and Marketplace.
Learn more
## Tools and Resources
Ads Manager ⁠ .
- Business Manager ⁠
- Commerce Manager ⁠
- App Dashboard
- Meta Business SDK
- Marketing API Status ⁠
- Meta Blueprint ⁠
- Meta Developer Community Forums
