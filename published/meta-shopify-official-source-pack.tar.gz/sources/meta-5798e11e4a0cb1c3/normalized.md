-
Meta Blueprint Startup Hub : Learn new skills to build your brand or business
Skip to main content
This site uses cookies to provide you with a greater user experience. By using Exceed LMS, you accept our use of cookies .
Search
Topics
##
All Topics
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
Log In
Welcome to the Meta Startup Hub. This course covers a series of 6 learning modules with the main aim of getting your Startup set up for success on Meta from the beginning.
-
###
Getting started with Meta Ads Manager
Learn how to create an ad campaign in Meta Ads Manager and customize reports with Ads Reporting.
Duration
20m
-
Rating 4.7
- Beginner
-
###
Implementing buying types and optimizing delivery
Learn how to set up a campaign through the auction and reservation buying types in Meta Ads Manager.
Duration
32m
-
Rating 4.7
- Intermediate
-
Credential
-
###
Determining the best buying type and bid strategy
Explore the available buying types and bid strategies for your campaigns.
Duration
28m
-
Rating 4.8
- Intermediate
-
Credential
-
###
Introduction to campaign objectives
Learn how to define business goals, select the correct ad objective and measure success in Meta Ads Manager.
Duration
15m
-
Rating 4.8
- Intermediate
-
###
Proposing a campaign budget
Learn how to create a budget for auction and reservation buying types.
Duration
18m
-
Rating 4.7
- Intermediate
-
###
Use Meta App Events to target, optimize and measure
Learn ways to use App Events to improve your business targeting, optimization and measurement practices.
Duration
15m
-
Rating 5.0
- Beginner
-
###
Optimize and troubleshoot the Meta Pixel
This course helps you set up and implement custom conversions and troubleshoot the Meta Pixel so you can optimize your ads.
Duration
40m
-
Rating 4.9
- Advanced
-
Credential
-
###
Set up the Meta Pixel and Meta Conversions API for ad campaigns
Use the Meta Pixel and the Conversions API to gain insight into customer actions and optimize your advertising strategy.
Duration
10m
-
Rating 4.9
- Beginner
-
Credential
-
###
Optimize Meta Conversions API
Learn how to optimize Meta Conversions API to help improve ad performance.
Duration
30m
-
Rating 4.8
- Intermediate
-
Credential
-
###
Optimise your campaign with Meta Advantage
This course covers the purpose and use cases for the AI ad tools within Meta Advantage.
Duration
30m
- Intermediate
-
Credential
-
###
Improve your advertising with Advantage+ catalog ads
Learn how to use Advantage+ catalog ads to dynamically deliver personalized ads and product recommendations to customers.
Duration
20m
-
Rating 4.9
- Beginner
-
Credential
-
###
Troubleshooting catalog for Advantage+ catalog ads
This training helps you troubleshoot a catalog for Advantage+ catalog ads and prepare for the Meta Certified Marketing Developer Exam.
Duration
10m
-
Rating 4.7
- Beginner
-
Credential
-
###
Understanding Meta Advertising Standards
Learn how to comply with Meta Advertising Standards to effectively place ads with Meta.
Duration
15m
-
Rating 4.8
- Beginner
-
###
Customize ad creative in Meta Ads Manager
Learn how to create ads and review format, placement and creative options in Ads Manager.
Duration
15m
-
Rating 5.0
- Intermediate
-
###
Introduction to measurement methodologies
This course prepares you to compare experimental and observational measurement methods and recognize when to implement A/B tests vs. randomized controlled trials (RCTs).
Duration
30m
-
Rating 5.0
- Advanced
-
Credential
-
###
Designing A/B tests, conversion lift tests and brand lift tests
In this course, you will learn how to design A/B tests, conversion lift tests and brand lift tests to prove or disprove your test hypothesis and recognize next steps for possible outcomes.
Duration
10m
-
Rating 5.0
- Intermediate
-
Credential
-
###
Get started with Audience Network
Learn how to use Meta's Audience Network to monetize your app, how to integrate the SDK for Audience Network and how to choose ad formats.
Duration
15m
-
Rating 4.9
- Advanced
-
Credential
-
###
Monetise your app with Audience Network
Audience Network advertising bidding monetise monetisation app games app development advertisers publishers
Duration
15m
- Intermediate
-
Credential
-
###
Measure and optimise your Audience Network ad performance
This course prepares you to use Monetisation Manager to measure ad performance, improve your results with data and optimise your bidding strategy.
Duration
15m
- Intermediate
-
Credential
##
All Topics
-
Increase sales
-
Get started with advertising
-
Your guide to audience targeting
-
Manage ads with automated tools
-
Get results that matter to your business
-
Optimize your campaigns
-
Creative inspiration
-
Opportunity score
-
All Activities
##
Review
##
Warning: Closing this page may affect activity tracking!
This page is used by your activity to communicate with the learning platform. Please be sure to close all activity windows before closing or navigating away from this page.
Return to activity
Did you arrive on this page without seeing a new activity window launch? You may have a pop-up blocker. Check out pop-up blocker tips here.
