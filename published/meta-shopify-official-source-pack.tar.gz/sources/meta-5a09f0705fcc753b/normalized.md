# Handling Duplicate Pixel and Conversions API Events
For optimal ad performance, we recommend that advertisers implement the Conversions API alongside their Meta Pixel. We call this a &quot;redundant setup&quot; and detail more about this recommended approach [here](https://developers.facebook.com/documentation/ads-commerce/conversions-api/guides/end-to-end-implementation#pick-your-integration-type).
When advertisers use a redundant setup, they must set up a deduplication method to ensure that the ad delivery system is able to differentiate between distinct and overlapping events. This document describes multiple deduplication method options to help Facebook deduplicate your events.
Advertisers who do not send the same event twice via both the Conversions API and Meta Pixel do not need to set up deduplication for those events.
**Warning:** The Conversions API now enables advertisers to send web, app, and physical store events to Meta through a single endpoint rather than across multiple. Learn more about [the Conversions API](https://developers.facebook.com/documentation/ads-commerce/conversions-api).
## Event deduplication options
Facebook tries to deduplicate identical events sent through Meta Pixel and the Conversions API. We have two ways of deduplicating your events:
### Event ID and event name (recommended)
#### Required parameters
For this approach, the `event_id` parameter is added to your events from both the Conversions API and the browser Pixel. The `event_id` parameter is an identifier that can uniquely distinguish between similar events. Read more about [the `event_id` parameter](https://developers.facebook.com/documentation/ads-commerce/conversions-api/parameters/server-event#event-id).
#### Approach description
We determine if events are identical based on their **ID** and **name**. So, for an event to be deduplicated:
1. In corresponding events, a Meta Pixel&#039;s `eventID` must match the Conversion API&#039;s `event_id`.
2. In corresponding events, a Meta Pixel&#039;s `event` must match the Conversion API&#039;s `event_name`.
Once the events are received, we employ a number of strategies to deduplicate between the events which may help improve optimization and measurement. If server and browser events do not differ meaningfully in their content, we generally prefer the event that is received first.
Note that the `eventID` parameter for the Pixel is the fourth argument in the `fbq` track call.
**Example**
```js
fbq(&#039;track&#039;, &#039;Purchase&#039;, &#123;value: 12, currency: &#039;USD&#039;&#125;, &#123;eventID: &#039;EVENT_ID&#039;&#125;);
```
### FBP or external ID
#### Required parameters
For this approach, you must use `event_name`, `fbp` and/or `external_id` consistently across browser and server events. See [Customer Information Parameters](https://developers.facebook.com/documentation/ads-commerce/conversions-api/parameters/customer-information-parameters) for more information about the `external_id` and `fbp` parameters.
#### Approach description
If you have configured the `external_id` and/or `fbp` parameters to be passed via both browser and server, we take care to remove duplicate events automatically. This is how the process works:
1. You send us a browser event with `event_name` and `fbp` and/or `external_id`.
2. Then, you send us a server event with `event_name` and `fbp` and/or `external_id`.
3. We compare the server event with the previously sent browser event. Specifically, we compare the `event_name` and `fbp` and/or `external_id` combinations.
4. We employ a number of strategies to deduplicate between the events which may help improve optimization and measurement. If server and browser events do not differ meaningfully in their content, we generally prefer the event that is received first.
#### Approach limitations
This deduplication method:
* Generally, it only works for deduplicating events sent first from the browser and then through the server. Server events will not be discarded if a browser event has not been received in the past 48 hours, even if an identical browser event arrives after the server event
* Does not deduplicate events when only using one event source, that is browser-only or server-only. If you send us two consecutive browser events with the same information, we do not discard either. If you send us two consecutive server events with the same information, we do not discard either.
## Setting up deduplication on the browser Pixel
For better matching, we need accurate information from your events coming through both Meta Pixel and the Conversions API:
- The `eventID` inside the optional `eventData` parameter should be a unique value. Depending on your Meta Pixel implementation, you can use:
- `track` to send the event for all Pixels on the page
```js
fbq(&#039;track&#039;, &#039;Purchase&#039;, &#123;value: 12, currency: &#039;USD&#039;&#125;, &#123;eventID: &#039;EVENT_ID&#039;&#125;);
```
- `trackSingle` to send the event for one Pixel
```js
fbq(&#039;trackSingle&#039;, &#039;SPECIFIC_PIXEL_ID&#039;, &#039;Purchase&#039;, &#123;value: 12, currency: &#039;USD&#039;&#125;, &#123;eventID: &#039;EVENT_ID&#039;&#125;);
```
- An image Pixel tag with the `eid` parameter
```html
&lt;img src=&quot;https://www.facebook.com/tr?id=PIXEL_ID&amp;ev=Purchase&amp;eid=EVENT_ID&quot;/&gt;
```
If the event you are sharing does not contain parameters such as value and currency, you can set it up as follows:
```js
fbq(&#039;track&#039;, &#039;Lead&#039;, &#123;&#125;, &#123;eventID: &#039;EVENT_ID&#039;&#125;);
```
- The `eventID` from the Meta Pixel must match the `event_id` in the corresponding event coming from the Conversions API.
- If we find the same server key combination (`event_id` and `event_name`) **and** browser key combination (`eventID` and `event`) sent to the same Pixel ID within 48 hours, we discard the subsequent events.
- If you are sending us your events via both browser and the Conversions API along with matching `event_ids`, keep in mind that events are only deduplicated if they are received within 48 hours of when we receive the first event with a given `event_id`.
## Verifying your deduplication setup
Learn how to verify your deduplication and event merging setup in the [Verifying Your Setup](https://developers.facebook.com/documentation/ads-commerce/conversions-api/verifying-setup) documentation.
## Learn more
* [Parameters](https://developers.facebook.com/documentation/ads-commerce/conversions-api/parameters)
* [Payload Helper](https://developers.facebook.com/documentation/ads-commerce/conversions-api/payload-helper)
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
