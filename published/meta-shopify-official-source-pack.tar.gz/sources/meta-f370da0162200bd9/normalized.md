# Meta Business SDK Features for Conversions API
This guide helps you navigate Meta Business SDK advanced features designed especially for Conversions API users. [Asynchronous Requests](#asynchronous-requests), [Concurrent Batching](#concurrent-batching), and [HTTP Service Interface](#http-service-interface) are available in the PHP, NodeJS, Java, Python, and Ruby SDKs. For basic Conversions API usage, refer to the main [Conversions API documentation](https://developers.facebook.com/documentation/ads-commerce/conversions-api/using-the-api#send).
**Note:** The [Meta Business SDK](https://developers.facebook.com/docs/business-sdk) gives you access to our suite of business APIs allowing you to build unique and customized solutions to serve your businesses and clients. One of the APIs available for SDK users is the [Conversions API](https://developers.facebook.com/documentation/ads-commerce/conversions-api).
## Requirements
Before using any of the features listed below, you need to have the Meta Business SDK installed. See [Get Started with the Meta Business SDK](https://developers.facebook.com/docs/business-sdk/getting-started) or the follow the `README` instructions listed here:
- PHP: [`facebook-php-business-sdk`](https://github.com/facebook/facebook-php-business-sdk)
- Node.js: [`facebook-nodejs-business-sdk`](https://github.com/facebook/facebook-nodejs-business-sdk)
- Java: [`facebook-java-business-sdk`](https://github.com/facebook/facebook-java-business-sdk)
- Python: [`facebook-python-business-sdk`](https://github.com/facebook/facebook-python-business-sdk)
- Ruby: [`facebook-ruby-business-sdk`](https://github.com/facebook/facebook-ruby-business-sdk)
Minimum language version required to use these features:
- PHP &gt;= 7.2
- Node.js &gt;= 7.6.0
- Java &gt;= 8
- Python &gt;= 2.7
- Ruby &gt;= 2
## Asynchronous requests &#123;#asynchronous-requests&#125;
Use this feature if you do not want to block your program&#039;s execution to wait for a request to be completed. With this approach, you make your request and get a signal back from the server once the request has been completed. While you wait for the response, the program can keep executing.
Asynchronous requests allow you to use your resources more efficiently, which leads to a decrease in server response time. Asynchronous requests also allow you to have more control on how your program handles errors coming from the server and to easily integrate the SDK into code that already runs asynchronously.
To implement Asynchronous Requests, see code samples in the following languages:
### PHP Business SDK
```php
use FacebookAds\Api;
use FacebookAds\Object\ServerSide\CustomData;
use FacebookAds\Object\ServerSide\Event;
use FacebookAds\Object\ServerSide\EventRequest;
use FacebookAds\Object\ServerSide\EventRequestAsync;
use FacebookAds\Object\ServerSide\UserData;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Promise;
$pixel_id = getenv(&#039;PIXEL_ID&#039;);
$access_token = getenv(&#039;ACCESS_TOKEN&#039;);
if (empty($pixel_id) || empty($access_token)) &#123;
throw new Exception(&#039;Missing required test config. Got pixel_id: &quot;&#039; . $pixel_id . &#039;&quot;, access_token: &quot;&#039; . $access_token . &#039;&quot;&#039;);
&#125;
Api::init(null, null, $access_token, false);
function create_events($num) &#123;
$user_data = (new UserData())
-&gt;setEmail(&#039;joe&#039; . $num . &#039;&#064;eg.com&#039;)
-&gt;setClientIpAddress($_SERVER[&#039;REMOTE_ADDR&#039;])
-&gt;setClientUserAgent($_SERVER[&#039;HTTP_USER_AGENT&#039;]);
$custom_data = (new CustomData())
-&gt;setCurrency(&#039;usd&#039;)
-&gt;setValue(123.45);
$event = (new Event())
-&gt;setEventName(&#039;Purchase&#039;)
-&gt;setEventTime(time())
-&gt;setEventSourceUrl(&#039;http://jaspers-market.com/product/123&#039;)
-&gt;setUserData($user_data)
-&gt;setCustomData($custom_data)
-&gt;setActionSource(ActionSource::WEBSITE);
return array($event);
&#125;
function create_async_request($pixel_id, $num) &#123;
$async_request = (new EventRequestAsync($pixel_id))
-&gt;setEvents(create_events($num));
return $async_request-&gt;execute()
-&gt;then(
null,
function (RequestException $e) &#123;
print(
&quot;Error!!!\n&quot; .
$e-&gt;getMessage() . &quot;\n&quot; .
$e-&gt;getRequest()-&gt;getMethod() . &quot;\n&quot;
);
&#125;
);
&#125;
// Async request:
$promise = create_async_request($pixel_id, 2);
print(&quot;Request 1 state: &quot; . $promise-&gt;getState() . &quot;\n&quot;);
print(&quot;Async request - OK.\n&quot;);
// Async request with wait:
$promise = create_async_request($pixel_id, 3);
$response2 = $promise-&gt;wait();
print(&quot;Request 2: &quot; . $response2-&gt;getBody() . &quot;\n&quot;);
print(&quot;Async request with wait - OK.\n&quot;);
// Multiple async requests:
$promises = [
&quot;Request 3&quot; =&gt; create_async_request($pixel_id, 4),
&quot;Request 4&quot; =&gt; create_async_request($pixel_id, 5),
];
$response3 = Promise\unwrap($promises);
foreach ($response3 as $request_name =&gt; $response) &#123;
print($request_name . &quot;: &quot; . $response-&gt;getBody().&quot;\n&quot;);
&#125;
print(&quot;Async - Multiple async requests OK.\n&quot;);
```
### Python Business SDK
```python
import asyncio
import time
import pprint
import os
import sys
repo_dir = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)
sys.path.insert(1, repo_dir)
from facebook_business.adobjects.serverside.custom_data import CustomData
from facebook_business.adobjects.serverside.event import Event
from facebook_business.adobjects.serverside.event_request import EventRequest
from facebook_business.adobjects.serverside.event_request_async import EventRequestAsync
from facebook_business.adobjects.serverside.user_data import UserData
from facebook_business.api import FacebookAdsApi
def create_events(num):
user_data = UserData(
email=&quot;joe%s&#064;eg.com&quot; % num,
client_ip_address=request.META.get(&#039;REMOTE_ADDR&#039;),
client_user_agent=request.headers[&#039;User-Agent&#039;]
)
custom_data = CustomData(currency=&quot;usd&quot;, value=123.45, item_number=&quot;itemnumber-123&quot;)
event = Event(
event_name=&quot;Purchase&quot;,
event_time=int(time.time()),
user_data=user_data,
custom_data=custom_data,
data_processing_options=[],
event_source_url=&#039;http://jaspers-market.com/product/123&#039;,
action_source=ActionSource.WEBSITE
)
return [event]
async def execute_async_request(pixel_id, num):
event_request_async = EventRequestAsync(
events=create_events(num),
pixel_id=pixel_id
)
return await event_request_async.execute()
async def run_tasks(pixel_id):
tasks = []
for i in range(1,3):
tasks.append(execute_async_request(pixel_id, i))
completed = await asyncio.gather(*tasks)
pp = pprint.PrettyPrinter(indent=4)
pp.pprint(completed)
if __name__ == &#039;__main__&#039;:
pixel_id = os.getenv(&quot;PIXEL_ID&quot;)
access_token = os.getenv(&quot;ACCESS_TOKEN&quot;)
if not (pixel_id and access_token):
raise Exception(&quot;Missing required test config. Got pixel_id: &#039;&#123;pixel_id&#125;&#039;, access_token: &#039;&#123;access_token&#125;&#039;&quot;.format(
pixel_id=pixel_id,
access_token=access_token
))
FacebookAdsApi.init(access_token=access_token, crash_log=False)
asyncio.run(run_tasks(pixel_id))
print(&quot;Create EventRequest Async - OK.&quot;)
```
### Node.js Business SDK
```js
const bizSdk = require(&#039;facebook-nodejs-business-sdk&#039;);
const process = require(&#039;process&#039;);
const ServerEvent = bizSdk.ServerEvent;
const EventRequest = bizSdk.EventRequest;
const UserData = bizSdk.UserData;
const CustomData = bizSdk.CustomData;
const Content = bizSdk.Content;
const access_token = process.env.ACCESS_TOKEN;
const pixel_id = process.env.PIXEL_ID;
void async function() &#123;
try &#123;
if (access_token === undefined || pixel_id === undefined) &#123;
throw new Error(`&quot;Missing required test config. Got pixel_id: &#039;$&#123;pixel_id&#125;&#039;, access_token: &#039;$&#123;access_token&#125;&#039;&quot;`)
&#125;
const api = bizSdk.FacebookAdsApi.init(access_token);
let current_timestamp = Math.floor(new Date() / 1000);
const userData1 = (new UserData())
.setEmail(&#039;joe1&#064;eg.com&#039;)
.setClientIpAddress(request.connection.remoteAddress)
.setClientUserAgent(request.headers[&#039;user-agent&#039;]);
const customData1 = (new CustomData())
.setCurrency(&#039;usd&#039;)
.setCustomProperties(&#123;custom1: &#039;value2&#039;&#125;)
.setValue(123.45);
const serverEvent1 = (new ServerEvent())
.setEventName(&#039;Purchase&#039;)
.setEventTime(current_timestamp)
.setUserData(userData1)
.setCustomData(customData1)
.setEventSourceUrl(&#039;http://jaspers-market.com/product/123&#039;)
.setActionSource(&#039;website&#039;);
const eventRequest1 = (new EventRequest(access_token, pixel_id))
.setEvents([serverEvent1]);
const userData2 = (new UserData())
.setEmail(&#039;joe2&#064;eg.com&#039;)
.setClientIpAddress(request.connection.remoteAddress)
.setClientUserAgent(request.headers[&#039;user-agent&#039;]);
const customData2 = (new CustomData())
.setCurrency(&#039;usd&#039;)
.setCustomProperties(&#123;custom1: &#039;value2&#039;&#125;)
.setValue(123.45);
const serverEvent2 = (new ServerEvent())
.setEventName(&#039;Purchase&#039;)
.setEventTime(current_timestamp)
.setUserData(userData2)
.setCustomData(customData2)
.setEventSourceUrl(&#039;http://jaspers-market.com/product/123&#039;)
.setActionSource(&#039;website&#039;);
const eventRequest2 = (new EventRequest(access_token, pixel_id))
.setEvents([serverEvent2]);
Promise.all([
eventRequest1.execute(),
eventRequest2.execute()
]).then(response =&gt; &#123;
console.log(&#039;Execute 2 Requests OK. Response: &#039;, response);
&#125;, err =&gt; &#123;
console.log(&#039;Error: &#039;, err);
&#125;);
&#125; catch(error) &#123;
console.log(error);
process.exit(1);
&#125;
&#125;();
```
### Java Business SDK
```java
import com.facebook.ads.sdk.APIContext;
import com.facebook.ads.sdk.serverside.Event;
import com.facebook.ads.sdk.serverside.EventRequest;
import com.facebook.ads.sdk.serverside.EventResponse;
import com.facebook.ads.sdk.serverside.UserData;
import com.facebook.ads.sdk.serverside.CustomData;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class CONVERSIONS_API_EVENT_CREATE_ASYNC &#123;
public static final String ACCESS_TOKEN = System.getenv(&quot;ACCESS_TOKEN&quot;);
public static final String PIXEL_ID = System.getenv(&quot;PIXEL_ID&quot;);
private static EventRequest getEventRequest(APIContext context, int num) &#123;
UserData userData = new UserData()
.email(String.format(&quot;joe%s&#064;eg.com&quot;, num))
.clientIpAddress(clientIpAddress)
.clientUserAgent(clientUserAgent);
HashMap&lt;String,String&gt; customProperties = new HashMap&lt;&gt;();
customProperties.put(&quot;custom1&quot;, &quot;value2&quot;);
CustomData customData = new CustomData()
.currency(&quot;usd&quot;)
.customProperties(customProperties)
.value(123.45F);
Event pageViewEvent = new Event();
pageViewEvent.eventName(&quot;Purchase&quot;)
.eventTime(System.currentTimeMillis() / 1000L)
.userData(userData)
.customData(customData)
.eventSourceUrl(&quot;http://jaspers-market.com/product/123&quot;)
.actionSource(ActionSource.website);
EventRequest eventRequest = new EventRequest(PIXEL_ID, context);
eventRequest.addDataItem(pageViewEvent);
return eventRequest;
&#125;
private static void run() throws Exception &#123;
if (ACCESS_TOKEN == null || PIXEL_ID == null) &#123;
throw new Exception(String.format(&quot;Missing required test config. Got pixel_id: &#039;%s&#039;, access_token: &#039;%s&#039;&quot;, PIXEL_ID, ACCESS_TOKEN));
&#125;
APIContext context = new APIContext(ACCESS_TOKEN);
context.setLogger(System.out);
EventRequest asyncRequest = getEventRequest(context, 1);
final ListenableFuture&lt;EventResponse&gt; requestFuture = asyncRequest.executeAsync();
EventResponse asyncResponse = requestFuture.get();
System.out.println(String.format(&quot;Async Request - OK: %s&quot;, asyncResponse));
List&lt;ListenableFuture&lt;EventResponse&gt;&gt; eventFutures = new ArrayList&lt;&gt;();
eventFutures.add(getEventRequest(context, 2).executeAsync());
eventFutures.add(getEventRequest(context, 3).executeAsync());
eventFutures.add(getEventRequest(context, 4).executeAsync());
List&lt;EventResponse&gt; asyncResponses = Futures
.allAsList(eventFutures)
.get();
System.out.println(String.format(&quot;Multiple Async Requests - OK: %s&quot;, asyncResponses));
&#125;
public static void main (String args[]) throws Exception &#123;
try &#123;
run();
&#125; catch (Exception e) &#123;
e.printStackTrace();
throw(e);
&#125;
System.exit(0);
&#125;
&#125;
```
### Ruby Business SDK
```ruby
require &#039;concurrent&#039;
require &#039;facebook_ads&#039;
require &#039;pp&#039;
ACCESS_TOKEN = ENV[&#039;ACCESS_TOKEN&#039;]
PIXEL_ID = ENV[&#039;PIXEL_ID&#039;]
unless ACCESS_TOKEN &amp;&amp; PIXEL_ID
raise Exception.new(&quot;Missing required test config. Got pixel_id: &#039;#&#123;PIXEL_ID&#125;&#039;, access_token: &#039;#&#123;ACCESS_TOKEN&#125;&#039;&quot;)
end
FacebookAds.configure do |config|
config.access_token = ACCESS_TOKEN
end
def get_events(num)
user_data = FacebookAds::ServerSide::UserData.new(
email: &#039;joe#&#123;num&#125;&#064;eg.com&#039;,
client_ip_address: request.remote_ip,
client_user_agent: request.user_agent
)
custom_data = FacebookAds::ServerSide::CustomData.new(
currency: &#039;usd&#039;,
value: 123.45
)
event = FacebookAds::ServerSide::Event.new(
event_name: &#039;Purchase&#039;,
event_time: Time.now.to_i,
user_data: user_data,
custom_data: custom_data,
event_source_url: &#039;http://jaspers-market.com/product/123&#039;,
action_source: &#039;website&#039;
)
[event]
end
def get_event_request_async(num)
FacebookAds::ServerSide::EventRequestAsync.new(
pixel_id: PIXEL_ID,
events: get_events(num)
)
end
def main
request = get_event_request_async(1)
response = request.execute.value!
print &quot;Response: #&#123;response&#125;\n&quot;
print &quot;EventRequest async single - OK.\n&quot;
promises = (2..3).map &#123;|num| get_event_request_async(num).execute &#125;
responses = Concurrent::Promise.zip(*promises)
.execute
.value!
print &quot;Responses:\n&quot;
pp responses
print &quot;EventRequest async multi - OK.\n&quot;
end
main
```
## Concurrent batching &#123;#concurrent-batching&#125;
Concurrent batching uses asynchronous requests to increase throughput by utilizing resources more efficiently. You can create batched requests to support use cases like event request workers, [cron jobs](https://en.wikipedia.org/wiki/Cron), and more.
You have the following `BatchProcessor` methods to choose from:
| Method | When To Use It |
| --- | --- |
| `processEvents` | Use it to process events that have the same top-level `EventRequest` fields, like `namespace_id` and `upload_tag`. |
| `processEventsGenerator` | This is the underlying generator for `processEvents`.&lt;br&gt;&lt;br&gt;It can also be used to process events that have the same top-level `EventRequest` fields, like `namespace_id` and `upload_tag`. |
| `processEventRequests` | Use it to process `EventRequests` concurrently when you want to specify different `EventRequest` fields per request. |
| `processEventRequestsGenerator` | This is the underlying generator for `processEventRequests`.&lt;br&gt;&lt;br&gt;It can also be used to process `EventRequests` concurrently when you want to specify different `EventRequest` fields per request. |
When using concurrent batching, events should be sent as close to real-time as possible. For more information, see [Sharing Frequency](https://developers.facebook.com/documentation/ads-commerce/conversions-api/guides/end-to-end-implementation#sharing-frequency).
If you are using the PHP, Python, or Ruby SDKs, the methods above require an EventRequestAsync object(s) instead of an EventRequest.
To implement concurrent batching, see code samples in the following languages:
### PHP Business SDK
```php
use FacebookAds\Api;
use FacebookAds\Object\ServerSide\BatchProcessor;
use FacebookAds\Object\ServerSide\CustomData;
use FacebookAds\Object\ServerSide\Event;
use FacebookAds\Object\ServerSide\EventRequestAsync;
use FacebookAds\Object\ServerSide\UserData;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Promise;
$pixel_id = getenv(&#039;PIXEL_ID&#039;);
$access_token = getenv(&#039;ACCESS_TOKEN&#039;);
if (empty($pixel_id) || empty($access_token)) &#123;
throw new Exception(&#039;Missing required test config. Got pixel_id: &quot;&#039; . $pixel_id . &#039;&quot;, access_token: &quot;&#039; . $access_token . &#039;&quot;&#039;);
&#125;
$api = Api::init(null, null, $access_token, false);
function create_event($i) &#123;
$user_data = (new UserData())
-&gt;setEmail(&#039;joe&#039; . $i . &#039;&#064;eg.com&#039;)
-&gt;setClientIpAddress($_SERVER[&#039;REMOTE_ADDR&#039;])
-&gt;setClientUserAgent($_SERVER[&#039;HTTP_USER_AGENT&#039;]);
$custom_data = (new CustomData())
-&gt;setCurrency(&#039;usd&#039;)
-&gt;setValue(123.45);
return (new Event())
-&gt;setEventName(&#039;Purchase&#039;)
-&gt;setEventTime(time())
-&gt;setEventSourceUrl(&#039;http://jaspers-market.com/product/&#039; . $i)
-&gt;setUserData($user_data)
-&gt;setCustomData($custom_data)
-&gt;setActionSource(ActionSource::WEBSITE);
&#125;
function create_events($num) &#123;
$events = [];
for ($i = 0; $i &lt; $num; $i++) &#123;
$events[] = create_event($i);
&#125;
return $events;
&#125;
function create_async_requests($pixel_id, $num) &#123;
$requests = [];
for ($i = 0; $i &lt; $num; $i++) &#123;
$requests[] = (new EventRequestAsync($pixel_id))
-&gt;setUploadTag(&#039;test-tag-2&#039;)
-&gt;setEvents([create_event($i)]);
&#125;
return $requests;
&#125;
function run($pixel_id) &#123;
print(&quot;Started CONVERSIONS_API_EVENT_CREATE_BATCH...\n&quot;);
$batch_processor = new BatchProcessor($pixel_id, 2, 2);
// processEvents
$events = create_events(11);
$batch_processor-&gt;processEvents(array(&#039;upload_tag&#039; =&gt; &#039;test-tag-1&#039;), $events);
// processEventRequests
$requests = create_async_requests($pixel_id, 5);
$batch_processor-&gt;processEventRequests($requests);
// processEventsGenerator
$process_events_generator = $batch_processor-&gt;processEventsGenerator(array(&#039;upload_tag&#039; =&gt; &#039;test-tag-1&#039;), $events);
foreach ($process_events_generator as $promises) &#123;
try &#123;
Promise\unwrap($promises);
&#125; catch (RequestException $e) &#123;
print(&#039;RequestException: &#039; . $e-&gt;getResponse()-&gt;getBody()-&gt;getContents() . &quot;\n&quot;);
throw $e;
&#125; catch (\Exception $e) &#123;
print(&quot;Exception:\n&quot;);
print_r($e);
throw $e;
&#125;
&#125;
// processEventRequestsGenerator
$requests = create_async_requests($pixel_id, 5);
$process_event_requests_generator = $batch_processor-&gt;processEventRequestsGenerator($requests);
foreach ($process_event_requests_generator as $promises) &#123;
try &#123;
Promise\unwrap($promises);
&#125; catch (RequestException $e) &#123;
print(&#039;RequestException: &#039; . $e-&gt;getResponse()-&gt;getBody()-&gt;getContents() . &quot;\n&quot;);
throw $e;
&#125; catch (\Exception $e) &#123;
print(&quot;Exception:\n&quot;);
print_r($e);
throw $e;
&#125;
&#125;
print(&quot;Finished CONVERSIONS_API_EVENT_CREATE_BATCH with no errors.\n&quot;);
&#125;
run($pixel_id);
```
### Python Business SDK
```python
import asyncio
import time
import os
import sys
repo_dir = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)
sys.path.insert(1, repo_dir)
from facebook_business.adobjects.serverside.batch_processor import BatchProcessor
from facebook_business.adobjects.serverside.custom_data import CustomData
from facebook_business.adobjects.serverside.event import Event
from facebook_business.adobjects.serverside.event_request_async import EventRequestAsync
from facebook_business.adobjects.serverside.user_data import UserData
from facebook_business.api import FacebookAdsApi
def get_event(num):
user_data = UserData(
email=&quot;joe%s&#064;eg.com&quot; % num,
client_ip_address=request.META.get(&#039;REMOTE_ADDR&#039;),
client_user_agent=request.headers[&#039;User-Agent&#039;]
)
custom_data = CustomData(currency=&quot;usd&quot;, value=123.45, item_number=&quot;itemnumber-123&quot;)
event = Event(
event_name=&quot;Purchase&quot;,
event_time=int(time.time()),
user_data=user_data,
custom_data=custom_data,
data_processing_options=[],
event_source_url=&#039;http://jaspers-market.com/product/123&#039;,
action_source=ActionSource.WEBSITE
)
return event
def get_events(num):
events = []
for i in range(num):
events.append(get_event(num))
return events
def get_event_requests_async(num):
event_requests_async = []
for i in range(num):
event_requests_async.append(
EventRequestAsync(
events=[get_event(i)],
pixel_id=pixel_id
)
)
return event_requests_async
def run_process_event_requests():
batch_processor = BatchProcessor(2, 2)
event_requests_async = get_event_requests_async(3)
batch_processor.process_event_requests(event_requests_async)
async def run_process_event_requests_generator():
batch_processor = BatchProcessor(3, 2)
event_requests_async = get_event_requests_async(7)
generator = batch_processor.process_event_requests_generator(event_requests_async)
async for batch_responses in generator:
print(batch_responses)
def run_process_events():
batch_processor = BatchProcessor(2, 2)
event_request_async_to_clone = EventRequestAsync(pixel_id=pixel_id, events=[])
events = get_events(3)
batch_processor.process_events(event_request_async_to_clone, events)
async def run_process_events_generator():
batch_processor = BatchProcessor(3, 2)
event_request_async_to_clone = EventRequestAsync(pixel_id=pixel_id, events=[])
events = get_events(10)
generator = batch_processor.process_events_generator(event_request_async_to_clone, events)
async for batch_responses in generator:
print(batch_responses)
if __name__ == &#039;__main__&#039;:
pixel_id = os.getenv(&quot;PIXEL_ID&quot;)
access_token = os.getenv(&quot;ACCESS_TOKEN&quot;)
if not (pixel_id and access_token):
raise Exception(&quot;Missing required test config. Got pixel_id: &#039;&#123;pixel_id&#125;&#039;, access_token: &#039;&#123;access_token&#125;&#039;&quot;.format(
pixel_id=pixel_id,
access_token=access_token
))
FacebookAdsApi.init(access_token=access_token, crash_log=False)
run_process_event_requests()
print(&quot;BatchProcessor process_event_requests - OK.&quot;)
asyncio.run(run_process_event_requests_generator())
print(&quot;BatchProcessor process_event_requests_generator - OK.&quot;)
run_process_events()
print(&quot;BatchProcessor process_events - OK.&quot;)
asyncio.run(run_process_events_generator())
print(&quot;BatchProcessor process_events_generator - OK.&quot;)
```
### Node.js Business SDK
```js
const bizSdk = require(&#039;facebook-nodejs-business-sdk&#039;);
const process = require(&#039;process&#039;);
const ServerEvent = bizSdk.ServerEvent;
const EventRequest = bizSdk.EventRequest;
const UserData = bizSdk.UserData;
const CustomData = bizSdk.CustomData;
const Content = bizSdk.Content;
const BatchProcessor = bizSdk.BatchProcessor;
const access_token = process.env.ACCESS_TOKEN;
const pixel_id = process.env.PIXEL_ID;
function createEvents(num) &#123;
let events = [];
for (let i = 0; i &lt; num; i++) &#123;
let current_timestamp = Math.floor(new Date() / 1000);
const user_data = (new UserData())
.setEmail(`joe$&#123;i&#125;&#064;eg.com`)
.setClientIpAddress(request.connection.remoteAddress)
.setClientUserAgent(request.headers[&#039;user-agent&#039;]);
const custom_data = (new CustomData())
.setCurrency(&#039;usd&#039;)
.setCustomProperties(&#123;custom1: &#039;value2&#039;&#125;)
.setValue(123.45);
const server_event = (new ServerEvent())
.setEventName(&#039;Purchase&#039;)
.setEventTime(current_timestamp)
.setUserData(user_data)
.setCustomData(custom_data)
.setEventSourceUrl(&#039;http://jaspers-market.com/product/123&#039;)
.setActionSource(&#039;website&#039;);
events.push(server_event);
&#125;
return events;
&#125;
function createEventRequests(num, access_token, pixel_id) &#123;
let event_requests = [];
for (let i = 0; i &lt; num; i++) &#123;
const events = createEvents(2);
const event_request = (new EventRequest(access_token, pixel_id))
.setEvents(events);
event_requests.push(event_request);
&#125;
return event_requests;
&#125;
void async function() &#123;
try &#123;
if (access_token === undefined || pixel_id === undefined) &#123;
throw new Error(`&quot;Missing required test config. Got pixel_id: &#039;$&#123;pixel_id&#125;&#039;, access_token: &#039;$&#123;access_token&#125;&#039;&quot;`)
&#125;
const api = bizSdk.FacebookAdsApi.init(access_token);
const batch_processor = new BatchProcessor(2, 2);
// processEvents
const events1 = createEvents(5);
const event_request = (new EventRequest(access_token, pixel_id));
batch_processor.processEvents(event_request, events1);
console.log(&#039;BatchProcessor.processEvents - OK.&#039;);
// processEventRequests
const event_requests1 = createEventRequests(3, access_token, pixel_id);
batch_processor.processEventRequests(event_requests1);
console.log(&#039;BatchProcessor.processEventRequests - OK.&#039;);
// processEventsGenerator
const events2 = createEvents(5);
const eventsGenerator = batch_processor.processEventsGenerator(event_request, events2);
while (true) &#123;
const batch = eventsGenerator.next().value;
if (!batch || batch.length === 0) &#123;
eventsGenerator.return();
break;
&#125;
await Promise.all(batch).then(response =&gt; &#123;
console.log(&#039;processEventsGenerator Events Received: &#039;, response.map(r =&gt; r.events_received))
&#125;).catch(response =&gt; &#123;
console.log(&#039;processEventsGenerator Error: &#039;, response);
&#125;);
&#125;
// processEventRequestsGenerator
const event_requests2 = createEventRequests(3, access_token, pixel_id);
const eventRequestsGenerator = batch_processor.processEventRequestsGenerator(event_requests2);
while (true) &#123;
const batch = eventRequestsGenerator.next().value;
if (!batch || batch.length === 0) &#123;
eventRequestsGenerator.return();
break;
&#125;
await Promise.all(batch).then(response =&gt; &#123;
console.log(&#039;processEventRequestsGenerator Events Received: &#039;, response.map(r =&gt; r.events_received))
&#125;).catch(response =&gt; &#123;
console.log(&#039;processEventRequestsGenerator Error: &#039;, response);
&#125;);
&#125;
&#125; catch(error) &#123;
console.log(error);
process.exit(1);
&#125;
&#125;();
```
### Java Business SDK
```java
import com.facebook.ads.sdk.APIContext;
import com.facebook.ads.sdk.serverside.*;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
class CONVERSIONS_API_EVENT_CREATE_BATCH &#123;
public static final String ACCESS_TOKEN = System.getenv(&quot;ACCESS_TOKEN&quot;);
public static final String PIXEL_ID = System.getenv(&quot;PIXEL_ID&quot;);
public static void run() throws Exception &#123;
if (ACCESS_TOKEN == null || PIXEL_ID == null) &#123;
throw new Exception(String.format(&quot;Missing required test config. Got pixel_id: &#039;%s&#039;, access_token: &#039;%s&#039;&quot;, PIXEL_ID, ACCESS_TOKEN));
&#125;
APIContext context = new APIContext(ACCESS_TOKEN);
context.setLogger(System.out);
BatchProcessor batchProcessor = new BatchProcessor(2, 3);
List&lt;EventRequest&gt; eventRequests1 = getEventRequests(context, 4);
batchProcessor.processEventRequests(eventRequests1);
System.out.println(&quot;processEventRequests - OK.\n&quot;);
List&lt;EventRequest&gt; eventRequests2 = getEventRequests(context, 2);
Iterator&lt;List&lt;ListenableFuture&lt;EventResponse&gt;&gt;&gt; eventRequestsIterator = batchProcessor.processEventRequestsIterator(eventRequests2);
while (eventRequestsIterator.hasNext()) &#123;
List&lt;ListenableFuture&lt;EventResponse&gt;&gt; futures = eventRequestsIterator.next();
List&lt;EventResponse&gt; eventResponses = Futures
.allAsList(futures)
.get();
System.out.println(eventResponses);
&#125;
System.out.println(&quot;processEventRequestsIterator - OK.\n&quot;);
EventRequest eventRequest1 = new EventRequest(PIXEL_ID, context);
List&lt;Event&gt; events1 = getEvents(5);
batchProcessor.processEvents(eventRequest1, events1);
System.out.println(&quot;processEvents - OK.\n&quot;);
EventRequest eventRequest2 = new EventRequest(PIXEL_ID, context);
List&lt;Event&gt; events2 = getEvents(5);
Iterator&lt;List&lt;ListenableFuture&lt;EventResponse&gt;&gt;&gt; eventsIterator = batchProcessor.processEventsIterator(eventRequest2, events2);
while (eventsIterator.hasNext()) &#123;
List&lt;ListenableFuture&lt;EventResponse&gt;&gt; futures = eventsIterator.next();
List&lt;EventResponse&gt; eventResponses = Futures
.allAsList(futures)
.get();
System.out.println(eventResponses);
&#125;
System.out.println(&quot;processEventsIterator - OK.\n&quot;);
&#125;
private static List&lt;EventRequest&gt; getEventRequests(APIContext context, int num) &#123;
List&lt;EventRequest&gt; requests = new ArrayList&lt;&gt;();
for (int i = 0; i &lt; num; i++) &#123;
Event pageViewEvent = getEvent(i);
EventRequest request = new EventRequest(PIXEL_ID, context);
request.addDataItem(pageViewEvent);
requests.add(request);
&#125;
return requests;
&#125;
private static Event getEvent(int num) &#123;
UserData userData = new UserData()
.email(String.format(&quot;joe%s&#064;eg.com&quot;, num))
.clientIpAddress(clientIpAddress)
.clientUserAgent(clientUserAgent);
HashMap&lt;String, String&gt; customProperties = new HashMap&lt;&gt;();
customProperties.put(&quot;item_number&quot;, &quot;456&quot;);
CustomData customData = new CustomData()
.currency(&quot;usd&quot;)
.customProperties(customProperties)
.value(123.45F);
Event pageViewEvent = new Event();
pageViewEvent.eventName(&quot;Purchase&quot;)
.eventTime(System.currentTimeMillis() / 1000L)
.userData(userData)
.customData(customData)
.eventSourceUrl(&quot;http://jaspers-market.com/product/123&quot;)
.actionSource(ActionSource.website);
return pageViewEvent;
&#125;
private static List&lt;Event&gt; getEvents(int num) &#123;
List&lt;Event&gt; events = new ArrayList&lt;&gt;();
for (int i = 0; i &lt; num; i++) &#123;
events.add(getEvent(i));
&#125;
return events;
&#125;
public static void main(String[] args) &#123;
try &#123;
run();
&#125; catch (Exception e) &#123;
e.printStackTrace();
System.out.println(e.toString());
System.exit(1);
&#125;
System.exit(0);
&#125;
&#125;
```
### Ruby Business SDK
```ruby
require &#039;concurrent&#039;
require &#039;facebook_ads&#039;
def get_event(num)
user_data = FacebookAds::ServerSide::UserData.new(
email: &#039;joe#&#123;num&#125;&#064;eg.com&#039;,
client_ip_address: request.remote_ip,
client_user_agent: request.user_agent
)
custom_data = FacebookAds::ServerSide::CustomData.new(
currency: &#039;usd&#039;,
value: 123.45
)
FacebookAds::ServerSide::Event.new(
event_name: &#039;Purchase&#039;,
event_time: Time.now.to_i,
user_data: user_data,
custom_data: custom_data,
event_source_url: &#039;http://jaspers-market.com/product/123&#039;,
action_source: &#039;website&#039;
)
end
def get_events(num)
num.times.map do |i|
get_event(i)
end
end
def get_event_request_async(pixel_id, num)
FacebookAds::ServerSide::EventRequestAsync.new(
pixel_id: pixel_id,
events: [get_event(num)]
)
end
def get_event_requests_async(pixel_id, num)
num.times.map do |i|
get_event_request_async(pixel_id, i)
end
end
def run_process_event_requests(pixel_id)
batch_processor = FacebookAds::ServerSide::BatchProcessor.new(2, 2)
event_requests_async = get_event_requests_async(pixel_id, 3)
batch_processor.process_event_requests(event_requests_async)
end
def run_process_event_requests_generator(pixel_id)
batch_processor = FacebookAds::ServerSide::BatchProcessor.new(3, 2)
event_requests_async = get_event_requests_async(pixel_id, 7)
generator = batch_processor.process_event_requests_generator(event_requests_async)
generator.each do |batch|
responses = Concurrent::Promise.zip(*batch).execute.value!
print &quot;#&#123;responses&#125;\n&quot;
end
end
def run_process_events(pixel_id)
batch_processor = FacebookAds::ServerSide::BatchProcessor.new(2, 2)
event_request_async_to_clone = FacebookAds::ServerSide::EventRequestAsync.new(pixel_id: pixel_id)
events = get_events(3)
batch_processor.process_events(event_request_async_to_clone, events)
end
def run_process_events_generator(pixel_id)
batch_processor = FacebookAds::ServerSide::BatchProcessor.new(3, 2)
event_request_async_to_clone = FacebookAds::ServerSide::EventRequestAsync.new(pixel_id: pixel_id)
events = get_events(10)
generator = batch_processor.process_events_generator(event_request_async_to_clone, events)
generator.each do |batch|
responses = Concurrent::Promise.zip(*batch).execute.value!
print &quot;#&#123;responses&#125;\n&quot;
end
end
def main
access_token = ENV[&#039;ACCESS_TOKEN&#039;]
pixel_id = ENV[&#039;PIXEL_ID&#039;]
unless access_token &amp;&amp; pixel_id
raise Exception.new(&quot;Missing required test config. Got pixel_id: &#039;#&#123;pixel_id&#125;&#039;, access_token: &#039;#&#123;access_token&#125;&#039;&quot;)
end
FacebookAds.configure do |config|
config.access_token = access_token
end
run_process_event_requests(pixel_id)
print &quot;BatchProcessor process_event_requests - OK.\n&quot;
run_process_event_requests_generator(pixel_id)
print &quot;BatchProcessor process_event_requests_generator - OK.\n&quot;
run_process_events(pixel_id)
print &quot;BatchProcessor process_events - OK.\n&quot;
run_process_events_generator(pixel_id)
print &quot;BatchProcessor process_events_generator - OK.\n&quot;
end
main
```
## HTTP service interface &#123;#http-service-interface&#125;
Use HTTP Service Interface if you have a specific set of requirements for the HTTP service layer. With this feature, you can override the Business SDK&#039;s default HTTP service and implement your own custom service with your preferred method or library.
To implement your own HTTP Service Interface, see code samples in the following languages:
### PHP Business SDK
```php
require __DIR__ . &#039;/../vendor/autoload.php&#039;;
use FacebookAds\Api;
use FacebookAds\Object\ServerSide\CustomData;
use FacebookAds\Object\ServerSide\Event;
use FacebookAds\Object\ServerSide\EventRequest;
use FacebookAds\Object\ServerSide\EventRequestAsync;
use FacebookAds\Object\ServerSide\HttpServiceClientConfig;
use FacebookAds\Object\ServerSide\UserData;
// Imports used by the TestHttpClient class
use FacebookAds\Object\ServerSide\HttpServiceInterface;
use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Handler\CurlHandler;
use GuzzleHttp\Psr7\MultipartStream;
use GuzzleHttp\Psr7\Request;
$pixel_id = getenv(&#039;PIXEL_ID&#039;);
$access_token = getenv(&#039;ACCESS_TOKEN&#039;);
if (empty($pixel_id) || empty($access_token)) &#123;
throw new Exception(&#039;Missing required test config. Got pixel_id: &quot;&#039; . $pixel_id . &#039;&quot;, access_token: &quot;&#039; . $access_token . &#039;&quot;&#039;);
&#125;
function run($access_token, $pixel_id) &#123;
Api::init(null, null, $access_token, false);
$request1 = getEventRequest($pixel_id, 1);
$request1-&gt;setHttpClient(new TestHttpClient());
$response1 = $request1-&gt;execute();
print(&quot;Response: &quot; . $response1-&gt;getBody() . &quot;\n&quot;);
print(&quot;Custom HTTP Service Request 1 - OK.\n&quot;);
// Alternatively, you can set the access_token and the HTTP Client on the HttpServiceClientConfig
Api::init(null, null, null, false);
HttpServiceClientConfig::getInstance()-&gt;setClient(new TestHttpClient());
HttpServiceClientConfig::getInstance()-&gt;setAccessToken($access_token);
$request2 = getEventRequest($pixel_id, 2);
$response2 = $request2-&gt;execute();
print(&quot;Response: &quot; . $response2-&gt;getBody() . &quot;\n&quot;);
print(&quot;Custom HTTP Service Request 2 - OK.\n&quot;);
&#125;
function getEventRequest($pixel_id, $num) &#123;
$user_data = (new UserData())
-&gt;setEmail(&#039;joe&#039; . $num . &#039;&#064;eg.com&#039;)
-&gt;setClientIpAddress($_SERVER[&#039;REMOTE_ADDR&#039;])
-&gt;setClientUserAgent($_SERVER[&#039;HTTP_USER_AGENT&#039;]);
$custom_data = (new CustomData())
-&gt;setCurrency(&#039;usd&#039;)
-&gt;setValue(123.45);
$event = (new Event())
-&gt;setEventName(&#039;Purchase&#039;)
-&gt;setEventTime(time())
-&gt;setEventSourceUrl(&#039;http://jaspers-market.com/product/123&#039;)
-&gt;setUserData($user_data)
-&gt;setCustomData($custom_data)
-&gt;setActionSource(ActionSource::WEBSITE);
return (new EventRequest($pixel_id))
-&gt;setEvents(array($event));
&#125;
class TestHttpClient implements HttpServiceInterface &#123;
public function executeRequest($url, $method, array $curl_options, array $headers, array $params) &#123;
$multipart_contents = [];
foreach ($params as $key =&gt; $value) &#123;
if ($key === &#039;data&#039;) &#123;
$multipart_contents[] = [
&#039;name&#039; =&gt; $key,
&#039;contents&#039; =&gt; \GuzzleHttp\json_encode($value),
&#039;headers&#039; =&gt; array(&#039;Content-Type&#039; =&gt; &#039;multipart/form-data&#039;),
];
&#125; else &#123;
$multipart_contents[] = [
&#039;name&#039; =&gt; $key,
&#039;contents&#039; =&gt; $value,
&#039;headers&#039; =&gt; array(&#039;Content-Type&#039; =&gt; &#039;multipart/form-data&#039;),
];
&#125;
&#125;
$body = new MultipartStream($multipart_contents);
$request = new Request($method, $url, $headers, $body);
$handler_stack = HandlerStack::create(
new CurlHandler([&#039;options&#039; =&gt; $curl_options])
);
$client = new Client([&#039;handler&#039; =&gt; $handler_stack]);
return $client-&gt;send($request);
&#125;
&#125;
run($access_token, $pixel_id);
```
### Python Business SDK
```python
import time
import os
import sys
repo_dir = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)
sys.path.insert(1, repo_dir)
from facebook_business.adobjects.serverside.custom_data import CustomData
from facebook_business.adobjects.serverside.event import Event
from facebook_business.adobjects.serverside.event_request import EventRequest
from facebook_business.adobjects.serverside.http_service_interface import HttpServiceInterface
from facebook_business.adobjects.serverside.user_data import UserData
from facebook_business.api import FacebookAdsApi
def run(pixel_id, access_token):
user_data = UserData(
email=&quot;joe&#064;eg.com&quot;,
client_ip_address=request.META.get(&#039;REMOTE_ADDR&#039;),
client_user_agent=request.headers[&#039;User-Agent&#039;]
)
custom_data = CustomData(currency=&quot;usd&quot;, value=123.45, item_number=&quot;itemnumber-123&quot;)
event = Event(
event_name=&quot;Purchase&quot;,
event_time=int(time.time()),
user_data=user_data,
custom_data=custom_data,
data_processing_options=[],
event_source_url=&#039;http://jaspers-market.com/product/123&#039;,
action_source=ActionSource.WEBSITE
)
custom_http_client = CustomHttpClient()
event_request = EventRequest(
events=[event],
pixel_id=pixel_id,
http_client=custom_http_client,
access_token=access_token
)
event_response = event_request.execute()
print(event_response)
print(&quot;Custom HTTP Service Request - OK.&quot;)
class CustomHttpClient(HttpServiceInterface):
def execute(self, url, method, request_options, headers, params):
import requests
from facebook_business.adobjects.serverside.event_response import EventResponse
response = requests.request(method, url, json=params, headers=headers).json()
return EventResponse(
events_received=response[&#039;events_received&#039;],
fbtrace_id=response[&#039;fbtrace_id&#039;],
messages=response[&#039;messages&#039;]
)
if __name__ == &#039;__main__&#039;:
pixel_id = os.getenv(&quot;PIXEL_ID&quot;)
access_token = os.getenv(&quot;ACCESS_TOKEN&quot;)
if not (pixel_id and access_token):
raise Exception(&quot;Missing required test config. Got pixel_id: &#039;&#123;pixel_id&#125;&#039;, access_token: &#039;&#123;access_token&#125;&#039;&quot;.format(
pixel_id=pixel_id,
access_token=access_token
))
run(pixel_id, access_token)
```
### Node.js Business SDK
```js
const bizSdk = require(&#039;facebook-nodejs-business-sdk&#039;);
const https = require(&#039;https&#039;);
const process = require(&#039;process&#039;);
const ServerEvent = bizSdk.ServerEvent;
const EventRequest = bizSdk.EventRequest;
const EventResponse = bizSdk.EventResponse;
const UserData = bizSdk.UserData;
const CustomData = bizSdk.CustomData;
const Content = bizSdk.Content;
const access_token = process.env.ACCESS_TOKEN;
const pixel_id = process.env.PIXEL_ID;
// Implements the HttpServiceInterface
class E2EHttpService &#123;
executeRequest(url, method, headers, params) &#123;
return new Promise((resolve, reject) =&gt; &#123;
const options = &#123;
port: 443,
method,
headers,
&#125;
let body = &#039;&#039;;
const request = https.request(url, options, response =&gt; &#123;
response.on(&#039;data&#039;, chunk =&gt; &#123;
body += chunk.toString();
&#125;);
response.on(&#039;end&#039;, () =&gt; &#123;
return resolve(body);
&#125;);
&#125;).on(&#039;error&#039;, reject);
request.write(JSON.stringify(params));
request.end();
&#125;);
&#125;
&#125;
void async function() &#123;
try &#123;
if (access_token === undefined || pixel_id === undefined) &#123;
throw new Error(`&quot;Missing required test config. Got pixel_id: &#039;$&#123;pixel_id&#125;&#039;, access_token: &#039;$&#123;access_token&#125;&#039;&quot;`)
&#125;
const userData = (new UserData())
.setEmail(&#039;joe&#064;eg.com&#039;)
.setClientIpAddress(request.connection.remoteAddress)
.setClientUserAgent(request.headers[&#039;user-agent&#039;]);
const customData = (new CustomData())
.setCurrency(&#039;usd&#039;)
.setCustomProperties(&#123;custom1: &#039;value2&#039;&#125;)
.setValue(123.45);
const serverEvent = (new ServerEvent())
.setEventName(&#039;Purchase&#039;)
.setEventTime(Math.floor(new Date() / 1000))
.setUserData(userData)
.setCustomData(customData)
.setEventSourceUrl(&#039;http://jaspers-market.com/product/123&#039;)
.setActionSource(&#039;website&#039;);
const eventsData = [serverEvent];
const eventRequest = (new EventRequest(access_token, pixel_id))
.setHttpService(new E2EHttpService())
.setEvents(eventsData);
eventRequest.execute().then(response =&gt; &#123;
console.log(&#039;Custom HTTP Service Request OK. Response: &#039;, response);
&#125;, err =&gt; &#123;
console.log(&#039;Error: &#039;, err);
&#125;);
&#125; catch(error) &#123;
console.log(error);
process.exit(1);
&#125;
&#125;();
```
### Java Business SDK
```java
import com.facebook.ads.sdk.APIContext;
import com.facebook.ads.sdk.serverside.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
public class CONVERSIONS_API_EVENT_CREATE_CUSTOM_HTTP_SERVICE &#123;
public static final String ACCESS_TOKEN = System.getenv(&quot;ACCESS_TOKEN&quot;);
public static final String PIXEL_ID = System.getenv(&quot;PIXEL_ID&quot;);
public static void run() throws Exception &#123;
if (ACCESS_TOKEN == null || PIXEL_ID == null) &#123;
throw new Exception(String.format(&quot;Missing required test config. Got pixel_id: &#039;%s&#039;, access_token: &#039;%s&#039;&quot;, PIXEL_ID, ACCESS_TOKEN));
&#125;
APIContext context = new APIContext(ACCESS_TOKEN).enableDebug(true);
context.setLogger(System.out);
UserData userData = new UserData()
.email(&quot;joe&#064;eg.com&quot;)
.clientIpAddress(clientIpAddress)
.clientUserAgent(clientUserAgent);
HashMap&lt;String, String&gt; customProperties = new HashMap&lt;&gt;();
customProperties.put(&quot;item_number&quot;, &quot;456&quot;);
CustomData customData = new CustomData()
.currency(&quot;usd&quot;)
.customProperties(customProperties)
.value(123.45F);
Event pageViewEvent = new Event();
pageViewEvent.eventName(&quot;Purchase&quot;)
.eventTime(System.currentTimeMillis() / 1000L)
.userData(userData)
.customData(customData)
.eventSourceUrl(&quot;http://jaspers-market.com/product/123&quot;)
.actionSource(ActionSource.website);
EventRequest eventRequest = new EventRequest(PIXEL_ID, context);
eventRequest.addDataItem(pageViewEvent);
// Set the Custom HTTP Service Client
HttpServiceInterface httpServiceClient = new E2EHttpServiceClient();
eventRequest.setHttpServiceClient(httpServiceClient);
EventResponse eventResponse = eventRequest.execute();
System.out.println(&quot;Request was successful:&quot;);
System.out.println(eventResponse);
&#125;
public static void main(String[] args) &#123;
try &#123;
run();
&#125; catch (Exception e) &#123;
e.printStackTrace();
System.out.println(e.toString());
System.exit(1);
&#125;
System.exit(0);
&#125;
private static class E2EHttpServiceClient implements HttpServiceInterface &#123;
&#064;Override
public EventResponse executeRequest(String url, HttpMethodEnum httpMethod, Map&lt;String, String&gt; headers, HttpServiceParams params) &#123;
EventResponse eventResponse = null;
try &#123;
Gson gson = new GsonBuilder()
.disableHtmlEscaping()
.create();
URL requestUrl = new URL(url);
HttpURLConnection connection = (HttpURLConnection) requestUrl.openConnection();
connection.setRequestMethod(httpMethod.toString());
connection.setDoOutput(true);
connection.setRequestProperty(&quot;Content-Type&quot;, &quot;application/json&quot;);
DataOutputStream out = new DataOutputStream(connection.getOutputStream());
out.writeBytes(gson.toJson(params));
out.flush();
out.close();
BufferedReader in = new BufferedReader(
new InputStreamReader(connection.getInputStream())
);
String responseLine = in.readLine();
StringBuffer response = new StringBuffer();
while (responseLine != null) &#123;
response.append(responseLine);
responseLine = in.readLine();
&#125;
in.close();
String responseString = response.toString();
eventResponse = gson.fromJson(responseString, EventResponse.class);
&#125; catch (Exception e) &#123;
e.printStackTrace();
System.exit(1);
&#125;
return eventResponse;
&#125;
&#125;
&#125;
```
### Ruby Business SDK
```ruby
require &#039;facebook_ads&#039;
class CustomHttpClient &lt; FacebookAds::ServerSide::HttpServiceInterface
def execute(url, request_method, headers, params)
require &#039;faraday&#039;
require &#039;json&#039;
raise Exception.new(&quot;Incorrect HTTP method: #&#123;request_method&#125;&quot;) if request_method != FacebookAds::ServerSide::HttpMethod::POST
response = Faraday.post(url) do |request|
headers.each do |key, value|
request[key] = value
end
request.headers[&#039;Content-Type&#039;] = &#039;application/json&#039;
request.body = params.to_json
end
parsed_response = JSON.load(response.body)
return FacebookAds::ServerSide::EventResponse.new(
events_received: parsed_response[&#039;events_received&#039;],
messages: parsed_response[&#039;messages&#039;],
fbtrace_id: parsed_response[&#039;fbtrace_id&#039;]
)
end
end
def main
access_token = ENV[&#039;ACCESS_TOKEN&#039;]
pixel_id = ENV[&#039;PIXEL_ID&#039;]
unless access_token &amp;&amp; pixel_id
raise Exception.new(&quot;Missing required test config. Got pixel_id: &#039;#&#123;pixel_id&#125;&#039;, access_token: &#039;#&#123;access_token&#125;&#039;&quot;)
end
FacebookAds.configure do |config|
config.access_token = access_token
end
user_data = FacebookAds::ServerSide::UserData.new(
email: &#039;joe&#064;eg.com&#039;,
client_ip_address: request.remote_ip,
client_user_agent: request.user_agent
)
custom_data = FacebookAds::ServerSide::CustomData.new(
currency: &#039;usd&#039;,
value: 123.45
)
event = FacebookAds::ServerSide::Event.new(
event_name: &#039;Purchase&#039;,
event_time: Time.now.to_i,
user_data: user_data,
custom_data: custom_data,
event_source_url: &#039;http://jaspers-market.com/product/123&#039;,
action_source: &#039;website&#039;
)
request = FacebookAds::ServerSide::EventRequest.new(
pixel_id: pixel_id,
events: [event],
http_service_client: CustomHttpClient.new
)
response = request.execute
print &quot;Response: #&#123;response&#125;\n&quot;
print &quot;Custom HTTP Service Request - OK.&quot;
end
main
```
## Test your event requests
You can test your event requests using the `test_event_code` parameter. Locate the test code by going to the Test Events tool found in the **Events Manager** under **Data Sources** &gt; **Your Pixel** &gt; **Test Events** tab.
**Note:** You must replace the sample value in the code below (i.e., `TEST12345`) with the test code you obtain from the **Test Events** tab.
### PHP Business SDK
```php
...
$request = (new EventRequest($pixel_id))
-&gt;setTestEventCode(&#039;TEST12345&#039;)
-&gt;setEvents($events);
$response = $request-&gt;execute();
```
### Python Business SDK
```python
...
event_request = EventRequest(
events=[event],
test_event_code=&#039;TEST12345&#039;,
pixel_id=pixel_id
)
result = event_request.execute()
```
### Node.js Business SDK
```js
...
const eventRequest = (new EventRequest(access_token, pixel_id))
.setTestEventCode(&#039;TEST12345&#039;)
.setEvents(eventsData);
eventRequest.execute().then(response =&gt; &#123;
console.log(&#039;Execute Request OK. Response: &#039;, response);
&#125;, err =&gt; &#123;
console.log(&#039;Error: &#039;, err);
&#125;);
```
### Java Business SDK
```java
...
EventRequest eventRequest = new EventRequest(PIXEL_ID, context);
eventRequest.addDataItem(purchaseEvent);
eventRequest.setTestEventCode(&quot;TEST12345&quot;);
EventResponse response = eventRequest.execute();
```
### Ruby Business SDK
```ruby
...
request = FacebookAds::ServerSide::EventRequest.new(
pixel_id: PIXEL_ID,
test_event_code: &#039;TEST12345&#039;,
events: [event]
)
response = request.execute
```
## Limitations
Currently, we do not support setting a custom HTTP Service Interface when making concurrent batch requests or asynchronous requests.
