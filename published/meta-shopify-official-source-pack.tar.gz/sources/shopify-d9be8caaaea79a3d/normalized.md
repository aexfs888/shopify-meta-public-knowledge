- Shopify Help Center | Meta pixel
Help
Log in
Contents
# Meta pixel
When you set up Facebook and Instagram by Meta, you can add a pixel to track customer data and behavior on your Online Store. To use a Meta pixel, you need to set a customer data-sharing level . It's up to you to decide how much data you want to track using the pixel. The Standard data sharing setting sends only customer behavior. The Enhanced and Maximum settings send additional customer information including name, location, and email address.
You can create a Meta pixel using Facebook Ads Manager, or in Facebook and Instagram by Meta.
If you've added a Meta pixel to your online store theme code before, then remove the Meta pixel code from your online store after you set up your pixel using Facebook and Instagram by Meta.
Meta pixels can help improve your stores marketing capabilities and the performance of Facebook ads. To create Facebook ads you need to connect a Facebook ad account .
## On this page
Creating a Meta pixel
- Add a Meta pixel to your online store
- Change or remove a Meta pixel from your online store
- Customer data-sharing events
## Creating a Meta pixel
You can create a new Meta pixel directly in Facebook and Instagram by Meta by clicking Create new in the pixel set-up box, or you can create a Meta pixel in Facebook Ads Manager . To create a pixel in Facebook Ads Manager, refer to the Facebook Help Center .
## Add a Meta pixel to your online store
When you add a Meta pixel to Facebook and Instagram by Meta, the pixel integrates with your online store. A Meta pixel can be added when you're setting up Instagram Shopping or Facebook Shop. Before you can add a Meta pixel, you need to activate data sharing in the Customer data-sharing section.
You can manage your Meta pixel in the Share data settings within the Settings section of Facebook and Instagram by Meta.
In the Customer data-sharing section of your Share data settings in Facebook and Instagram by Meta, there's a list of pixels that you have created. Click Connect to connect a preexisting Meta pixel or click Create new to create a new Meta pixel.
After you add a Meta pixel to your online store, make sure that it's working by using Facebook Ads Manager. Learn about how to tell if your Meta pixel is working from the Facebook Help Center .
#### Steps:
-
From your Shopify admin, go to Sales channels > Facebook & Instagram .
-
Click Settings , and then click Share data settings .
-
In the Customer data-sharing section, click the Enable data-sharing toggle.
-
In the Choose data-sharing level section select Standard , Enhanced , or Maximum .
-
Select your pixel from the list.
-
Click Confirm .
## Change or remove a Meta pixel from your online store
#### Steps:
-
From your Shopify admin, go to Sales channels > Facebook & Instagram .
-
Click Settings .
-
In the Share data settings section, click Change to remove your current pixel.
-
Connect another pixel, or create a new one.
If you edited your theme file code to add a Meta pixel, then you need to remove the pixel code before you can add a Meta pixel ID using Facebook and Instagram by Meta. If you don't remove the pixel code, then your store will have more than one pixel on it, which can result in duplicate or incorrect data in your reports.
### Remove pixel code from your theme file
Desktop
-
From your Shopify admin, go to Online Store .
-
In the Current theme section, click , and then click Edit code .
-
Click the theme.liquid file to open the code editor.
-
Delete the Meta pixel code. You can find it between the <head> and </head> tags.
-
Click Save .
Mobile
-
From the Shopify app , tap the icon.
-
In the Sales channels section, tap Online Store .
-
Tap Manage all themes .
-
In the Current theme section, tap , and then tap Edit code .
-
Tap the theme.liquid file to open the code editor.
-
Delete the Meta pixel code. You can find it between the <head> and </head> tags.
-
Tap Save .
### Remove your Meta pixel in your Online Store Preferences
-
From your Shopify admin, go to Online Store .
-
Click Preferences .
-
In the Meta pixel section, click Change .
-
Delete the Meta pixel, and then click Save .
## Customer data-sharing events
After you add a Meta pixel in Shopify, the pixel tracks certain events on your online store, such as when a customer views a certain page. For more information on customer data-sharing events, refer to Facebook data sharing .
Leave feedback
