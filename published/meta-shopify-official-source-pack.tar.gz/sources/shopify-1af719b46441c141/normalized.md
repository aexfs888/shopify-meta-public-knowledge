- Apps in checkout Skip to main content
Merchants use Shopify checkout to accept orders and receive payments wherever they sell online. To augment Shopify checkout with new functionality, build an app with extensions.
##
Anchor to How it works How it works
After a customer adds products to a cart, they use Shopify checkout to enter their customer, shipping, and payment information before placing the order.
To extend checkout, apps can use extensions. For example, apps can use extensions to offer a customer free shipping or other discounts, depending on the contents of their cart.
To install apps on their store, merchants can use the Shopify admin. There, they can can use the checkout editor to place a block for a checkout UI extension in the checkout experience.
##
Anchor to Customization options Customization options
There are various types of Shopify Extensions that you can use to customize checkout:
UI extensions
- Functions
- Web pixel extensions
- Payments extensions
All customization options are easy to install and upgrade-safe, enabling merchants to benefit from Shopify releases new products such as Shop Pay , or features such as One-page checkout .
For a detailed breakdown of the technologies that can be used to customize checkout, and the ways that you can extend checkout, refer to the options for customizing Shopify checkout .
If your extension sends data to your own app backend, such as storing records in your own database, build that backend with one of Shopify's official libraries . Shopify provides libraries for Node.js, Ruby on Rails, PHP frameworks like Laravel and Symfony ( shopify-app-php ), and Python frameworks like Django, Flask, and FastAPI ( shopify-app-python ).
Note
Checkout apps and extensions have design requirements that apply to custom apps as well as public apps. Be sure that your app meets all requirements for its functionality and distribution type.
Note :
Checkout apps and extensions have design requirements that apply to custom apps as well as public apps. Be sure that your app meets all requirements for its functionality and distribution type.
##
Anchor to Getting started Getting started
To learn how to customize and extend checkout, read the following tutorials.
###
Anchor to Checkout UI extensions tutorials Checkout UI extensions tutorials
Pre-purchase product offers
Build a pre-purchase upsell offer that prompts the customer to add a product to their order.
Pre-purchase product offers
Build a pre-purchase upsell offer that prompts the customer to add a product to their order.
Pre-purchase product offers
Build a pre-purchase upsell offer that prompts the customer to add a product to their order.
Post-purchase checkout extensions
Create a basic example of a post-purchase checkout extension.
Post-purchase checkout extensions
Create a basic example of a post-purchase checkout extension.
Post-purchase checkout extensions
Create a basic example of a post-purchase checkout extension.
Thank you and order status extensions
Build a survey that asks customers how they heard about the store after they made a purchase.
Thank you and order status extensions
Build a survey that asks customers how they heard about the store after they made a purchase.
Thank you and order status extensions
Build a survey that asks customers how they heard about the store after they made a purchase.
Custom banners
Learn how to add a custom banner to checkout.
Custom banners
Learn how to add a custom banner to checkout.
Custom banners
Learn how to add a custom banner to checkout.
Custom fields
Learn how to add custom fields to checkout that customers can use to add delivery instructions to their order.
Custom fields
Learn how to add custom fields to checkout that customers can use to add delivery instructions to their order.
Custom fields
Learn how to add custom fields to checkout that customers can use to add delivery instructions to their order.
Client-side validation
Use a checkout UI extension to validate fields at checkout and block customer progress.
Client-side validation
Use a checkout UI extension to validate fields at checkout and block customer progress.
Client-side validation
Use a checkout UI extension to validate fields at checkout and block customer progress.
Header
Use a checkout UI extension and the GraphQL Admin API's checkout branding types to customize the checkout header with custom images, including the back to cart link.
Header
Use a checkout UI extension and the GraphQL Admin API's checkout branding types to customize the checkout header with custom images, including the back to cart link.
Header
Use a checkout UI extension and the GraphQL Admin API's checkout branding types to customize the checkout header with custom images, including the back to cart link.
Footer
Use a checkout UI extension and the GraphQL Admin API's checkout branding types to customize the checkout footer with store policies.
Footer
Use a checkout UI extension and the GraphQL Admin API's checkout branding types to customize the checkout footer with store policies.
Footer
Use a checkout UI extension and the GraphQL Admin API's checkout branding types to customize the checkout footer with store policies.
Address autocomplete
Build an extension to customize the address autocomplete provider for the delivery and billing address forms in checkout.
Address autocomplete
Build an extension to customize the address autocomplete provider for the delivery and billing address forms in checkout.
Address autocomplete
Build an extension to customize the address autocomplete provider for the delivery and billing address forms in checkout.
###
Anchor to Shopify Functions tutorials Shopify Functions tutorials
Build a discount function
Use Shopify Functions to create a new discount type for users.
Build a discount function
Use Shopify Functions to create a new discount type for users.
Build a discount function
Use Shopify Functions to create a new discount type for users.
Create a payments function
Use Shopify Functions to hide a payment option offered to customers at checkout.
Create a payments function
Use Shopify Functions to hide a payment option offered to customers at checkout.
Create a payments function
Use Shopify Functions to hide a payment option offered to customers at checkout.
Build a delivery options function
Use Shopify Functions to rename a delivery option offered to customers at checkout.
Build a delivery options function
Use Shopify Functions to rename a delivery option offered to customers at checkout.
Build a delivery options function
Use Shopify Functions to rename a delivery option offered to customers at checkout.
Create a server-side validation function
Use Shopify Functions to block progress on a checkout when the cart line quantities exceed a limit.
Create a server-side validation function
Use Shopify Functions to block progress on a checkout when the cart line quantities exceed a limit.
Create a server-side validation function
Use Shopify Functions to block progress on a checkout when the cart line quantities exceed a limit.
Build a location rule function
Use Shopify Functions to choose a different order location during checkout.
Build a location rule function
Use Shopify Functions to choose a different order location during checkout.
Build a location rule function
Use Shopify Functions to choose a different order location during checkout.
Add a customized bundle function
Use Shopify Functions to group products together and sell them as a single unit.
Add a customized bundle function
Use Shopify Functions to group products together and sell them as a single unit.
Add a customized bundle function
Use Shopify Functions to group products together and sell them as a single unit.
Build a fulfillment constraints function
Use Shopify Functions to customize fulfillment and delivery strategies.
Build a fulfillment constraints function
Use Shopify Functions to customize fulfillment and delivery strategies.
Build a fulfillment constraints function
Use Shopify Functions to customize fulfillment and delivery strategies.
Build a local pickup options function
Use Shopify Functions to generate local pickup delivery options at checkout.
Build a local pickup options function
Use Shopify Functions to generate local pickup delivery options at checkout.
Build a local pickup options function
Use Shopify Functions to generate local pickup delivery options at checkout.
Create a local pickup charges function
Use Shopify Functions to create local pickup charges at checkout.
Create a local pickup charges function
Use Shopify Functions to create local pickup charges at checkout.
Create a local pickup charges function
Use Shopify Functions to create local pickup charges at checkout.
Generate a pickup points function
Use Shopify Functions to generate pickup point delivery options at checkout.
Generate a pickup points function
Use Shopify Functions to generate pickup point delivery options at checkout.
Generate a pickup points function
Use Shopify Functions to generate pickup point delivery options at checkout.
##
Anchor to Build for checkout Build for checkout
Checkout is where merchants solve a range of cross-cutting problems. Explore the hubs below for guides grouped by topic.
Discounts
Build custom discount types with Shopify Functions and configure them from the admin or customer accounts.
Discounts
Build custom discount types with Shopify Functions and configure them from the admin or customer accounts.
Discounts
Build custom discount types with Shopify Functions and configure them from the admin or customer accounts.
Payments
Provide customized payment processing for merchants on checkout.
Payments
Provide customized payment processing for merchants on checkout.
Payments
Provide customized payment processing for merchants on checkout.
Product bundles
Group products together and sell them as a single unit.
Product bundles
Group products together and sell them as a single unit.
Product bundles
Group products together and sell them as a single unit.
Purchase options
Offer subscriptions, pre-orders, and Try Before You Buy.
Purchase options
Offer subscriptions, pre-orders, and Try Before You Buy.
Purchase options
Offer subscriptions, pre-orders, and Try Before You Buy.
##
Anchor to Upgrade Upgrade
Deprecated
checkout.liquid is now unsupported for the Information, Shipping, and Payment checkout steps. checkout.liquid and additional scripts were sunset for the Thank you and Order status pages on August 28, 2025. Script tags were sunset on those pages on August 28, 2025 for Plus stores, and are sunset for non-Plus stores on August 26, 2026.
Stores that still use checkout.liquid for the Thank you and Order status pages must upgrade to Shopify Extensions in Checkout .
Deprecated :
checkout.liquid is now unsupported for the Information, Shipping, and Payment checkout steps. checkout.liquid and additional scripts were sunset for the Thank you and Order status pages on August 28, 2025. Script tags were sunset on those pages on August 28, 2025 for Plus stores, and are sunset for non-Plus stores on August 26, 2026.
Stores that still use checkout.liquid for the Thank you and Order status pages must upgrade to Shopify Extensions in Checkout .
A report identifying your current checkout customizations is available in the Shopify admin. The report provides high-level guidance to map customizations to Shopify Extensions in Checkout. Use this report to simplify your review of your existing customizations and to help you upgrade to Shopify Extensions in Checkout faster. Learn more .
To upgrade a checkout.liquid customization to Shopify Extensions in Checkout, take one or more of the following actions:
-
Use a public app that's built using extensions.
We're adding new checkout apps to the Shopify App Store on a regular basis. If there currently isn't a suitable public app for your customization, then consider simplifying your checkout temporarily and adding new apps to your store as they become available.
-
Build a custom app using extensions, or hire a service partner to build one for you.
In some cases, after you've upgraded you can revert to checkout.liquid until its sunset dates.
If you're upgrading a store to Shopify Extensions in Checkout, we recommend planning your in-checkout, Thank you page, and Order status page upgrades together, when possible, for the following benefits:
-
Avoid maintaining multiple tech stacks, like UI extensions and checkout.liquid .
-
Apply styling once to the entire experience.
-
Manage one sunset date for checkout.liquid rather than one date for pre-purchase pages and another for Thank you and Order status pages.
If this isn't possible, then we recommend prioritizing the upgrade for in-checkout pages first and upgrading after-purchase pages after that.
##
Anchor to Best practices Best practices
To optimize your app development experience, Shopify has established a set of best practices that you can refer to when developing an app that extends checkout.
Tip
We also recommend getting familiar with Polaris accessibility and content guidelines.
Tip :
We also recommend getting familiar with Polaris accessibility and content guidelines.
Checkout performance
Learn best practices for applying changes to checkout.
Checkout performance
Learn best practices for applying changes to checkout.
Checkout performance
Learn best practices for applying changes to checkout.
Create multi-page extensions
Learn more about building extensions that can render on any checkout page.
Create multi-page extensions
Learn more about building extensions that can render on any checkout page.
Create multi-page extensions
Learn more about building extensions that can render on any checkout page.
UX for checkout
Learn how to improve the quality of checkout experiences by following our UX guidelines for checkout.
UX for checkout
Learn how to improve the quality of checkout experiences by following our UX guidelines for checkout.
UX for checkout
Learn how to improve the quality of checkout experiences by following our UX guidelines for checkout.
Network requests from extensions
Learn about Cross-Origin Resource Sharing (CORS) and other security considerations when making network requests to your own server.
Network requests from extensions
Learn about Cross-Origin Resource Sharing (CORS) and other security considerations when making network requests to your own server.
Network requests from extensions
Learn about Cross-Origin Resource Sharing (CORS) and other security considerations when making network requests to your own server.
App Design Guidelines
Get practical guidance on how to design a user interface for the Shopify admin.
App Design Guidelines
Get practical guidance on how to design a user interface for the Shopify admin.
App Design Guidelines
Get practical guidance on how to design a user interface for the Shopify admin.
##
Anchor to Product roadmap Product roadmap
Some checkout customization features are in development and will be released later this year. The following are the features on our roadmap and our estimated launch dates:
Note
This roadmap is being shared for informational purposes and is subject to change. Bug fixes and improvements will be added as we hear from the community. Share your feedback or request new features by creating a new issue in the Shopify developer community forum .
Note :
This roadmap is being shared for informational purposes and is subject to change. Bug fixes and improvements will be added as we hear from the community. Share your feedback or request new features by creating a new issue in the Shopify developer community forum .
###
Anchor to Shopify Functions Shopify Functions
We'll continue to add new Shopify Functions APIs to further customize checkout business logic.
Milestone | Target |
Introduced a new Discount API that supports any combination of product, order, and shipping savings from a single function extension | April 2025 (shipped) |
Support for cart metafields on function input queries | July 2025 (shipped) |
Optionally reject discount codes and return custom messages when discounts shouldn't be applied (Discount API) | Q4 2025 (shipped) |
Support complex conditions for "Buy X Get Y" discounts (Discount API) | Q1 2026 (shipped) |
Changes to the Discount API to stack multiple discounts on the same product line item | Q1 2026 (shipped) |
Was this page helpful?
Yes No
