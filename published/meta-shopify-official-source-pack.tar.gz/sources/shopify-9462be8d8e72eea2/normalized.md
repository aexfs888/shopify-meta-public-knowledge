- Recent changes to Shopify’s platform Skip to main content
October 27, 2026
##
Security update: Offline token dates, new security features
Offline token enforcement dates, plus new security features: client credentials access, IP restrictions, network access declarations, identity verification, and a new app security hub.
Read the full story
Subscribe
All posts
-
Blog & announcements
-
Release notes
### Surfaces & APIs
Apps
Admin Extensions
Admin REST API
App Bridge
App Events API
App store
Built for Shopify
Checkout UI
Customer Accounts
Events & webhooks
Functions
GraphQL Admin API
Metafields & metaobjects
Payments Apps API
Polaris
POS Extensions
Storefronts
Ajax API
Customer Account API
Hydrogen
Liquid
Shop Minis
Shopify Theme Store
ShopifyQL
Storefront API
Themes
Agents
Catalog
UCP
Dev Platform
AI Toolkit
Dev Dashboard
Platform
Shopify CLI
Tools
### Versions
All versions
2027-01
2026-10
2026-08-25
2026-07
2026-04
2026-01
2025-10
2025-07
2025-04
### Change type
Action required
Breaking change
Deprecated
Latest 2026-10
Release candidate 2027-01
- 10.30
UI extensions now support a larger number of locales
Platform
- 10.30
New trusted vault origin signal in Payments Apps API
Payments Apps API
- 10.28
Shop SDK lead capture now supports Rich Authorization Requests
Tools
- 10.28
Start Sidekick conversations from your app
App Bridge
-
- 10.28
Shopify App Pricing: Plan Feature Targeting
App store
- 10.28
Shopify App Store: Estimated local-currency prices
App store
- 10.28
Merchant email now available on the ThemeSale object in the Partners API
Themes
- 10.28
Introducing theme app add-ons: Build and bundle apps with your themes
Shopify Theme Store
- 10.28
Make your app's activity reportable in Shopify Analytics with App Events
App Events API
- 10.28
App Events: Send events from Checkout and Customer Account UI extensions
App Events API
- 10.28
Shopify Flow: manage automations through AI Toolkit
API
- 10.28
Managed mode for Shopify Tax
Breaking changes Admin REST API
- 10.28
First sign-ins to customer accounts now set Customer.state and send customers/enable webhooks
GraphQL Admin API
- 10.28
Add selling plans to draft order line items with the Admin GraphQL API
GraphQL Admin API
- 10.28
Cart and checkout permalinks now support UCP at /buy
UCP
- 10.27
Store and app install details in the Dev Dashboard
Dev Dashboard
- 10.27
Manage payouts, billing, and settings in Dev Dashboard
Dev Dashboard
- 10.27
Migrate to expiring offline access tokens before January 1, 2027
Action required Platform
- 10.27
Secure your app with network access rules in shopify.app.toml
Platform
- 10.27
Restrict Admin API access with an IP allowlist
Dev Dashboard
- 10.27
Promoted Placements beta now includes Shop Campaigns
Catalog
- 10.27
Search brands that don't sell on Shopify in the Catalog API (beta)
Catalog
- 10.23
Analytics queryable capability is configurable in shopify.app.toml for metaobject definitions
API
- 10.23
Unlink a customer's identity provider subject with the GraphQL Admin API
GraphQL Admin API
- 10.22
Discover a merchant's retail stores with UCP location search and lookup
UCP
- 10.22
POS UI extensions now support reactive storage access
POS Extensions
- 10.22
POS UI extensions 2026-10 adds s-pos-list, a virtualized list with custom row templates
POS Extensions
- 10.22
Polaris 2.0 is now stable
Polaris
- 10.20
Metaobject analytics queryable capability available in the Admin API
GraphQL Admin API
-
10.20
###
Securing your app, together
Act now to secure your app: We're asking every app dev to act this week. We have new tools to help, including AI security scans, expiring tokens, and better log filtering. Read on to learn how.
Platform
- 10.20
Enable the analytics queryable capability on metafield and metaobject definitions from your app's TOML
Tools
- 10.19
Exclusive > timestamp filters exclude the full second
GraphQL Admin API
- 10.16
Checkout MCP and Cart MCP now support UCP buyer consent
UCP
-
10.15
###
Build with confidence: Shopify AI Toolkit's security check
Check your app for security vulnerabilities with `shopify app security check`. Run it before you submit an app, and on every release, to catch problems in your own code and get remediation guidance.
AI Toolkit
-
10.14
###
Hydrogen 2026-10 is now available
The new Hydrogen is now GA: A framework-agnostic JavaScript library to add Shopify commerce to your existing stack, plus skills for coding agents and starters for React Router and Next.js.
Hydrogen
- 10.13
Add shopping and Shop Pay checkout to any agent with Shop MCP
Tools
- 10.12
Cart updates that result in no changes to the cart no longer trigger carts/update webhooks
Ajax API
- 10.12
Detect when a POS extension screen finishes navigating
POS Extensions
- 10.12
Identify the published version running in a POS extension
POS Extensions
- 10.09
Global Catalog REST API stops serving traffic on November 2, 2026
Deprecated Catalog
- 10.09
Catalog API now returns compare-at prices as list_price
Catalog
- 10.08
Hydrogen developer preview update: October 8, 2026
Hydrogen
- 10.08
New owner_type field for metafield declarations in Checkout and Customer Account UI extensions, required in 2027-01
Action required Checkout UI
- 10.08
Shopify Flow: Flow Trigger Lifecycle Callback extensions now support relative url paths
Tools
- 10.07
Cart mutations reject unconfirmed writes in POS UI extensions 2026-10
Breaking changes POS Extensions
- 10.07
POS UI extensions now return percentage values for percentage discounts
Breaking changes POS Extensions
- 10.07
Per-customer request limit for the Customer Account API
Customer Account API
- 10.07
Downgrade app access scopes from write to read
GraphQL Admin API
- 10.02
Hydrogen developer preview update: October 2, 2026
Hydrogen
- 10.01
What's new in Polaris 2.0.0-rc.1
Polaris
-
10.01
###
More control over commerce updates with Next Gen Events
Fewer deliveries, richer payloads, no follow-up queries: Events is a declarative replacement for classic webhooks, now generally available across 18 topics.
Events & webhooks
- 10.01
New Shop Campaigns metrics and dimensions in ShopifyQL API version 2026-10
ShopifyQL
- 10.01
Rollouts queries and webhooks in the Admin GraphQL API
GraphQL Admin API
- 10.01
Discounts can now be included in Rollouts
Action required GraphQL Admin API
- 10.01
Orders webhooks now include selling_plan_id on line items
Events & webhooks
- 10.01
New fiscalDeviceIdentifier field on PointOfSaleDevice
GraphQL Admin API
- 10.01
metafieldInteger collection condition removed in API version 2027-01
Breaking changes GraphQL Admin API
- 10.01
Added parseWarnings to ShopifyqlQueryResponse
GraphQL Admin API
- 10.01
The orderCancel mutation now returns a structured jobResult
GraphQL Admin API
- 10.01
SMS marketing consent now available on the CustomerPhoneNumber object
Action required GraphQL Admin API
- 10.01
Tax webhook summary and calculation requests now use Global IDs
Breaking changes GraphQL Admin API
- 10.01
New SubscriptionContractCalculation API for subscription management
Action required GraphQL Admin API
- 10.01
Inventory shipment webhooks include inventory transfer IDs
Events & webhooks
- 10.01
Updated function syntax on the segment query language
Breaking changes GraphQL Admin API
- 10.01
Return policy profiles are now available in the GraphQL Admin API
GraphQL Admin API
- 10.01
New APIs for buyer-requested order edits
GraphQL Admin API
- 10.01
New tax fields for return shipping fees in the GraphQL Admin API
GraphQL Admin API
-
10.01
### 2026-10: Release notes
Covers order tax recalculation, metafield filter errors, and removed checkout fields.
- 09.30
Use app intents for your discount app
Functions
- 09.29
More resilient token exchanges when migrating tokens without a user session
GraphQL Admin API
- 09.29
Manage packed product dimensions with the GraphQL Admin API
GraphQL Admin API
- 09.29
Move existing subscriptions to Shopify App Pricing
App store
- 09.28
Sidekick can now invoke app intents without tools
Platform
- 09.28
WebMCP support for checkout
Platform
- 09.25
AI Toolkit skills have been consolidated to shopify
Action required AI Toolkit
-
09.25
###
The new Dev Dashboard: your command center for building
One home for your apps and the stores you work in: Designed to make your everyday easier.
Dev Dashboard
- 09.25
Shopify Payments Balance Transaction GraphQL type supports currency conversion type
GraphQL Admin API
- 09.24
Polaris 2.0 release candidate
Polaris
- 09.22
Events subscription query complexity limit is changing to 100 points
Breaking changes Events & webhooks
- 09.22
Polaris CDN 1.1 is now stable
Polaris
- 09.22
Removing marketCurrencySettingsUpdate mutation
Breaking changes GraphQL Admin API
- 09.21
Unlimited private plans and target stores in Shopify App Pricing
App store
- 09.21
New translatable boolean field for Metafield GraphQL Object
GraphQL Admin API
- 09.18
The automaticDiscounts query is removed in API version 2027-01
Breaking changes GraphQL Admin API
- 09.17
Request a bundle size exception for existing UI extensions
Admin Extensions
- 09.17
Adding a canceled receive action to the inventory shipments API
GraphQL Admin API
- 09.17
Removed session.currentSession.staffMemberId from POS UI Extensions (2026-10)
Breaking changes POS Extensions
- 09.17
Purchase Order Read API
GraphQL Admin API
- 09.17
Query market hierarchies with the GraphQL Admin API
GraphQL Admin API
- 09.17
New Pricing audit trail for contextual product variant prices
GraphQL Admin API
- 09.16
Updates to Events payloads and subscription configuration
Action required Events & webhooks
- 09.15
Filter Catalog search results by media type
Catalog
- 09.15
Dynamic complexity cost for metafieldsSet mutation
GraphQL Admin API
- 09.15
Prepare your app for the Shopify admin's new look
Polaris
- 09.15
family_name is optional for B2B orders in Payments Apps API requests
Payments Apps API
- 09.15
Delivery options in Shopify Functions input now expose their metafields
Functions
- 09.11
Hydrogen developer preview update: September 11, 2026
Hydrogen
- 09.10
Discounts Allocator Function API developer preview has ended
Action required GraphQL Admin API
- 09.09
Create and delete dev stores in Shopify CLI
Shopify CLI
Load more
