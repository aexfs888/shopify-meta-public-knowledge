- Recent changes to Shopify’s platform Skip to main content
September 25, 2026
##
The new Dev Dashboard: your command center for building
One home for your apps and the stores you work in: Designed to make your everyday easier.
Read the full story
Subscribe
All posts
-
Blog & announcements
-
Release notes
### Surfaces & APIs
Apps
Admin Extensions
Admin GraphQL API
Admin REST API
App Bridge
App Events API
App store
Built for Shopify
Checkout UI
Customer Accounts
Events & webhooks
Functions
Metafields & metaobjects
Payments Apps API
Polaris
POS Extensions
Storefronts
Customer Account API
Hydrogen
Liquid
Shop Minis
Shopify Theme Store
ShopifyQL
Storefront API
Themes
Agents
Catalog
UCP
Dev Platform
AI Toolkit
Dev Dashboard
Platform
Shopify CLI
Tools
### Versions
All versions
2027-01
2026-10
2026-07
2026-04
2026-01
2025-10
2025-07
2025-04
2025-01
### Change type
Action required
Breaking change
Deprecated
Latest 2026-10
Release candidate 2027-01
- 10.09
Global Catalog REST API stops serving traffic on November 2, 2026
Deprecated Catalog
- 10.09
Catalog API now returns compare-at prices as list_price
Catalog
- 10.08
New owner_type field for metafield declarations in Checkout and Customer Account UI extensions, required in 2027-01
Action required Checkout UI
- 10.07
Cart mutations reject unconfirmed writes in POS UI extensions 2026-10
Breaking changes POS Extensions
- 10.07
POS UI extensions now return percentage values for percentage discounts
Breaking changes POS Extensions
- 10.07
Per-customer request limit for the Customer Account API
Customer Account API
- 10.07
Downgrade app access scopes from write to read
Admin GraphQL API
- 10.01
What's new in Polaris 2.0.0-rc.1
Polaris
-
10.01
###
More control over commerce updates with Next Gen Events
Fewer deliveries, richer payloads, no follow-up queries: Events is a declarative replacement for classic webhooks, now generally available across 18 topics.
Events & webhooks
- 10.01
New Shop Campaigns metrics and dimensions in ShopifyQL API version 2026-10
ShopifyQL
- 10.01
Rollouts queries and webhooks in the Admin GraphQL API
Admin GraphQL API
- 10.01
Discounts can now be included in Rollouts
Action required Admin GraphQL API
- 10.01
Orders webhooks now include selling_plan_id on line items
Events & webhooks
- 10.01
New fiscalDeviceIdentifier field on PointOfSaleDevice
Admin GraphQL API
- 10.01
metafieldInteger collection condition removed in API version 2027-01
Breaking changes Admin GraphQL API
- 10.01
Added parseWarnings to ShopifyqlQueryResponse
Admin GraphQL API
- 10.01
The orderCancel mutation now returns a structured jobResult
Admin GraphQL API
- 10.01
SMS marketing consent now available on the CustomerPhoneNumber object
Action required Admin GraphQL API
- 10.01
Tax webhook summary and calculation requests now use Global IDs
Breaking changes Admin GraphQL API
- 10.01
New SubscriptionContractCalculation API for subscription management
Action required Admin GraphQL API
- 10.01
Inventory shipment webhooks include inventory transfer IDs
Events & webhooks
- 10.01
Updated function syntax on the segment query language
Breaking changes Admin GraphQL API
- 10.01
Return policy profiles are now available in the GraphQL Admin API
Admin GraphQL API
- 10.01
New APIs for buyer-requested order edits
Admin GraphQL API
- 10.01
New tax fields for return shipping fees in the GraphQL Admin API
Admin GraphQL API
-
10.01
### 2026-10: Release notes
Covers order tax recalculation, metafield filter errors, and removed checkout fields.
- 09.30
Use app intents for your discount app
Functions
- 09.29
More resilient token exchanges when migrating tokens without a user session
Admin GraphQL API
- 09.29
Manage packed product dimensions with the Admin GraphQL API
Admin GraphQL API
- 09.29
Move existing subscriptions to Shopify App Pricing
App store
- 09.28
Sidekick can now invoke app intents without tools
Platform
- 09.28
WebMCP support for checkout
Platform
- 09.25
AI Toolkit skills have been consolidated to shopify
Action required AI Toolkit
- 09.25
Shopify Payments Balance Transaction GraphQL type supports currency conversion type
Admin GraphQL API
- 09.24
Polaris 2.0 release candidate
Polaris
- 09.22
Events subscription query complexity limit is changing to 100 points
Breaking changes Events & webhooks
- 09.22
Polaris CDN 1.1 is now stable
Polaris
- 09.22
Removing marketCurrencySettingsUpdate mutation
Breaking changes Admin GraphQL API
- 09.21
Unlimited private plans and target stores in Shopify App Pricing
App store
- 09.21
New translatable boolean field for Metafield GraphQL Object
Admin GraphQL API
- 09.18
The automaticDiscounts query is removed in API version 2027-01
Breaking changes Admin GraphQL API
- 09.17
Request a bundle size exception for existing UI extensions
Admin Extensions
- 09.17
Adding a canceled receive action to the inventory shipments API
Admin GraphQL API
- 09.17
Removed session.currentSession.staffMemberId from POS UI Extensions (2026-10)
Breaking changes POS Extensions
- 09.17
Query market hierarchies with the GraphQL Admin API
Admin GraphQL API
- 09.17
New Pricing audit trail for contextual product variant prices
Admin GraphQL API
- 09.16
Updates to Events payloads and subscription configuration
Action required Events & webhooks
- 09.15
Filter Catalog search results by media type
Catalog
- 09.15
Dynamic complexity cost for metafieldsSet mutation
Admin GraphQL API
- 09.15
Prepare your app for the Shopify admin's new look
Polaris
- 09.15
family_name is optional for B2B orders in Payments Apps API requests
Payments Apps API
- 09.15
Delivery options in Shopify Functions input now expose their metafields
Functions
- 09.10
Discounts Allocator Function API developer preview has ended
Action required Admin GraphQL API
- 09.09
Create and delete dev stores in Shopify CLI
Shopify CLI
- 09.08
Variants now support multiple barcodes
Action required Admin GraphQL API
- 09.08
Customer Address APIs now support countryCode
Deprecated Checkout UI
- 09.04
Shopify storefronts now support UCP 2026-08-25
UCP
- 09.03
Hydrogen developer preview update: September 2, 2026
Hydrogen
- 09.03
New paymentInstrumentSendAddEmail mutation emails customers a link to add a payment method for a subscription, order, or draft order
Admin GraphQL API
- 08.31
Polaris CDN 1.1 release candidate
Polaris
- 08.31
The Polaris CDN is adopting semantic versioning
Polaris
- 08.28
More resilient refreshes for expiring offline access tokens
Admin GraphQL API
- 08.27
Password Protected Shop Dev flows on Shopify Theme CLI v3.83.x and older to be deprecated
Action required Themes
- 08.26
Four additional topics are now available for Events
Events & webhooks
- 08.26
Build Shopify apps in PHP and Python with new official packages
Tools
- 08.26
GitHub commits now name the last theme editor
Themes
- 08.25
Oxygen is now available on trial plan stores
Hydrogen
- 08.24
Script tags are deprecated and will stop running on March 1, 2027
Action required Admin GraphQL API
- 08.19
App intents on admin.app.intent.link now open as a full-page navigation
Platform
- 08.18
Hydrogen developer preview update: August 18, 2026
Hydrogen
- 08.10
Shop Campaigns performance data now available via ShopifyQL
Admin GraphQL API
- 08.06
Standard storefront events and actions now support cart attributes
Platform
- 08.05
Draft order and transfer/shipment inventory is moving from reserved to committed
Admin GraphQL API
- 08.05
WebMCP support for Liquid and Hydrogen storefronts
Platform
- 08.03
Oxygen is now available on development stores
Hydrogen
- 08.03
The orderCreate mutation now supports multiple tracking numbers for each fulfillment
Admin GraphQL API
- 08.01
Updated Built for Shopify requirements for Fulfillment services apps
Built for Shopify
- 07.31
Hydrogen developer preview update: July 30, 2026
Hydrogen
- 07.31
New fields for cash management activities and drawers in POS
Admin GraphQL API
- 07.30
Merchants now see partner details on collaborator requests
Dev Dashboard
- 07.30
The shopify-account component for customer accounts is now a Theme Store requirement
Themes
- 07.30
createdAt is now available on the Customer object in Shopify Functions
Functions
- 07.30
Updating an order's shipping address recalculates taxes as of API version 2026-10
Breaking changes Admin GraphQL API
- 07.27
POS UI extensions can now print directly to hardware receipt printers
POS Extensions
- 07.27
SubscriptionContractCalculation API now available in early access
Admin GraphQL API
- 07.24
Invalid metafield queries now return errors in the GraphQL Admin API
Breaking changes Admin GraphQL API
-
07.22
###
Meet the 2026 Shopify Build Award winners
Meet the 2026 Shopify Build Award winners across apps, storefronts, merchant impact, and community.
Partners
- 07.21
Metafield triggers and additional topics are now available for Events
Events & webhooks
- 07.21
Liquid templates can now compose pages with blocks and partials
Liquid
-
07.21
###
Full-stack capabilities to power app analytics
Shopify Analytics is now a full-stack platform for apps. Model, query, embed, and enrich analytics on Shopify without managing your own data infrastructure.
Admin GraphQL API
- 07.17
Physical inventory feature preview
Admin GraphQL API
- 07.16
Card deposit endpoint now requires mTLS certificate
API
-
07.15
###
Sign in with Shop opens to storefront apps
Sign in with Shop is now a drop-in component any storefront app can integrate — wishlists, back-in-stock, loyalty, and more.
Partners
- 07.15
Updated App Store requirements: 4.1.2 Use a unique name for your app
App store
- 07.15
Storefront API @inContext supports channelId
Storefront API
- 07.15
productId , title , variantSku , and variantTitle fields added to ExchangeLineItem
Admin GraphQL API
- 07.15
POS UI Extensions 2026-07 adds discount allocations to bundle components
POS Extensions
- 07.09
POS Extensions now supports a background extension target
POS Extensions
- 07.09
Identity verification for Shopify Partners starts today
Action required Platform
- 07.09
Hydrogen developer preview update: July 8, 2026
Hydrogen
Load more
