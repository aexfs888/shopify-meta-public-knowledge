- Recent changes to Shopify’s platform Skip to main content
Search changelog
Latest 2026-10
Release candidate 2027-01
11.19
###
App security updates: IP allowlist due tomorrow
IP allowlist enforcement starts tomorrow, November 20. New requirements needed by December 1. All apps have access to security tooling in Dev Dashboard. You can also now test your token migration.
Platform
- 11.19
Function settings extensions can now report several errors at once
Admin Extensions
- 11.19
Network access declarations are now required for apps that run on the online store
Platform
- 11.19
Expiring offline access tokens required for new custom apps as of December 1, 2026
Admin REST API
- 11.19
abandonedCheckoutUrl now requires level 2 protected customer data access
Breaking changes Admin REST API
- 11.19
Subscriptions now support store credit with allowStoreCredit
Customer Account API
- 11.19
RolloutChange now includes applyResult
GraphQL Admin API
- 11.18
App Events: Send events from Admin UI extensions and embedded apps
Admin Extensions
- 11.18
draftOrderCreate and draftOrderUpdate require the apply_discounts_to_draft_orders permission to add discounts
Breaking changes GraphQL Admin API
- 11.17
Admin-created custom apps now appear in the Dev Dashboard
Dev Dashboard
- 11.17
Amazon EventBridge webhook payload size limit increased to 1 MB
Events & webhooks
- 11.17
Updated B2B location access in the Customer Account API
Customer Account API
- 11.16
Declare that your app uses only expiring Admin API tokens
Dev Dashboard
-
11.13
###
App security updates: Thank you, plus what's required next
Thank you for adding IP allowlists for bulk operations. Here's what's required now, what's new, and what's coming next for your apps and partner account.
Platform
- 11.13
Checkout Function cart.deliverableLine inputs now model cost and link to their relevant cart.line
Functions
- 11.13
Market metafields break ties between equally specific markets by market handle
Functions
- 11.13
Market.metafields matches keys in any case as of Storefront API version 2027-01
Breaking changes Storefront API
- 11.12
Remove your app from the Shopify App Store yourself
App store
- 11.11
IP allowlists are now required for custom apps installed outside your organization
Dev Dashboard
- 11.11
App IP allowlists now support IP addresses and ASNs together, and up to 250 IPs
Dev Dashboard
- 11.11
Storefront MCP policies and FAQs tool is being deprecated in favor of UCP MCP Ask tool
Action required API
- 11.11
Customer data erasure requests updated from 10 days to 5
Platform
- 11.10
Shopify App Store submission requirements: build, grow, then expand
App store
- 11.09
Redesigned Partner Directory with profiles built on Shopify data
Platform
- 11.06
Partner apps must enable bulk operations before use
GraphQL Admin API
- 11.06
Dev Dashboard now shows when checkout and customer account UI extensions fail to load
Dev Dashboard
- 11.06
Merchant notes on store credit transactions
GraphQL Admin API
- 11.06
orderCreate line items support custom IDs
GraphQL Admin API
- 11.05
Order routing functions can now rank locations across multiple fulfillment groups in the unstable Function APIs.
Functions
-
11.05
###
App security updates: IP allowlist is now required
The IP allowlist is now required for every public app by November 20, or November 12 if you use bulk ops. ASN support covers serverless hosting. Plus token updates.
Platform
- 11.05
IP allowlists are now required for public apps
Action required Platform
- 11.05
App IP allowlists now support apps with serverless hosting through ASNs
Dev Dashboard
- 11.04
Test app network access configuration on dev stores
Platform
- 11.04
RETRY_DECLINED added to CustomerPaymentMethodRevocationReason
GraphQL Admin API
- 10.31
currententrychange now returns the previous page in event.from for customer account full-page extensions
Breaking changes Customer Account API
- 10.30
UI extensions now support a larger number of locales
Platform
- 10.30
Gift Card line_item_id will become read-only in REST Admin API version 2027-01
Breaking changes Admin REST API
- 10.30
New trusted vault origin signal in Payments Apps API
Payments Apps API
- 10.29
FulfillmentOrderDestination now includes provinceCode
GraphQL Admin API
- 10.28
Shop SDK lead capture now supports Rich Authorization Requests
Tools
- 10.28
Start Sidekick conversations from your app
App Bridge
- 10.28
Shopify App Pricing: Plan Feature Targeting
App store
- 10.28
Shopify App Store: Estimated local-currency prices
App store
- 10.28
Merchant email now available on the ThemeSale object in the Partners API
Themes
- 10.28
Introducing theme app add-ons: Build and bundle apps with your themes
Shopify Theme Store
- 10.28
Make your app's activity reportable in Shopify Analytics with App Events
App Events API
- 10.28
App Events: Send events from Checkout and Customer Account UI extensions
App Events API
- 10.28
Shopify Flow: manage automations through AI Toolkit
API
- 10.28
Managed mode for Shopify Tax
Breaking changes Admin REST API
- 10.28
First sign-ins to customer accounts now set Customer.state and send customers/enable webhooks
GraphQL Admin API
- 10.28
Add selling plans to draft order line items with the Admin GraphQL API
GraphQL Admin API
- 10.28
Cart and checkout permalinks now support UCP at /buy
UCP
- 10.27
Store and app install details in the Dev Dashboard
Dev Dashboard
- 10.27
Manage payouts, billing, and settings in Dev Dashboard
Dev Dashboard
-
10.27
###
Security update: Offline token dates, new security features
Offline token enforcement dates, plus new security features: client credentials access, IP restrictions, network access declarations, identity verification, and a new app security hub.
Platform
- 10.27
Migrate to expiring offline access tokens before January 1, 2027
Action required Platform
- 10.27
Secure your app with network access rules in shopify.app.toml
Platform
- 10.27
Restrict Admin API access with an IP allowlist
Dev Dashboard
- 10.27
Promoted Placements beta now includes Shop Campaigns
Catalog
- 10.27
Search brands that don't sell on Shopify in the Catalog API (beta)
Catalog
- 10.23
Analytics queryable capability is configurable in shopify.app.toml for metaobject definitions
API
- 10.23
Unlink a customer's identity provider subject with the GraphQL Admin API
GraphQL Admin API
- 10.22
Discover a merchant's retail stores with UCP location search and lookup
UCP
- 10.22
POS UI extensions now support reactive storage access
POS Extensions
- 10.22
POS UI extensions 2026-10 adds s-pos-list, a virtualized list with custom row templates
POS Extensions
- 10.22
Polaris 2.0 is now stable
Polaris
- 10.20
Metaobject analytics queryable capability available in the Admin API
GraphQL Admin API
-
10.20
###
Securing your app, together
Act now to secure your app: We're asking every app dev to act this week. We have new tools to help, including AI security scans, expiring tokens, and better log filtering. Read on to learn how.
Platform
- 10.20
Enable the analytics queryable capability on metafield and metaobject definitions from your app's TOML
Tools
- 10.19
Exclusive > timestamp filters exclude the full second
GraphQL Admin API
- 10.16
Checkout MCP and Cart MCP now support UCP buyer consent
UCP
-
10.15
###
Build with confidence: Shopify AI Toolkit's security check
Check your app for security vulnerabilities with `shopify app security check`. Run it before you submit an app, and on every release, to catch problems in your own code and get remediation guidance.
AI Toolkit
-
10.14
###
Hydrogen 2026-10 is now available
The new Hydrogen is now GA: A framework-agnostic JavaScript library to add Shopify commerce to your existing stack, plus skills for coding agents and starters for React Router and Next.js.
Hydrogen
- 10.13
Add shopping and Shop Pay checkout to any agent with Shop MCP
Tools
- 10.12
Cart updates that result in no changes to the cart no longer trigger carts/update webhooks
Ajax API
- 10.12
Detect when a POS extension screen finishes navigating
POS Extensions
- 10.12
Identify the published version running in a POS extension
POS Extensions
- 10.09
Global Catalog REST API stops serving traffic on November 2, 2026
Deprecated Catalog
- 10.09
Catalog API now returns compare-at prices as list_price
Catalog
- 10.08
Hydrogen developer preview update: October 8, 2026
Hydrogen
- 10.08
New owner_type field for metafield declarations in Checkout and Customer Account UI extensions, required in 2027-01
Action required Checkout UI
- 10.08
Shopify Flow: Flow Trigger Lifecycle Callback extensions now support relative url paths
Tools
- 10.07
Cart mutations reject unconfirmed writes in POS UI extensions 2026-10
Breaking changes POS Extensions
- 10.07
POS UI extensions now return percentage values for percentage discounts
Breaking changes POS Extensions
- 10.07
Per-customer request limit for the Customer Account API
Customer Account API
- 10.07
Downgrade app access scopes from write to read
GraphQL Admin API
- 10.02
Hydrogen developer preview update: October 2, 2026
Hydrogen
- 10.01
What's new in Polaris 2.0.0-rc.1
Polaris
-
10.01
###
More control over commerce updates with Next Gen Events
Fewer deliveries, richer payloads, no follow-up queries: Events is a declarative replacement for classic webhooks, now generally available across 18 topics.
Events & webhooks
- 10.01
New Shop Campaigns metrics and dimensions in ShopifyQL API version 2026-10
ShopifyQL
- 10.01
Rollouts queries and webhooks in the Admin GraphQL API
GraphQL Admin API
- 10.01
Discounts can now be included in Rollouts
Action required GraphQL Admin API
- 10.01
Orders webhooks now include selling_plan_id on line items
Events & webhooks
- 10.01
New fiscalDeviceIdentifier field on PointOfSaleDevice
GraphQL Admin API
- 10.01
metafieldInteger collection condition removed in API version 2027-01
Breaking changes GraphQL Admin API
- 10.01
Added parseWarnings to ShopifyqlQueryResponse
GraphQL Admin API
- 10.01
The orderCancel mutation now returns a structured jobResult
GraphQL Admin API
- 10.01
SMS marketing consent now available on the CustomerPhoneNumber object
Action required GraphQL Admin API
- 10.01
Tax webhook summary and calculation requests now use Global IDs
Breaking changes GraphQL Admin API
Load more
