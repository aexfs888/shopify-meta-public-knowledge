- 100-101: Meta Certified Digital Marketing Associate Exam | Meta for Business
### Meta Blueprint > Credentials > Meta Certified Digital Marketing Associate
# 100-101: Meta Certified Digital Marketing Associate
Digital Marketing Associates understand the value that advertising on Meta technologies can deliver for businesses, and they can use foundational tools to build campaigns.
Register now
Explore learning resources
## About the certification
Duration:
90 minutes
Exam audience:
This exam is for entry-level marketers, including students, job seekers and people changing careers.
## Additional certification opportunities
Once you’ve become a Meta Certified Digital Marketing Associate, you can earn a Meta Certified Media Measurement Specialist badge.
### Media Measurement Specialist
Develop your ability to analyze and interpret measurement results, and learn how to apply relevant next steps based on the data you obtain.
One of the following certifications is a prerequisite:
Digital Marketing Associate
- Creative Strategy Professional
- Media Planning Professional
- Media Buying Professional
- Business Marketing Strategy
Learn more
Learning resources
## Learning resources
Earn your certification using Meta Blueprint’s self-guided sessions and resources.
## Practice test
Use this 30-question exam to check if you're ready for certification or find gaps in your current knowledge. It's a time-saving tool to focus your learning.
Test your skills
## Online courses
Meta Blueprint offers text-based and curated onscreen courses to help you build your digital skills.
Start studying
## Study guide
Break down the information you'll need to earn your certification and structure your own Meta Blueprint study plan. The study guide includes a glossary and highlights from your curriculum to help accelerate your path to becoming an expert.
Explore the guide
## Webinars
Attend live webinar events for the Digital Marketing Associate certification.
Sign up for live events
## Ready to take your exam?
Register for the exam
## Frequently asked questions about the Digital Marketing Associate Exam
Expand all Collapse all
### General questions
Q: What languages is this certification offered in?
A: This certification is available in Traditional Chinese, English, French, German, Korean, Portuguese (Brazilian) and Spanish (LATAM).
Q: When will my certification expire?
A: Your certification is valid for 24 months from the day earned.
### Exam content outline
Some important details to consider when taking an exam:
Q: What does the exam cover, and are certain topics more important than others?
A: The Digital Marketing Certification exam consists of the following sections. The percentages reveal how much each section will count toward your final grade, and you can review the specific skills that will be covered within each one.
Use this breakdown to guide your studying and develop the skills that are most critical to earning a certification and advancing your career.
The value of Meta technologies (8%)
This section will test your ability to:
- Identify Meta technologies.
- Communicate the value proposition of Meta technologies for businesses.
Establish a business presence (15%)
This section will test your ability to:
- Identify the steps to establish a business presence on Facebook, Instagram and WhatsApp and the tools needed to engage with audiences.
- Explain the process to customize settings within Meta Ads Manager.
- Apply creative best practices optimized for mobile experiences.
Advertising fundamentals (23%)
This section will test your ability to:
- Recognize the value of advertising on Meta technologies.
- Recognize the importance of matching business goals to ad campaign objectives.
- Communicate the value of the Meta Pixel, Conversions API, and SDK.
- Describe how people are charged for ads and where the ads are shown.
- Identify data privacy protections and common ad policies.
Create and manage ads (44%)
This section will test your ability to:
- Identify the differences among boosting a Page post, promoting a post on Instagram and creating an ad in Ads Manager.
- Identify settings available at the campaign, ad set and ad level.
- Determine the ad campaign objective to achieve business goals.
- Identify ad targeting capabilities.
- Determine the appropriate ad placements and ad formats for a given scenario.
- Identify budget and ad scheduling options.
- Identify the relationship between budget and estimated results.
Reporting (10%)
This section will test your ability to:
- Identify campaign results through Meta Ads Reporting.
- Measure the success of a campaign.
### Recertification
Q: How do I get recertified?
A: To renew your certification you will need to retake the Digital Marketing Associate Exam.
Please note the following:
- The exam has 60 questions and is 90 minutes long.
- The passing score is 700 out of 1,000.
- There is a five-day waiting period to retake the exam, if you don’t pass.
- You have access to free study materials .
To retake the exam, schedule an exam appointment . After passing the exam, you’ll receive a recertification confirmation email.
## Additional resources
### Certified Company at Meta
### Live and recorded webinars
## Additional questions?
We are here to help.
Contact support
## Related Content
Meta Blueprint Digital Marketing Associate Exam: 100-101
Meta Blueprint Digital Marketing Associate Exam: 100-101
Meta Blueprint Digital Marketing Associate Exam: 100-101
100-101: Meta Certified Digital Marketing Associate Exam
410-101: Meta Certified Media Buying Professional Exam
Meta Blueprint Professional Media Buying Exam: 410-101
## Stay in the know with Meta Blueprint
Sign up for a free Meta Blueprint account to get webinar invites, course updates and certification news delivered to your inbox.
Sign up
© 2026 Meta
About Developers Careers Privacy Cookies Terms Help Center
English (US) English (UK) Español Português (Brasil) Français (France) Español (España) More languages
#### Log in to Meta for Business
Manage your ad accounts and get personalized support.
Log in with Facebook
