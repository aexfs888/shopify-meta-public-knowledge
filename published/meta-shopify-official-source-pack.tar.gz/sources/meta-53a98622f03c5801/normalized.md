# Detailed Targeting
With [Targeting Search](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/targeting-search), you can find targeting with one targeting type in a single API call. With the Detailed Targeting API, you can search for multiple targeting types in a single request. You can also get suggestions based on your query.
The API has four endpoints: [Search](#search), [Suggestions](#suggestions), [Browse](#browse), and [Validation](#validation).
The response for these endpoints contains the following:
| Name | Description |
| --- | --- |
| `id`&lt;br&gt;&lt;br&gt;type: string | Target audience ID |
| `name`&lt;br&gt;&lt;br&gt;type: string | Name of the target audience |
| `audience_size_lower_bound`&lt;br&gt;&lt;br&gt;type: integer | Estimated lower bound target audience size |
| `audience_size_upper_bound`&lt;br&gt;&lt;br&gt;type: integer | Estimated upper bound target audience size |
| `path`&lt;br&gt;&lt;br&gt;type: array of strings | Includes the category and any parent categories the targeting falls into |
| `description`&lt;br&gt;&lt;br&gt;type: string | A short description of the target audience |
If you do not provide `limit_type`, the API filters results with fewer than 2,000 people into four categories: `work_employers`, `work_positions`, `education_majors`, `education_schools`. Otherwise you get fewer meaningful results. When you use `limit_type`, results are filtered for one of those four categories and not everything is returned.
## Search &#123;#search&#125;
Retrieve target audiences for your ads that match your search query. You can provide the following parameters at this endpoint:
```
curl -G \
-d &quot;q=harvard&quot; \
-d &quot;access_token=&lt;ACCESS_TOKEN&gt;&quot; \
https://graph.facebook.com/&lt;API_VERSION&gt;/act_&lt;AD_ACCOUNT_ID&gt;/targetingsearch
```
| Name | Description |
| --- | --- |
| `q`&lt;br&gt;&lt;br&gt;type: string | **Required.**&lt;br&gt;&lt;br&gt;Query string. |
| `limit`&lt;br&gt;&lt;br&gt;type: integer | **Optional.**&lt;br&gt;&lt;br&gt;Number of results. |
| `limit_type`&lt;br&gt;&lt;br&gt;type: string | **Optional.**&lt;br&gt;&lt;br&gt;Limit the type of audience to retrieve. Defaults to all types.&lt;br&gt;&lt;br&gt;Valid values:&lt;br&gt;&lt;br&gt;- `interests`&lt;br&gt;- `education_schools`&lt;br&gt;- `education_majors`&lt;br&gt;- `work_positions`&lt;br&gt;- `work_employers`&lt;br&gt;- `relationship_statuses`&lt;br&gt;- `college_years`&lt;br&gt;- `education_statuses`&lt;br&gt;- `family_statuses`&lt;br&gt;- `industries`&lt;br&gt;- `life_events`&lt;br&gt;- `behaviors`&lt;br&gt;- `income` |
| `locale`&lt;br&gt;&lt;br&gt;type: string | **Optional.**&lt;br&gt;&lt;br&gt;The locale to display audience names and descriptions, if available. Defaults to the ad account&#039;s locale. |
## Suggestions &#123;#suggestions&#125;
Returns additional audiences you can target based on the audiences you provide.
```
curl -G \
-d &quot;targeting_list=[&#123;&#039;type&#039;:&#039;interests&#039;,&#039;id&#039;:6003263791114&#125;]&quot; \
-d &quot;access_token=&lt;ACCESS_TOKEN&gt;&quot; \
https://graph.facebook.com/&lt;API_VERSION&gt;/act_&lt;AD_ACCOUNT_ID&gt;/targetingsuggestions
```
Provide these parameters:
| Name | Description |
| --- | --- |
| `targeting_list`&lt;br&gt;&lt;br&gt;type: array of `&#123;&#039;type&#039;:&#039;&#123;TYPE&#125;&#039;, &#039;id&#039;:&#123;ID&#125;&#125;` | **Required.**&lt;br&gt;&lt;br&gt;Array of `&#123;&#039;type&#039;:&#039;&#123;TYPE&#125;&#039;, &#039;id&#039;:&#123;ID&#125;&#125;` pairs as input audience for suggestions. |
| `limit`&lt;br&gt;&lt;br&gt;type: integer | **Optional.**&lt;br&gt;&lt;br&gt;Number of results. Default is 30. Maximum is 45. |
| `limit_type`&lt;br&gt;&lt;br&gt;type: string | **Optional.**&lt;br&gt;&lt;br&gt;Limit the type of audience to retrieve. Defaults to all types.&lt;br&gt;&lt;br&gt;Valid values:&lt;br&gt;&lt;br&gt;- `interests`&lt;br&gt;- `education_schools`&lt;br&gt;- `education_majors`&lt;br&gt;- `work_positions`&lt;br&gt;- `work_employers`&lt;br&gt;- `relationship_statuses`&lt;br&gt;- `college_years`&lt;br&gt;- `education_statuses`&lt;br&gt;- `family_statuses`&lt;br&gt;- `industries`&lt;br&gt;- `life_events`&lt;br&gt;- `behaviors`&lt;br&gt;- `income` |
| `locale`&lt;br&gt;&lt;br&gt;type: string | **Optional.**&lt;br&gt;&lt;br&gt;The locale to display audience names and descriptions. Defaults to the ad account&#039;s locale. |
## Browse &#123;#browse&#125;
Get targeting in a structured taxonomy for Facebook categories, third-party data providers, and some interests. Results from this endpoint appear in the Browse function of the Detailed Targeting UI component in Ads Manager.
```
curl -G \
-d &quot;access_token=&lt;ACCESS_TOKEN&gt;&quot; \
https://graph.facebook.com/&lt;API_VERSION&gt;/act_&lt;AD_ACCOUNT_ID&gt;/targetingbrowse
```
Provide the following optional parameters:
| Name | Description |
| --- | --- |
| `limit_type`&lt;br&gt;&lt;br&gt;type: string | **Optional.**&lt;br&gt;&lt;br&gt;Limit the type of audience to retrieve. Defaults to all types. |
| `locale`&lt;br&gt;&lt;br&gt;type: string | **Optional.**&lt;br&gt;&lt;br&gt;The locale to display audience names and descriptions. Defaults to the ad account&#039;s locale. |
## Validation &#123;#validation&#125;
Verify whether an audience is valid for targeting. Validation is helpful if you have already created an ad set and want to verify its targeting spec is still valid. If the targeting is not valid, remove it from the targeting spec.
```
curl -G \
-d &quot;targeting_list=[&#123;&#039;type&#039;:&#039;interests&#039;,&#039;id&#039;:6003283735711&#125;, &#123;&#039;type&#039;:&#039;relationship_statuses&#039;,&#039;id&#039;:100&#125;]&quot; \
-d &quot;access_token=&lt;ACCESS_TOKEN&gt;&quot; \
https://graph.facebook.com/&lt;API_VERSION&gt;/act_&lt;AD_ACCOUNT_ID&gt;/targetingvalidation
```
In addition to the standard Detailed Targeting response fields, this endpoint also returns:
| Name | Description |
| --- | --- |
| `valid`&lt;br&gt;&lt;br&gt;type: boolean | Whether the audience is valid. |
Here is the list of input parameters:
| Name | Description |
| --- | --- |
| `targeting_list`&lt;br&gt;&lt;br&gt;type: array of `&#123;&#039;type&#039;:&#039;&#123;TYPE&#125;&#039;, &#039;id&#039;:&#123;ID&#125;&#125;` | Array of `&#123;&#039;type&#039;:&#039;&#123;TYPE&#125;&#039;, &#039;id&#039;:&#123;ID&#125;&#125;` pairs for validation. Preferred. |
| `id_list`&lt;br&gt;&lt;br&gt;type: array of strings | Array of IDs for validation. Succeeds only if an ID is uniquely identifiable in the Meta audience database. |
| `name_list`&lt;br&gt;&lt;br&gt;type: array of strings | Array of strings for validation. Interests only. Case-insensitive. |
| `locale`&lt;br&gt;&lt;br&gt;type: string | Locale to display audience names and descriptions. Defaults to ad account&#039;s locale. |
Provide at least one of the following: `targeting_list`, `id_list`, or `name_list`.
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
