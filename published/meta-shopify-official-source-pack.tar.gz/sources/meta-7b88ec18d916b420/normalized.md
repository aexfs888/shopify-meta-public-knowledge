# &quot;Conversions API Gateway for Multiple Accounts Control Plane API: Pixel Management&quot;
**Warning:** ## This content has moved
This content has moved to the &quot;Gateway Products&quot; section of the site.
* Go to: [Conversions API Gateway and Signals Gateway Control Plane API Reference: Pixel Management](https://developers.facebook.com/documentation/ads-commerce/gateway-products/gateway-control-plane-api/pixel-management)
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
