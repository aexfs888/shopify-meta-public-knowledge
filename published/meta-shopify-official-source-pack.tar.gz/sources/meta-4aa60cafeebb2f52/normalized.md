# Ad Campaign Group
A campaign is the highest level organizational structure within an ad account and should represent a single objective for an advertiser, for example, to drive page post engagement. Setting objective of the campaign will enforce validation on any ads added to the campaign to ensure they also have the correct objective.
**Warning:** The `date_preset = lifetime` parameter is disabled in Graph API v10.0 and replaced with `date_preset = maximum`, which returns a maximum of 37 months of data. For v9.0 and below, `date_preset = maximum` will be enabled on May 25, 2021, and any `lifetime` calls will default to `maximum` and return only 37 months of data.
### Limits
- You can only create 200 ad sets per ad campaign. [Learn more about the ad campaign structure](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group).
- If your campaign has more than 70 ad sets and uses [Campaign Budget Optimization](https://developers.facebook.com/docs/marketing-api/bidding/guides/campaign-budget-optimization), you are not able to edit your current bid strategy or turn off CBO. [Learn more in the Business Help Center](https://www.facebook.com/business/help/519856662172206).
### New Required Field for All Campaigns
All businesses using the Marketing API must identify whether or not new and edited campaigns belong to a [Special Ad Category](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/special-ad-category). Current available categories are: [housing, employment, credit](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/special-ad-category#context), or issues, elections, and politics. Businesses whose ads do not belong to a Special Ad Category must indicate NONE or send an empty array in the `special_ad_categories` field.
Businesses running **housing**, **employment**, or **credit** ads must comply with [targeting and audience restrictions](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/targeting-restrictions). Targeting for ads about social issues, elections or politics are not affected by the `special_ad_categories` label.
**Warning:** As of **Marketing API 7.0**, the `special_ad_category` parameter on the [`POST /act_&lt;ad_account_id&gt;/campaigns`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account/campaigns#Creating) endpoint has been deprecated and replaced with a new `special_ad_categories` parameter. The new `special_ad_categories` parameter is required and accepts an array.
If you use the `special_ad_category` parameter, it will still return a string, but you should use `GET /&#123;campaign-id&#125;?fields=special_ad_categories` to get an array back. Refer to [Special Ad Category](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/special-ad-category) for additional information.
## Reading
A campaign is a grouping of ad sets which are organized by the same business objective. Each campaign has an objective that must be valid across the ad sets within that campaign.
After your ads begin delivering, you can query stats for ad campaigns. The statistics returned will be unique stats, deduped across the ad sets. You can also get reports and statistics for all ad sets and ads in an campaign simultaneously.
#### Example
### HTTP
```
GET v25.0/...?fields=&#123;fieldname_of_type_Campaign&#125; HTTP/1.1
Host: graph.facebook.com
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;get(
&#039;...?fields=&#123;fieldname_of_type_Campaign&#125;&#039;,
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;...?fields=&#123;fieldname_of_type_Campaign&#125;&quot;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;...?fields=&#123;fieldname_of_type_Campaign&#125;&quot;,
null,
HttpMethod.GET,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;...?fields=&#123;fieldname_of_type_Campaign&#125;&quot;
parameters:params
HTTPMethod:&#064;&quot;GET&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=GET&amp;path=...%3Ffields%3D%257Bfieldname_of_type_Campaign%257D&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
| Parameter | Description |
| --- | --- |
| `date_preset`&lt;br&gt;&lt;br&gt;*enum&#123;today, yesterday, this_month, last_month, this_quarter, maximum, data_maximum, last_3d, last_7d, last_14d, last_28d, last_30d, last_90d, last_week_mon_sun, last_week_sun_sat, last_quarter, last_year, this_week_mon_today, this_week_sun_today, this_year&#125;* | Date Preset&lt;br&gt; |
| `time_range`&lt;br&gt;&lt;br&gt;*&#123;&#039;since&#039;:YYYY-MM-DD,&#039;until&#039;:YYYY-MM-DD&#125;* | Time Range. Note if time range is invalid, it will be ignored.&lt;br&gt;&lt;br&gt;&lt;br&gt;`since` *datetime*&lt;br&gt;A date in the format of &quot;YYYY-MM-DD&quot;, which means from the beginning midnight of that day.&lt;br&gt;&lt;br&gt;&lt;br&gt;`until` *datetime*&lt;br&gt;A date in the format of &quot;YYYY-MM-DD&quot;, which means to the beginning midnight of the following day.&lt;br&gt; |
#### Fields
| Field | Description |
| --- | --- |
| `id`&lt;br&gt;&lt;br&gt;*numeric string* | Campaign&#039;s ID&lt;br&gt;&lt;br&gt;&lt;br&gt;**[default]**&lt;br&gt; |
| `account_id`&lt;br&gt;&lt;br&gt;*numeric string* | ID of the ad account that owns this campaign&lt;br&gt; |
| `adlabels`&lt;br&gt;&lt;br&gt;*[list&lt;AdLabel&gt;](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-label)* | Ad Labels associated with this campaign&lt;br&gt; |
| `bid_strategy` This field is only accessible in v3.0 or later.&lt;br&gt;&lt;br&gt;*enum &#123;LOWEST_COST_WITHOUT_CAP, LOWEST_COST_WITH_BID_CAP, COST_CAP, LOWEST_COST_WITH_MIN_ROAS&#125;* | Bid strategy for this campaign when you enable campaign budget optimization and&lt;br&gt;when you use `AUCTION` as your buying type:&lt;br&gt;&lt;br&gt;`LOWEST_COST_WITHOUT_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` without limiting your bid amount. This is the best strategy to select&lt;br&gt;if you care most about cost efficiency. However, note that it may be harder to get&lt;br&gt;stable average costs as you spend. Note: this strategy is also known as&lt;br&gt;*automatic bidding*.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Lowest cost](https://www.facebook.com/business/help/721453268045071).&lt;br&gt;&lt;br&gt;`LOWEST_COST_WITH_BID_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` while limiting actual bid to a specified amount.&lt;br&gt;Get specified bid cap in the `bid_amount` field for each ad set in this ad campaign.&lt;br&gt;This strategy is known as *manual maximum-cost bidding*.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Lowest cost](https://www.facebook.com/business/help/721453268045071).&lt;br&gt;&lt;br&gt;`COST_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` while limiting actual average cost per optimization event to a specified amount.&lt;br&gt;Get specified cost cap in the `bid_amount` field for each ad set in this ad campaign.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Cost Cap](https://www.facebook.com/business/help/272336376749096?id=2196356200683573).&lt;br&gt;Notes:&lt;br&gt;&lt;br&gt;&lt;br&gt;• If you do not enable campaign budget optimization, you should get `bid_strategy` at the ad set level.&lt;br&gt;• `TARGET_COST` bidding strategy has been deprecated with [Marketing API v9](https://developers.facebook.com/docs/graph-api/changelog/version9.0).&lt;br&gt; |
| `boosted_object_id`&lt;br&gt;&lt;br&gt;*numeric string* | The Boosted Object this campaign has associated, if any&lt;br&gt; |
| `brand_lift_studies`&lt;br&gt;&lt;br&gt;*[list&lt;AdStudy&gt;](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-study)* | Automated Brand Lift V2 studies for this ad set.&lt;br&gt; |
| `budget_rebalance_flag`&lt;br&gt;&lt;br&gt;*bool* | Whether to automatically rebalance budgets daily for all the adsets under this campaign. [This has been deprecated on Marketing API V7.0](https://developers.facebook.com/docs/graph-api/changelog/version7.0#deprecations).&lt;br&gt; |
| `budget_remaining`&lt;br&gt;&lt;br&gt;*numeric string* | Remaining budget&lt;br&gt; |
| `buying_type`&lt;br&gt;&lt;br&gt;*string* | Buying type, possible values are: &lt;br&gt;`AUCTION`: default&lt;br&gt;`RESERVED`: for [reach and frequency ads](https://developers.facebook.com/docs/marketing-api/reachandfrequency)&lt;br&gt;[Reach and Frequency](https://developers.facebook.com/docs/marketing-api/reachandfrequency) is disabled for [housing, employment and credit ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/special-ad-category).&lt;br&gt; |
| `campaign_group_active_time`&lt;br&gt;&lt;br&gt;*numeric string* | campaign_group_active_time this is only for Internal, This will have the active running length of Campaign Groups&lt;br&gt; |
| `can_create_brand_lift_study`&lt;br&gt;&lt;br&gt;*bool* | If we can create a new automated brand lift study for the ad set.&lt;br&gt; |
| `can_use_spend_cap`&lt;br&gt;&lt;br&gt;*bool* | Whether the campaign can set the spend cap&lt;br&gt; |
| `configured_status`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | If this status is `PAUSED`, all its active ad sets and ads will&lt;br&gt;be paused and have an effective status `CAMPAIGN_PAUSED`. Prefer&lt;br&gt;using &#039;status&#039; instead of this.&lt;br&gt; |
| `created_time`&lt;br&gt;&lt;br&gt;*datetime* | Created Time&lt;br&gt; |
| `daily_budget`&lt;br&gt;&lt;br&gt;*numeric string* | The daily budget of the campaign&lt;br&gt; |
| `effective_status`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, DELETED, ARCHIVED, IN_PROCESS, WITH_ISSUES&#125;* | IN_PROCESS is available for version 4.0 or higher&lt;br&gt; |
| `has_secondary_skadnetwork_reporting`&lt;br&gt;&lt;br&gt;*bool* | has_secondary_skadnetwork_reporting&lt;br&gt; |
| `is_adset_budget_sharing_enabled`&lt;br&gt;&lt;br&gt;*bool* | Whether the child ad sets are managed under ad set budget sharing&lt;br&gt; |
| `is_budget_schedule_enabled`&lt;br&gt;&lt;br&gt;*bool* | Whether budget scheduling is enabled for the campaign group&lt;br&gt; |
| `is_reels_trending_ads_enabled`&lt;br&gt;&lt;br&gt;*bool* | is_reels_trending_ads_enabled&lt;br&gt; |
| `is_skadnetwork_attribution`&lt;br&gt;&lt;br&gt;*bool* | When set to `true` Indicates that the campaign will include SKAdNetwork, iOS 14+.&lt;br&gt; |
| `issues_info` This field is only accessible in v3.2 or later.&lt;br&gt;&lt;br&gt;*[list&lt;AdCampaignIssuesInfo&gt;](https://developers.facebook.com/docs/marketing-api/reference/ad-campaign-issues-info)* | Issues for this campaign that prevented it from deliverying&lt;br&gt; |
| `last_budget_toggling_time`&lt;br&gt;&lt;br&gt;*datetime* | Last budget toggling time&lt;br&gt; |
| `lifetime_budget`&lt;br&gt;&lt;br&gt;*numeric string* | The lifetime budget of the campaign&lt;br&gt; |
| `name`&lt;br&gt;&lt;br&gt;*string* | Campaign&#039;s name&lt;br&gt; |
| `objective`&lt;br&gt;&lt;br&gt;*string* | Campaign&#039;s objective&lt;br&gt;&lt;br&gt;&lt;br&gt;See the [Outcome Ad-Driven Experience Objective Validation](#odax) section below for more information.&lt;br&gt; |
| `pacing_type`&lt;br&gt;&lt;br&gt;*list&lt;string&gt;* | Defines pacing type of the campaign. The value is an array of options: &quot;standard&quot;.&lt;br&gt; |
| `primary_attribution`&lt;br&gt;&lt;br&gt;*enum* | primary_attribution&lt;br&gt; |
| `promoted_object`&lt;br&gt;&lt;br&gt;*[AdPromotedObject](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-promoted-object)* | The object this campaign is promoting across all its ads&lt;br&gt; |
| `smart_promotion_type`&lt;br&gt;&lt;br&gt;*enum* | Smart Promotion Type. guided_creation or smart_app_promotion(the choice under APP_INSTALLS objective).&lt;br&gt; |
| `source_campaign`&lt;br&gt;&lt;br&gt;*[Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group)* | The source campaign that this campaign is copied from&lt;br&gt; |
| `source_campaign_id`&lt;br&gt;&lt;br&gt;*numeric string* | The source campaign id that this campaign is copied from&lt;br&gt; |
| `special_ad_categories` This field is only accessible in v7.0 or later.&lt;br&gt;&lt;br&gt;*list&lt;enum&gt;* | special ad categories&lt;br&gt; |
| `special_ad_category`&lt;br&gt;&lt;br&gt;*enum* | The campaign&#039;s Special Ad Category. One of `HOUSING`, `EMPLOYMENT`, `CREDIT`, or `NONE`.&lt;br&gt; |
| `special_ad_category_country` This field is only accessible in v7.0 or later.&lt;br&gt;&lt;br&gt;*list&lt;enum&gt;* | Country field for Special Ad Category.&lt;br&gt; |
| `spend_cap`&lt;br&gt;&lt;br&gt;*numeric string* | A spend cap for the campaign, such that it will not spend more than this cap. Expressed as integer value of the subunit in your currency.&lt;br&gt; |
| `start_time`&lt;br&gt;&lt;br&gt;*datetime* | Merging of `start_time`s for the ad sets belonging to this campaign. At the campaign level, `start_time` is a read only field. You can setup `start_time` at the ad set level.&lt;br&gt; |
| `status`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | If this status is `PAUSED`, all its active ad sets and ads will&lt;br&gt;be paused and have an effective status `CAMPAIGN_PAUSED`. The field&lt;br&gt;returns the same value as &#039;configured_status&#039;, and is the suggested&lt;br&gt;one to use.&lt;br&gt; |
| `stop_time`&lt;br&gt;&lt;br&gt;*datetime* | Merging of `stop_time`s for the ad sets belonging to this campaign, if available. At the campaign level, `stop_time` is a read only field. You can setup `stop_time` at the ad set level.&lt;br&gt; |
| `topline_id`&lt;br&gt;&lt;br&gt;*numeric string* | Topline ID&lt;br&gt; |
| `updated_time`&lt;br&gt;&lt;br&gt;*datetime* | Updated Time. If you update `spend_cap` or daily budget or lifetime budget, this will not automatically update this field.&lt;br&gt; |
#### Edges
| Edge | Description |
| --- | --- |
| [`ad_studies`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group/ad_studies)&lt;br&gt;&lt;br&gt;*Edge&lt;AdStudy&gt;* | The ad studies containing this campaign&lt;br&gt; |
| [`adrules_governed`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group/adrules_governed)&lt;br&gt;&lt;br&gt;*Edge&lt;AdRule&gt;* | Ad rules that govern this campaign - by default, this only returns rules that either directly mention the campaign by id or indirectly through the set entity_type&lt;br&gt; |
| [`ads`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group/ads)&lt;br&gt;&lt;br&gt;*Edge&lt;Adgroup&gt;* | Ads under this campaign&lt;br&gt; |
| [`adsets`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group/adsets)&lt;br&gt;&lt;br&gt;*Edge&lt;AdCampaign&gt;* | The ad sets under this campaign&lt;br&gt; |
| [`copies`](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group/copies)&lt;br&gt;&lt;br&gt;*Edge&lt;AdCampaignGroup&gt;* | The copies of this campaign&lt;br&gt; |
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 613 | Calls to this api have exceeded the rate limit. |
| 190 | Invalid OAuth 2.0 Access Token |
| 104 | Incorrect signature |
| 2500 | Error parsing graph query |
| 3018 | The start date of the time range cannot be beyond 37 months from the current date |
| 200 | Permissions error |
| 2635 | You are calling a deprecated version of the Ads API. Please update to the latest version. |
## Creating
### /act_&#123;ad_account_id&#125;/async_batch_requests
You can make a POST request to *async_batch_requests* edge from the following paths:
- [/act_&#123;ad_account_id&#125;/async_batch_requests](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account/async_batch_requests)
When posting to this edge, a [Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group) will be created.
#### Parameters
| Parameter | Description |
| --- | --- |
| `adbatch`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | JSON encoded batch reqeust&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`name` *string*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`relative_url` *string*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`body` *UTF-8 encoded string*&lt;br&gt;**[required]**&lt;br&gt; |
| `name`&lt;br&gt;&lt;br&gt;*UTF-8 encoded string* | Name of the batch request for tracking purposes.&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *id* in the return type.
```
Struct &#123;
id: numeric string,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 194 | Missing at least one required parameter |
| 100 | Invalid parameter |
| 2500 | Error parsing graph query |
### /&#123;campaign_id&#125;/copies
You can make a POST request to *copies* edge from the following paths:
- [/&#123;campaign_id&#125;/copies](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group/copies)
When posting to this edge, a [Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group) will be created.
#### Parameters
| Parameter | Description |
| --- | --- |
| `deep_copy`&lt;br&gt;&lt;br&gt;*boolean* | **Default value: **`false`&lt;br&gt;Whether to copy all the child ads. Limits: the total number of children ads to copy should not exceed 3 for a synchronous call and 51 for an asynchronous call.&lt;br&gt; |
| `end_time`&lt;br&gt;&lt;br&gt;*datetime* | For deep copy, the end time of the sets under the copied campaign, e.g. `2015-03-12 23:59:59-07:00` or `2015-03-12 23:59:59 PDT`. UTC UNIX timestamp. When creating a set with a daily budget, specify `end_time=0` to set the set to be ongoing without end date. If not set, the copied sets will inherit the end time from the original set&lt;br&gt; |
| `parameter_overrides`&lt;br&gt;&lt;br&gt;*Campaign spec* | parameter_overrides&lt;br&gt; |
| `rename_options`&lt;br&gt;&lt;br&gt;*JSON or object-like arrays* | Rename options&lt;br&gt;&lt;br&gt;&lt;br&gt;`rename_strategy` *enum &#123;DEEP_RENAME, ONLY_TOP_LEVEL_RENAME, NO_RENAME&#125;*&lt;br&gt;&lt;br&gt;**Default value: **`ONLY_TOP_LEVEL_RENAME`&lt;br&gt;`DEEP_RENAME`: will change this object&#039;s name and children&#039;s names in the copied object. `ONLY_TOP_LEVEL_RENAME`: will change the this object&#039;s name but won&#039;t change the children&#039;s name in the copied object. `NO_RENAME`: will change no name in the copied object&lt;br&gt;&lt;br&gt;&lt;br&gt;`rename_prefix` *string*&lt;br&gt;A prefix to copy names. Defaults to null if not provided.&lt;br&gt;&lt;br&gt;&lt;br&gt;`rename_suffix` *string*&lt;br&gt;A suffix to copy names. Defaults to null if not provided and appends a localized string of `- Copy` based on the ad account locale.&lt;br&gt; |
| `start_time`&lt;br&gt;&lt;br&gt;*datetime* | For deep copy, the start time of the sets under the copied campaign, e.g. `2015-03-12 23:59:59-07:00` or `2015-03-12 23:59:59 PDT`. UTC UNIX timestamp. If not set, the copied sets will inherit the start time from the original set&lt;br&gt; |
| `status_option`&lt;br&gt;&lt;br&gt;*enum &#123;ACTIVE, PAUSED, INHERITED_FROM_SOURCE&#125;* | **Default value: **`PAUSED`&lt;br&gt;`ACTIVE`: the copied campaign will have active status. `PAUSED`: the copied campaign will have paused status. `INHERITED_FROM_SOURCE`: the copied campaign will have the parent status.&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *copied_campaign_id* in the return type.
```
Struct &#123;
copied_campaign_id: numeric string,
ad_object_ids: List [ Struct &#123;
ad_object_type: enum &#123;
unique_adcreative,
ad,
ad_set,
campaign,
opportunities,
privacy_info_center,
topline,
ad_account,
product&#125;,
source_id: numeric string,
copied_id: numeric string,
&#125;],
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 190 | Invalid OAuth 2.0 Access Token |
| 200 | Permissions error |
### /act_&#123;ad_account_id&#125;/campaigns
You can make a POST request to *campaigns* edge from the following paths:
- [/act_&#123;ad_account_id&#125;/campaigns](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account/campaigns)
When posting to this edge, a [Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group) will be created.
#### Example
### HTTP
```
POST /v25.0/act_&lt;AD_ACCOUNT_ID&gt;/campaigns HTTP/1.1
Host: graph.facebook.com
name=My+campaign&amp;objective=OUTCOME_TRAFFIC&amp;status=PAUSED&amp;special_ad_categories=%5B%5D&amp;is_adset_budget_sharing_enabled=0
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;post(
&#039;/act_&lt;AD_ACCOUNT_ID&gt;/campaigns&#039;,
array (
&#039;name&#039; =&gt; &#039;My campaign&#039;,
&#039;objective&#039; =&gt; &#039;OUTCOME_TRAFFIC&#039;,
&#039;status&#039; =&gt; &#039;PAUSED&#039;,
&#039;special_ad_categories&#039; =&gt; &#039;[]&#039;,
&#039;is_adset_budget_sharing_enabled&#039; =&gt; &#039;0&#039;,
),
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;/act_&lt;AD_ACCOUNT_ID&gt;/campaigns&quot;,
&quot;POST&quot;,
&#123;
&quot;name&quot;: &quot;My campaign&quot;,
&quot;objective&quot;: &quot;OUTCOME_TRAFFIC&quot;,
&quot;status&quot;: &quot;PAUSED&quot;,
&quot;special_ad_categories&quot;: &quot;[]&quot;,
&quot;is_adset_budget_sharing_enabled&quot;: &quot;0&quot;
&#125;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
Bundle params = new Bundle();
params.putString(&quot;name&quot;, &quot;My campaign&quot;);
params.putString(&quot;objective&quot;, &quot;OUTCOME_TRAFFIC&quot;);
params.putString(&quot;status&quot;, &quot;PAUSED&quot;);
params.putString(&quot;special_ad_categories&quot;, &quot;[]&quot;);
params.putString(&quot;is_adset_budget_sharing_enabled&quot;, &quot;0&quot;);
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;/act_&lt;AD_ACCOUNT_ID&gt;/campaigns&quot;,
params,
HttpMethod.POST,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
NSDictionary *params = &#064;&#123;
&#064;&quot;name&quot;: &#064;&quot;My campaign&quot;,
&#064;&quot;objective&quot;: &#064;&quot;OUTCOME_TRAFFIC&quot;,
&#064;&quot;status&quot;: &#064;&quot;PAUSED&quot;,
&#064;&quot;special_ad_categories&quot;: &#064;&quot;[]&quot;,
&#064;&quot;is_adset_budget_sharing_enabled&quot;: &#064;&quot;0&quot;,
&#125;;
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;/act_&lt;AD_ACCOUNT_ID&gt;/campaigns&quot;
parameters:params
HTTPMethod:&#064;&quot;POST&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
### cURL
```
curl -X POST \
-F &#039;name=&quot;My campaign&quot;&#039; \
-F &#039;objective=&quot;OUTCOME_TRAFFIC&quot;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;special_ad_categories=[]&#039; \
-F &#039;is_adset_budget_sharing_enabled=0&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/campaigns
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=POST&amp;path=act_%3CAD_ACCOUNT_ID%3E%2Fcampaigns%3Fname%3DMy%2Bcampaign%26objective%3DOUTCOME_TRAFFIC%26status%3DPAUSED%26special_ad_categories%3D%255B%255D%26is_adset_budget_sharing_enabled%3D0&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
| Parameter | Description |
| --- | --- |
| `adlabels`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | [Ad Labels](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-label) associated with this campaign&lt;br&gt; |
| `bid_strategy` This field is only accessible in v3.0 or later.&lt;br&gt;&lt;br&gt;*enum&#123;LOWEST_COST_WITHOUT_CAP, LOWEST_COST_WITH_BID_CAP, COST_CAP, LOWEST_COST_WITH_MIN_ROAS&#125;* | Choose bid strategy for this campaign to suit your specific business goals.&lt;br&gt;Each strategy has tradeoffs and may be available for certain `optimization_goal`s:&lt;br&gt;&lt;br&gt;`LOWEST_COST_WITHOUT_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` without limiting your bid amount. This is the best strategy&lt;br&gt;if you care most about cost efficiency. However with this strategy it may be harder to get&lt;br&gt;stable average costs as you spend. This strategy is also known as *automatic bidding*.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Lowest cost](https://www.facebook.com/business/help/721453268045071).&lt;br&gt;&lt;br&gt;`LOWEST_COST_WITH_BID_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` while limiting actual bid to your specified&lt;br&gt;amount. With a bid cap you have more control over your&lt;br&gt;cost per actual optimization event. However if you set a limit which is too low you may&lt;br&gt;get less ads delivery. If you select this, you must provide&lt;br&gt;a bid cap in the `bid_amount` field for each ad set in this ad campaign.&lt;br&gt;Note: during creation this is the default bid strategy if you don&#039;t specify.&lt;br&gt;This strategy is also known as *manual maximum-cost bidding*.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Lowest cost](https://www.facebook.com/business/help/721453268045071).&lt;br&gt;&lt;br&gt;&lt;br&gt;**Notes:**&lt;br&gt;&lt;br&gt;&lt;br&gt;• If you do not enable campaign budget optimization, you should set `bid_strategy` at ad set level.&lt;br&gt;• `TARGET_COST` bidding strategy has been deprecated with [Marketing API v9](https://developers.facebook.com/docs/graph-api/changelog/version9.0).&lt;br&gt; |
| `budget_schedule_specs`&lt;br&gt;&lt;br&gt;*list&lt;JSON or object-like arrays&gt;* | Initial high demand periods to be created with the campaign.&lt;br&gt;&lt;br&gt;Provide list of `time_start`, `time_end`,`budget_value`, and `budget_value_type`.&lt;br&gt;For example,&lt;br&gt;-F &#039;budget_schedule_specs=[&#123;&lt;br&gt;&lt;br&gt;&quot;time_start&quot;:1699081200,&lt;br&gt;&lt;br&gt;&quot;time_end&quot;:1699167600,&lt;br&gt;&lt;br&gt;&quot;budget_value&quot;:100,&lt;br&gt;&lt;br&gt;&quot;budget_value_type&quot;:&quot;ABSOLUTE&quot;&lt;br&gt;&lt;br&gt;&#125;]&#039;&lt;br&gt;&lt;br&gt;See [High Demand Period](https://developers.facebook.com/docs/graph-api/reference/high-demand-period) for more details on each field.&lt;br&gt;&lt;br&gt;&lt;br&gt;`id` *int64*&lt;br&gt;&lt;br&gt;`time_start` *datetime*&lt;br&gt;&lt;br&gt;`time_end` *datetime*&lt;br&gt;&lt;br&gt;`budget_value` *int64*&lt;br&gt;&lt;br&gt;`budget_value_type` *enum&#123;ABSOLUTE, MULTIPLIER&#125;*&lt;br&gt;&lt;br&gt;`recurrence_type` *enum&#123;ONE_TIME, WEEKLY&#125;*&lt;br&gt;&lt;br&gt;`weekly_schedule` *list&lt;JSON or object-like arrays&gt;*&lt;br&gt;&lt;br&gt;`days` *list&lt;int64&gt;*&lt;br&gt;&lt;br&gt;`minute_start` *int64*&lt;br&gt;&lt;br&gt;`minute_end` *int64*&lt;br&gt;&lt;br&gt;`timezone_type` *string* |
| `buying_type`&lt;br&gt;&lt;br&gt;*string* | **Default value: **`AUCTION`&lt;br&gt;This field will help Facebook make optimizations to delivery, pricing, and limits. All ad sets in this campaign must match the buying type. Possible values are: &lt;br&gt;`AUCTION` (default)&lt;br&gt;`RESERVED` (for [reach and frequency ads](https://developers.facebook.com/docs/marketing-api/reachandfrequency)).&lt;br&gt; |
| `campaign_optimization_type`&lt;br&gt;&lt;br&gt;*enum&#123;NONE, ICO_ONLY&#125;* | campaign_optimization_type&lt;br&gt; |
| `daily_budget`&lt;br&gt;&lt;br&gt;*int64* | Daily budget of this campaign. All adsets under this&lt;br&gt;campaign will share this budget. You can either set budget at the&lt;br&gt;campaign level or at the adset level, not both.&lt;br&gt; |
| `execution_options`&lt;br&gt;&lt;br&gt;*list&lt;enum&#123;validate_only, include_recommendations&#125;&gt;* | **Default value: **`Set`&lt;br&gt;An execution setting&lt;br&gt; `validate_only`: when this option is specified, the API call will not perform the mutation but will run through the validation rules against values of each field. &lt;br&gt;`include_recommendations`: this option cannot be used by itself. When this option is used, recommendations for ad object&#039;s configuration will be included. A separate section [recommendations](https://developers.facebook.com/docs/marketing-api/reference/ad-recommendation) will be included in the response, but only if recommendations for this specification exist.&lt;br&gt;If the call passes validation or review, response will be `&#123;&quot;success&quot;: true&#125;`. If the call does not pass, an error will be returned with more details. These options can be used to improve any UI to display errors to the user much sooner, e.g. as soon as a new value is typed into any field corresponding to this ad object, rather than at the upload/save stage, or after review.&lt;br&gt; |
| `is_skadnetwork_attribution`&lt;br&gt;&lt;br&gt;*boolean* | To create an iOS 14 campaign, enable SKAdNetwork attribution for this campaign.&lt;br&gt; |
| `is_using_l3_schedule`&lt;br&gt;&lt;br&gt;*boolean* | is_using_l3_schedule&lt;br&gt; |
| `iterative_split_test_configs`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | Array of Iterative Split Test Configs created under this campaign .&lt;br&gt; |
| `lifetime_budget`&lt;br&gt;&lt;br&gt;*int64* | Lifetime budget of this campaign. All adsets under&lt;br&gt;this campaign will share this budget. You can either set budget at the&lt;br&gt;campaign level or at the adset level, not both.&lt;br&gt; |
| `name`&lt;br&gt;&lt;br&gt;*string* | Name for this campaign&lt;br&gt;&lt;br&gt;**[supports emoji]**&lt;br&gt; |
| `objective`&lt;br&gt;&lt;br&gt;*enum&#123;APP_INSTALLS, BRAND_AWARENESS, CONVERSIONS, EVENT_RESPONSES, LEAD_GENERATION, LINK_CLICKS, LOCAL_AWARENESS, MESSAGES, OFFER_CLAIMS, OUTCOME_APP_PROMOTION, OUTCOME_AWARENESS, OUTCOME_ENGAGEMENT, OUTCOME_LEADS, OUTCOME_SALES, OUTCOME_TRAFFIC, PAGE_LIKES, POST_ENGAGEMENT, PRODUCT_CATALOG_SALES, REACH, STORE_VISITS, VIDEO_VIEWS&#125;* | Campaign&#039;s objective. If it is specified the API will validate that any ads created under the campaign match that objective. &lt;br&gt;Currently, with `BRAND_AWARENESS` objective, all creatives should be either only images or only videos, not mixed.&lt;br&gt;&lt;br&gt;See [Outcome Ad-Driven Experience Objective Validation](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group#odax) for more information.&lt;br&gt; |
| `promoted_object`&lt;br&gt;&lt;br&gt;*Object* | The object this campaign is promoting across all its ads. It’s required for Meta iOS 14+ app promotion (SKAdNetwork or Aggregated Event Measurement) campaign creation. Only `product_catalog_id` is used at the ad set level.&lt;br&gt;&lt;br&gt;&lt;br&gt;`application_id` *int*&lt;br&gt;The ID of a Facebook Application. Usually related to mobile or canvas games being promoted on Facebook for installs or engagement&lt;br&gt;&lt;br&gt;&lt;br&gt;`pixel_id` *numeric string or integer*&lt;br&gt;The ID of a Facebook conversion pixel. Used with offsite conversion campaigns.&lt;br&gt;&lt;br&gt;&lt;br&gt;`custom_event_type` *enum&#123;AD_IMPRESSION, RATE, TUTORIAL_COMPLETION, CONTACT, CUSTOMIZE_PRODUCT, DONATE, FIND_LOCATION, SCHEDULE, START_TRIAL, SUBMIT_APPLICATION, SUBSCRIBE, ADD_TO_CART, ADD_TO_WISHLIST, INITIATED_CHECKOUT, ADD_PAYMENT_INFO, PURCHASE, LEAD, COMPLETE_REGISTRATION, CONTENT_VIEW, SEARCH, SERVICE_BOOKING_REQUEST, MESSAGING_CONVERSATION_STARTED_7D, LEVEL_ACHIEVED, ACHIEVEMENT_UNLOCKED, SPENT_CREDITS, LISTING_INTERACTION, D2_RETENTION, D7_RETENTION, OTHER&#125;*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`object_store_url` *URL*&lt;br&gt;The uri of the mobile / digital store where an application can be bought / downloaded. This is platform specific. When combined with the &quot;application_id&quot; this uniquely specifies an object which can be the subject of a Facebook advertising campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`object_store_urls` *list&lt;URL&gt;*&lt;br&gt;The vec of uri of the mobile / digital store where an application can be bought / downloaded. This is platform specific. When combined with the &quot;application_id&quot; this uniquely specifies an object which can be the subject of a Facebook advertising campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`offer_id` *numeric string or integer*&lt;br&gt;The ID of an Offer from a Facebook Page.&lt;br&gt;&lt;br&gt;&lt;br&gt;`page_id` *Page ID*&lt;br&gt;The ID of a Facebook Page&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_catalog_id` *numeric string or integer*&lt;br&gt;The ID of a Product Catalog. Used with&lt;br&gt;[Dynamic Product Ads](https://developers.facebook.com/docs/marketing-api/dynamic-product-ads).&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_item_id` *numeric string or integer*&lt;br&gt;The ID of the product item.&lt;br&gt;&lt;br&gt;&lt;br&gt;`job_listing_id` *numeric string or integer*&lt;br&gt;The ID of the marketplace job listing.&lt;br&gt;&lt;br&gt;&lt;br&gt;`instagram_profile_id` *numeric string or integer*&lt;br&gt;The ID of the instagram profile id.&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_set_id` *numeric string or integer*&lt;br&gt;The ID of a Product Set within an Ad Set level Product&lt;br&gt;Catalog. Used with&lt;br&gt;[Dynamic Product Ads](https://developers.facebook.com/docs/marketing-api/dynamic-product-ads).&lt;br&gt;&lt;br&gt;&lt;br&gt;`event_id` *numeric string or integer*&lt;br&gt;The ID of a Facebook Event&lt;br&gt;&lt;br&gt;&lt;br&gt;`offline_conversion_data_set_id` *numeric string or integer*&lt;br&gt;The ID of the offline dataset.&lt;br&gt;&lt;br&gt;&lt;br&gt;`fundraiser_campaign_id` *numeric string or integer*&lt;br&gt;The ID of the fundraiser campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`custom_event_str` *string*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`mcme_conversion_id` *numeric string or integer*&lt;br&gt;The ID of a MCME conversion.&lt;br&gt;&lt;br&gt;&lt;br&gt;`conversion_goal_id` *numeric string or integer*&lt;br&gt;The ID of a Conversion Goal.&lt;br&gt;&lt;br&gt;&lt;br&gt;`offsite_conversion_event_id` *numeric string or integer*&lt;br&gt;The ID of a Offsite Conversion Event&lt;br&gt;&lt;br&gt;&lt;br&gt;`boosted_product_set_id` *numeric string or integer*&lt;br&gt;The ID of the Boosted Product Set within an Ad Set level Product&lt;br&gt;Catalog. Should only be present when the advertiser has&lt;br&gt;opted into Product Set Boosting.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_form_event_source_type` *enum&#123;inferred, meta_source, offsite_crm, offsite_web, onsite_crm, onsite_crm_single_event, onsite_clo_dep_aet, onsite_web, onsite_p2b_call, onsite_messaging, qualified_lead_file&#125;*&lt;br&gt;The event source of lead ads form.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_custom_event_type` *enum&#123;AD_IMPRESSION, RATE, TUTORIAL_COMPLETION, CONTACT, CUSTOMIZE_PRODUCT, DONATE, FIND_LOCATION, SCHEDULE, START_TRIAL, SUBMIT_APPLICATION, SUBSCRIBE, ADD_TO_CART, ADD_TO_WISHLIST, INITIATED_CHECKOUT, ADD_PAYMENT_INFO, PURCHASE, LEAD, COMPLETE_REGISTRATION, CONTENT_VIEW, SEARCH, SERVICE_BOOKING_REQUEST, MESSAGING_CONVERSATION_STARTED_7D, LEVEL_ACHIEVED, ACHIEVEMENT_UNLOCKED, SPENT_CREDITS, LISTING_INTERACTION, D2_RETENTION, D7_RETENTION, OTHER&#125;*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_custom_event_str` *string*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_offsite_conversion_type` *enum&#123;default, clo&#125;*&lt;br&gt;The offsite conversion type for lead ads&lt;br&gt;&lt;br&gt;&lt;br&gt;`value_semantic_type` *enum &#123;VALUE, MARGIN, LIFETIME_VALUE&#125;*&lt;br&gt;The semantic of the event value to be using for optimization&lt;br&gt;&lt;br&gt;&lt;br&gt;`variation` *enum &#123;OMNI_CHANNEL_SHOP_AUTOMATIC_DATA_COLLECTION, PRODUCT_SET_AND_APP, PRODUCT_SET_AND_IN_STORE, PRODUCT_SET_AND_OMNICHANNEL, PRODUCT_SET_AND_PHONE_CALL, PRODUCT_SET_AND_WEBSITE, PRODUCT_SET_AND_WEBSITE_AND_PHONE_CALL, PRODUCT_SET_WEBSITE_APP_AND_INSTORE&#125;*&lt;br&gt;Variation of the promoted object for a PCA ad&lt;br&gt;&lt;br&gt;&lt;br&gt;`passback_pixel_id` *numeric string or integer*&lt;br&gt;ID of the pixel used for tracking passback events&lt;br&gt;&lt;br&gt;&lt;br&gt;`passback_application_id` *numeric string or integer*&lt;br&gt;ID of the application used for tracking passback events&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_set_optimization` *enum&#123;enabled, disabled&#125;*&lt;br&gt;Enum defining whether or not the ad should be optimized for the promoted product set&lt;br&gt;&lt;br&gt;&lt;br&gt;`full_funnel_objective` *enum&#123;OFFER_CLAIMS, PAGE_LIKES, EVENT_RESPONSES, POST_ENGAGEMENT, WEBSITE_CONVERSIONS, LINK_CLICKS, VIDEO_VIEWS, LOCAL_AWARENESS, PRODUCT_CATALOG_SALES, LEAD_GENERATION, BRAND_AWARENESS, STORE_VISITS, REACH, APP_INSTALLS, MESSAGES, OUTCOME_AWARENESS, OUTCOME_ENGAGEMENT, OUTCOME_LEADS, OUTCOME_SALES, OUTCOME_TRAFFIC, OUTCOME_APP_PROMOTION&#125;*&lt;br&gt;Enum defining the full funnel objective of the campaign&lt;br&gt;&lt;br&gt;&lt;br&gt;`dataset_split_id` *numeric string or integer*&lt;br&gt;ID of the dataset split used to perform additional optimization on the dataset&lt;br&gt;&lt;br&gt;&lt;br&gt;`dataset_split_ids` *array&lt;numeric string&gt;*&lt;br&gt;IDs of the dataset splits used to perform additional optimization on the dataset&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_selected_pixel_id` *numeric string or integer*&lt;br&gt;The selected pixel id for lead ads conversion leads optimization&lt;br&gt;&lt;br&gt;&lt;br&gt;`custom_attribution_source_ids` *array&lt;numeric string&gt;*&lt;br&gt;IDs of the custom attribution sources used for tracking passback events&lt;br&gt;&lt;br&gt;&lt;br&gt;`multi_event_product` *int64*&lt;br&gt;Identifies which action-to-action product the advertiser is using&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_sales_channel` *enum &#123;ONLINE, IN_STORE, OMNI&#125;*&lt;br&gt;ProductSalesChannel of the promoted object for Omni L3 DA SBLI ads&lt;br&gt;&lt;br&gt;&lt;br&gt;`anchor_event_config` *JSON object*&lt;br&gt;Configuration for anchor event in multi-event optimization campaigns&lt;br&gt;&lt;br&gt;&lt;br&gt;`multi_event_conversion_info` *JSON object*&lt;br&gt;Configuration for multi-event conversion info in CLO campaigns&lt;br&gt;&lt;br&gt;&lt;br&gt;`live_video_destination` *string*&lt;br&gt;The live video destination type for live video ads&lt;br&gt;&lt;br&gt;&lt;br&gt;`smart_pse_enabled` *boolean*&lt;br&gt;Whether Smart Product Set Expansion is enabled for this campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`smart_pse_setting` *enum&#123;ENABLED, DISABLED&#125;*&lt;br&gt;Setting for Smart Product Set Expansion. Uses an enum instead of a boolean to avoid TAO null handling issues.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_follow_up_event` *enum&#123;whatsapp_conversations&#125;*&lt;br&gt;The selected lead follow-up event for lead ads campaigns.&lt;br&gt;&lt;br&gt;&lt;br&gt;`omnichannel_object` *Object*&lt;br&gt;&lt;br&gt;`app` *array&lt;JSON object&gt;*&lt;br&gt;&lt;br&gt;`pixel` *array&lt;JSON object&gt;*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`onsite` *array&lt;JSON object&gt;*&lt;br&gt;&lt;br&gt;`whats_app_business_phone_number_id` *numeric string or integer*&lt;br&gt;&lt;br&gt;`whatsapp_phone_number` *string* |
| `source_campaign_id`&lt;br&gt;&lt;br&gt;*numeric string or integer* | Used if a campaign has been copied. The ID from the original campaign that was copied.&lt;br&gt; |
| `special_ad_categories` This field is only accessible in v7.0 or later.&lt;br&gt;&lt;br&gt;*array&lt;enum &#123;NONE, EMPLOYMENT, HOUSING, CREDIT, ISSUES_ELECTIONS_POLITICS, ONLINE_GAMBLING_AND_GAMING, FINANCIAL_PRODUCTS_SERVICES&#125;&gt;* | special_ad_categories&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `special_ad_category_country` This field is only accessible in v7.0 or later.&lt;br&gt;&lt;br&gt;*array&lt;enum &#123;AC, AD, AE, AF, AG, AI, AL, AM, AN, AO, AQ, AR, AS, AT, AU, AW, AX, AZ, BA, BB, BD, BE, BF, BG, BH, BI, BJ, BL, BM, BN, BO, BQ, BR, BS, BT, BV, BW, BY, BZ, CA, CC, CD, CF, CG, CH, CI, CK, CL, CM, CN, CO, CR, CU, CV, CW, CX, CY, CZ, DE, DJ, DK, DM, DO, DZ, EC, EE, EG, EH, ER, ES, ET, FI, FJ, FK, FM, FO, FR, GA, GB, GD, GE, GF, GG, GH, GI, GL, GM, GN, GP, GQ, GR, GS, GT, GU, GW, GY, HK, HM, HN, HR, HT, HU, ID, IE, IL, IM, IN, IO, IQ, IR, IS, IT, JE, JM, JO, JP, KE, KG, KH, KI, KM, KN, KP, KR, KW, KY, KZ, LA, LB, LC, LI, LK, LR, LS, LT, LU, LV, LY, MA, MC, MD, ME, MF, MG, MH, MK, ML, MM, MN, MO, MP, MQ, MR, MS, MT, MU, MV, MW, MX, MY, MZ, NA, NC, NE, NF, NG, NI, NL, NO, NP, NR, NU, NZ, OM, PA, PE, PF, PG, PH, PK, PL, PM, PN, PR, PS, PT, PW, PY, QA, RE, RO, RS, RU, RW, SA, SB, SC, SD, SE, SG, SH, SI, SJ, SK, SL, SM, SN, SO, SR, SS, ST, SV, SX, SY, SZ, TC, TD, TF, TG, TH, TJ, TK, TL, TM, TN, TO, TR, TT, TV, TW, TZ, UA, UG, UM, US, UY, UZ, VA, VC, VE, VG, VI, VN, VU, WF, WS, XK, YE, YT, ZA, ZM, ZW&#125;&gt;* | special_ad_category_country&lt;br&gt; |
| `spend_cap`&lt;br&gt;&lt;br&gt;*int64* | A spend cap for the campaign, such that it will not spend more than this cap. Defined as integer value of subunit in your currency with a minimum value of $100 USD (or approximate local equivalent). Set the value to 922337203685478 to remove the spend cap. Not available for Reach and Frequency or Premium Self Serve campaigns&lt;br&gt; |
| `start_time`&lt;br&gt;&lt;br&gt;*datetime* | start_time&lt;br&gt; |
| `status`&lt;br&gt;&lt;br&gt;*enum&#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | Only `ACTIVE` and `PAUSED` are valid during&lt;br&gt;creation. Other statuses can be used for update. If it is set to&lt;br&gt;`PAUSED`, its active child objects will be paused and have an effective&lt;br&gt;status `CAMPAIGN_PAUSED`.&lt;br&gt; |
| `stop_time`&lt;br&gt;&lt;br&gt;*datetime* | stop_time&lt;br&gt; |
| `topline_id`&lt;br&gt;&lt;br&gt;*numeric string or integer* | Topline ID&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *id* in the return type.
```
Struct &#123;
id: numeric string,
success: bool,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 613 | Calls to this api have exceeded the rate limit. |
| 200 | Permissions error |
| 2635 | You are calling a deprecated version of the Ads API. Please update to the latest version. |
| 190 | Invalid OAuth 2.0 Access Token |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 300 | Edit failure |
## Updating
### /&#123;campaign_id&#125;
You can update a [Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group) by making a POST request to [/&#123;campaign_id&#125;](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group).
#### Parameters
| Parameter | Description |
| --- | --- |
| `adlabels`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | [Ad Labels](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-label) associated with this campaign&lt;br&gt; |
| `adset_bid_amounts`&lt;br&gt;&lt;br&gt;*JSON object &#123;numeric string : int64&#125;* | A map of child adset IDs to their respective bid amounts required in the process of toggling campaign from autobid to manual bid&lt;br&gt; |
| `adset_budgets`&lt;br&gt;&lt;br&gt;*array&lt;JSON object&gt;* | An array of maps containing all the non-deleted child adset IDs and either daily_budget or lifetime_budget, required in the process of toggling between campaign budget and adset budget&lt;br&gt;&lt;br&gt;&lt;br&gt;`adset_id` *numeric string*&lt;br&gt;adset_id&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`daily_budget` *int64*&lt;br&gt;daily_budget&lt;br&gt;&lt;br&gt;&lt;br&gt;`lifetime_budget` *int64*&lt;br&gt;lifetime_budget&lt;br&gt; |
| `bid_strategy` This field is only accessible in v3.0 or later.&lt;br&gt;&lt;br&gt;*enum&#123;LOWEST_COST_WITHOUT_CAP, LOWEST_COST_WITH_BID_CAP, COST_CAP, LOWEST_COST_WITH_MIN_ROAS&#125;* | Choose bid strategy for this campaign to suit your specific business goals.&lt;br&gt;Each strategy has tradeoffs and may be available for certain `optimization_goal`s:&lt;br&gt;&lt;br&gt;`LOWEST_COST_WITHOUT_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` without limiting your bid amount. This is the best strategy&lt;br&gt;if you care most about cost efficiency. However with this strategy it may be harder to get&lt;br&gt;stable average costs as you spend. This strategy is also known as *automatic bidding*.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Lowest cost](https://www.facebook.com/business/help/721453268045071).&lt;br&gt;&lt;br&gt;`LOWEST_COST_WITH_BID_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` while limiting actual bid to your specified&lt;br&gt;amount. With a bid cap you have more control over your&lt;br&gt;cost per actual optimization event. However if you set a limit which is too low you may&lt;br&gt;get less ads delivery. If you select this, you must provide&lt;br&gt;a bid cap in the `bid_amount` field for each ad set in this ad campaign.&lt;br&gt;Note: during creation this is the default bid strategy if you don&#039;t specify.&lt;br&gt;This strategy is also known as *manual maximum-cost bidding*.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Lowest cost](https://www.facebook.com/business/help/721453268045071).&lt;br&gt;&lt;br&gt;`COST_CAP`: Designed to get the most results for your budget based on&lt;br&gt;your ad set `optimization_goal` while limiting actual average cost per optimization event to a specified amount.&lt;br&gt;Get specified cost cap in the `bid_amount` field for each ad set in this ad campaign.&lt;br&gt;Learn more in [Ads Help Center, About bid strategies: Cost Cap](https://www.facebook.com/business/help/272336376749096?id=2196356200683573).&lt;br&gt;&lt;br&gt;&lt;br&gt;Notes:&lt;br&gt;&lt;br&gt;&lt;br&gt;• If you do not enable campaign budget optimization, you should set `bid_strategy` at ad set level.&lt;br&gt;• `TARGET_COST` bidding strategy has been deprecated with [Marketing API v9](https://developers.facebook.com/docs/graph-api/changelog/version9.0).&lt;br&gt; |
| `budget_rebalance_flag`&lt;br&gt;&lt;br&gt;*boolean* | Whether to automatically rebalance budgets daily for all the adsets under this campaign.&lt;br&gt; |
| `campaign_optimization_type`&lt;br&gt;&lt;br&gt;*enum&#123;NONE, ICO_ONLY&#125;* | campaign_optimization_type&lt;br&gt; |
| `daily_budget`&lt;br&gt;&lt;br&gt;*int64* | Daily budget of this campaign. All adsets under this&lt;br&gt;campaign will share this budget. You can either set budget at the&lt;br&gt;campaign level or at the adset level, not both.&lt;br&gt; |
| `execution_options`&lt;br&gt;&lt;br&gt;*list&lt;enum&#123;validate_only, include_recommendations&#125;&gt;* | **Default value: **`Set`&lt;br&gt;An execution setting&lt;br&gt; `validate_only`: when this option is specified, the API call will not perform the mutation but will run through the validation rules against values of each field. &lt;br&gt;`include_recommendations`: this option cannot be used by itself. When this option is used, recommendations for ad object&#039;s configuration will be included. A separate section [recommendations](https://developers.facebook.com/docs/marketing-api/reference/ad-recommendation) will be included in the response, but only if recommendations for this specification exist.&lt;br&gt;If the call passes validation or review, response will be `&#123;&quot;success&quot;: true&#125;`. If the call does not pass, an error will be returned with more details. These options can be used to improve any UI to display errors to the user much sooner, e.g. as soon as a new value is typed into any field corresponding to this ad object, rather than at the upload/save stage, or after review.&lt;br&gt; |
| `is_adset_budget_sharing_enabled`&lt;br&gt;&lt;br&gt;*boolean* | Whether the child ad sets are managed under ad set budget sharing. With ad set budget sharing, advertisers can now share up to 20% of their budget with other ad sets in the same campaign.&lt;br&gt; |
| `is_reels_trending_ads_enabled`&lt;br&gt;&lt;br&gt;*boolean* | indicator for &#039;reels trending ads&#039; campaign&lt;br&gt; |
| `is_skadnetwork_attribution`&lt;br&gt;&lt;br&gt;*boolean* | Flag to indicate that the campaign will be using SKAdNetwork, which also means that it will only be targeting iOS 14.x and above&lt;br&gt; |
| `is_using_l3_schedule`&lt;br&gt;&lt;br&gt;*boolean* | is_using_l3_schedule&lt;br&gt; |
| `iterative_split_test_configs`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | Array of Iterative Split Test Configs created under this campaign .&lt;br&gt; |
| `lifetime_budget`&lt;br&gt;&lt;br&gt;*int64* | Lifetime budget of this campaign. All adsets under&lt;br&gt;this campaign will share this budget. You can either set budget at the&lt;br&gt;campaign level or at the adset level, not both.&lt;br&gt; |
| `name`&lt;br&gt;&lt;br&gt;*string* | Name for this campaign&lt;br&gt;&lt;br&gt;**[supports emoji]**&lt;br&gt; |
| `objective`&lt;br&gt;&lt;br&gt;*enum&#123;APP_INSTALLS, BRAND_AWARENESS, CONVERSIONS, EVENT_RESPONSES, LEAD_GENERATION, LINK_CLICKS, LOCAL_AWARENESS, MESSAGES, OFFER_CLAIMS, OUTCOME_APP_PROMOTION, OUTCOME_AWARENESS, OUTCOME_ENGAGEMENT, OUTCOME_LEADS, OUTCOME_SALES, OUTCOME_TRAFFIC, PAGE_LIKES, POST_ENGAGEMENT, PRODUCT_CATALOG_SALES, REACH, STORE_VISITS, VIDEO_VIEWS&#125;* | Campaign&#039;s objective. If it is specified the API will validate that any ads created under the campaign match that objective. &lt;br&gt;Currently, with `BRAND_AWARENESS` objective, all creatives should be either only images or only videos, not mixed.&lt;br&gt;&lt;br&gt;&lt;br&gt;See the [Outcome Ad-Driven Experience Objective Validation](#odax) section below for more information.&lt;br&gt; |
| `promoted_object`&lt;br&gt;&lt;br&gt;*Object* | The object this campaign is promoting across all its ads. Only `product_catalog_id` is used at the ad set level.&lt;br&gt;&lt;br&gt;&lt;br&gt;`application_id` *int*&lt;br&gt;The ID of a Facebook Application. Usually related to mobile or canvas games being promoted on Facebook for installs or engagement&lt;br&gt;&lt;br&gt;&lt;br&gt;`pixel_id` *numeric string or integer*&lt;br&gt;The ID of a Facebook conversion pixel. Used with offsite conversion campaigns.&lt;br&gt;&lt;br&gt;&lt;br&gt;`custom_event_type` *enum&#123;AD_IMPRESSION, RATE, TUTORIAL_COMPLETION, CONTACT, CUSTOMIZE_PRODUCT, DONATE, FIND_LOCATION, SCHEDULE, START_TRIAL, SUBMIT_APPLICATION, SUBSCRIBE, ADD_TO_CART, ADD_TO_WISHLIST, INITIATED_CHECKOUT, ADD_PAYMENT_INFO, PURCHASE, LEAD, COMPLETE_REGISTRATION, CONTENT_VIEW, SEARCH, SERVICE_BOOKING_REQUEST, MESSAGING_CONVERSATION_STARTED_7D, LEVEL_ACHIEVED, ACHIEVEMENT_UNLOCKED, SPENT_CREDITS, LISTING_INTERACTION, D2_RETENTION, D7_RETENTION, OTHER&#125;*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`object_store_url` *URL*&lt;br&gt;The uri of the mobile / digital store where an application can be bought / downloaded. This is platform specific. When combined with the &quot;application_id&quot; this uniquely specifies an object which can be the subject of a Facebook advertising campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`object_store_urls` *list&lt;URL&gt;*&lt;br&gt;The vec of uri of the mobile / digital store where an application can be bought / downloaded. This is platform specific. When combined with the &quot;application_id&quot; this uniquely specifies an object which can be the subject of a Facebook advertising campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`offer_id` *numeric string or integer*&lt;br&gt;The ID of an Offer from a Facebook Page.&lt;br&gt;&lt;br&gt;&lt;br&gt;`page_id` *Page ID*&lt;br&gt;The ID of a Facebook Page&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_catalog_id` *numeric string or integer*&lt;br&gt;The ID of a Product Catalog. Used with&lt;br&gt;[Dynamic Product Ads](https://developers.facebook.com/docs/marketing-api/dynamic-product-ads).&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_item_id` *numeric string or integer*&lt;br&gt;The ID of the product item.&lt;br&gt;&lt;br&gt;&lt;br&gt;`job_listing_id` *numeric string or integer*&lt;br&gt;The ID of the marketplace job listing.&lt;br&gt;&lt;br&gt;&lt;br&gt;`instagram_profile_id` *numeric string or integer*&lt;br&gt;The ID of the instagram profile id.&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_set_id` *numeric string or integer*&lt;br&gt;The ID of a Product Set within an Ad Set level Product&lt;br&gt;Catalog. Used with&lt;br&gt;[Dynamic Product Ads](https://developers.facebook.com/docs/marketing-api/dynamic-product-ads).&lt;br&gt;&lt;br&gt;&lt;br&gt;`event_id` *numeric string or integer*&lt;br&gt;The ID of a Facebook Event&lt;br&gt;&lt;br&gt;&lt;br&gt;`offline_conversion_data_set_id` *numeric string or integer*&lt;br&gt;The ID of the offline dataset.&lt;br&gt;&lt;br&gt;&lt;br&gt;`fundraiser_campaign_id` *numeric string or integer*&lt;br&gt;The ID of the fundraiser campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`custom_event_str` *string*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`mcme_conversion_id` *numeric string or integer*&lt;br&gt;The ID of a MCME conversion.&lt;br&gt;&lt;br&gt;&lt;br&gt;`conversion_goal_id` *numeric string or integer*&lt;br&gt;The ID of a Conversion Goal.&lt;br&gt;&lt;br&gt;&lt;br&gt;`offsite_conversion_event_id` *numeric string or integer*&lt;br&gt;The ID of a Offsite Conversion Event&lt;br&gt;&lt;br&gt;&lt;br&gt;`boosted_product_set_id` *numeric string or integer*&lt;br&gt;The ID of the Boosted Product Set within an Ad Set level Product&lt;br&gt;Catalog. Should only be present when the advertiser has&lt;br&gt;opted into Product Set Boosting.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_form_event_source_type` *enum&#123;inferred, meta_source, offsite_crm, offsite_web, onsite_crm, onsite_crm_single_event, onsite_clo_dep_aet, onsite_web, onsite_p2b_call, onsite_messaging, qualified_lead_file&#125;*&lt;br&gt;The event source of lead ads form.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_custom_event_type` *enum&#123;AD_IMPRESSION, RATE, TUTORIAL_COMPLETION, CONTACT, CUSTOMIZE_PRODUCT, DONATE, FIND_LOCATION, SCHEDULE, START_TRIAL, SUBMIT_APPLICATION, SUBSCRIBE, ADD_TO_CART, ADD_TO_WISHLIST, INITIATED_CHECKOUT, ADD_PAYMENT_INFO, PURCHASE, LEAD, COMPLETE_REGISTRATION, CONTENT_VIEW, SEARCH, SERVICE_BOOKING_REQUEST, MESSAGING_CONVERSATION_STARTED_7D, LEVEL_ACHIEVED, ACHIEVEMENT_UNLOCKED, SPENT_CREDITS, LISTING_INTERACTION, D2_RETENTION, D7_RETENTION, OTHER&#125;*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_custom_event_str` *string*&lt;br&gt;The event from an App Event of a mobile app,&lt;br&gt;not in the standard event list.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_offsite_conversion_type` *enum&#123;default, clo&#125;*&lt;br&gt;The offsite conversion type for lead ads&lt;br&gt;&lt;br&gt;&lt;br&gt;`value_semantic_type` *enum &#123;VALUE, MARGIN, LIFETIME_VALUE&#125;*&lt;br&gt;The semantic of the event value to be using for optimization&lt;br&gt;&lt;br&gt;&lt;br&gt;`variation` *enum &#123;OMNI_CHANNEL_SHOP_AUTOMATIC_DATA_COLLECTION, PRODUCT_SET_AND_APP, PRODUCT_SET_AND_IN_STORE, PRODUCT_SET_AND_OMNICHANNEL, PRODUCT_SET_AND_PHONE_CALL, PRODUCT_SET_AND_WEBSITE, PRODUCT_SET_AND_WEBSITE_AND_PHONE_CALL, PRODUCT_SET_WEBSITE_APP_AND_INSTORE&#125;*&lt;br&gt;Variation of the promoted object for a PCA ad&lt;br&gt;&lt;br&gt;&lt;br&gt;`passback_pixel_id` *numeric string or integer*&lt;br&gt;ID of the pixel used for tracking passback events&lt;br&gt;&lt;br&gt;&lt;br&gt;`passback_application_id` *numeric string or integer*&lt;br&gt;ID of the application used for tracking passback events&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_set_optimization` *enum&#123;enabled, disabled&#125;*&lt;br&gt;Enum defining whether or not the ad should be optimized for the promoted product set&lt;br&gt;&lt;br&gt;&lt;br&gt;`full_funnel_objective` *enum&#123;OFFER_CLAIMS, PAGE_LIKES, EVENT_RESPONSES, POST_ENGAGEMENT, WEBSITE_CONVERSIONS, LINK_CLICKS, VIDEO_VIEWS, LOCAL_AWARENESS, PRODUCT_CATALOG_SALES, LEAD_GENERATION, BRAND_AWARENESS, STORE_VISITS, REACH, APP_INSTALLS, MESSAGES, OUTCOME_AWARENESS, OUTCOME_ENGAGEMENT, OUTCOME_LEADS, OUTCOME_SALES, OUTCOME_TRAFFIC, OUTCOME_APP_PROMOTION&#125;*&lt;br&gt;Enum defining the full funnel objective of the campaign&lt;br&gt;&lt;br&gt;&lt;br&gt;`dataset_split_id` *numeric string or integer*&lt;br&gt;ID of the dataset split used to perform additional optimization on the dataset&lt;br&gt;&lt;br&gt;&lt;br&gt;`dataset_split_ids` *array&lt;numeric string&gt;*&lt;br&gt;IDs of the dataset splits used to perform additional optimization on the dataset&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_selected_pixel_id` *numeric string or integer*&lt;br&gt;The selected pixel id for lead ads conversion leads optimization&lt;br&gt;&lt;br&gt;&lt;br&gt;`custom_attribution_source_ids` *array&lt;numeric string&gt;*&lt;br&gt;IDs of the custom attribution sources used for tracking passback events&lt;br&gt;&lt;br&gt;&lt;br&gt;`multi_event_product` *int64*&lt;br&gt;Identifies which action-to-action product the advertiser is using&lt;br&gt;&lt;br&gt;&lt;br&gt;`product_sales_channel` *enum &#123;ONLINE, IN_STORE, OMNI&#125;*&lt;br&gt;ProductSalesChannel of the promoted object for Omni L3 DA SBLI ads&lt;br&gt;&lt;br&gt;&lt;br&gt;`anchor_event_config` *JSON object*&lt;br&gt;Configuration for anchor event in multi-event optimization campaigns&lt;br&gt;&lt;br&gt;&lt;br&gt;`multi_event_conversion_info` *JSON object*&lt;br&gt;Configuration for multi-event conversion info in CLO campaigns&lt;br&gt;&lt;br&gt;&lt;br&gt;`live_video_destination` *string*&lt;br&gt;The live video destination type for live video ads&lt;br&gt;&lt;br&gt;&lt;br&gt;`smart_pse_enabled` *boolean*&lt;br&gt;Whether Smart Product Set Expansion is enabled for this campaign.&lt;br&gt;&lt;br&gt;&lt;br&gt;`smart_pse_setting` *enum&#123;ENABLED, DISABLED&#125;*&lt;br&gt;Setting for Smart Product Set Expansion. Uses an enum instead of a boolean to avoid TAO null handling issues.&lt;br&gt;&lt;br&gt;&lt;br&gt;`lead_ads_follow_up_event` *enum&#123;whatsapp_conversations&#125;*&lt;br&gt;The selected lead follow-up event for lead ads campaigns.&lt;br&gt;&lt;br&gt;&lt;br&gt;`omnichannel_object` *Object*&lt;br&gt;&lt;br&gt;`app` *array&lt;JSON object&gt;*&lt;br&gt;&lt;br&gt;`pixel` *array&lt;JSON object&gt;*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`onsite` *array&lt;JSON object&gt;*&lt;br&gt;&lt;br&gt;`whats_app_business_phone_number_id` *numeric string or integer*&lt;br&gt;&lt;br&gt;`whatsapp_phone_number` *string* |
| `smart_promotion_type`&lt;br&gt;&lt;br&gt;*enum&#123;GUIDED_CREATION, SMART_APP_PROMOTION&#125;* | smart_promotion_type&lt;br&gt; |
| `special_ad_category`&lt;br&gt;&lt;br&gt;*enum&#123;NONE, EMPLOYMENT, HOUSING, CREDIT, ISSUES_ELECTIONS_POLITICS, ONLINE_GAMBLING_AND_GAMING, FINANCIAL_PRODUCTS_SERVICES&#125;* | special_ad_category&lt;br&gt; |
| `special_ad_category_country` This field is only accessible in v7.0 or later.&lt;br&gt;&lt;br&gt;*array&lt;enum &#123;AC, AD, AE, AF, AG, AI, AL, AM, AN, AO, AQ, AR, AS, AT, AU, AW, AX, AZ, BA, BB, BD, BE, BF, BG, BH, BI, BJ, BL, BM, BN, BO, BQ, BR, BS, BT, BV, BW, BY, BZ, CA, CC, CD, CF, CG, CH, CI, CK, CL, CM, CN, CO, CR, CU, CV, CW, CX, CY, CZ, DE, DJ, DK, DM, DO, DZ, EC, EE, EG, EH, ER, ES, ET, FI, FJ, FK, FM, FO, FR, GA, GB, GD, GE, GF, GG, GH, GI, GL, GM, GN, GP, GQ, GR, GS, GT, GU, GW, GY, HK, HM, HN, HR, HT, HU, ID, IE, IL, IM, IN, IO, IQ, IR, IS, IT, JE, JM, JO, JP, KE, KG, KH, KI, KM, KN, KP, KR, KW, KY, KZ, LA, LB, LC, LI, LK, LR, LS, LT, LU, LV, LY, MA, MC, MD, ME, MF, MG, MH, MK, ML, MM, MN, MO, MP, MQ, MR, MS, MT, MU, MV, MW, MX, MY, MZ, NA, NC, NE, NF, NG, NI, NL, NO, NP, NR, NU, NZ, OM, PA, PE, PF, PG, PH, PK, PL, PM, PN, PR, PS, PT, PW, PY, QA, RE, RO, RS, RU, RW, SA, SB, SC, SD, SE, SG, SH, SI, SJ, SK, SL, SM, SN, SO, SR, SS, ST, SV, SX, SY, SZ, TC, TD, TF, TG, TH, TJ, TK, TL, TM, TN, TO, TR, TT, TV, TW, TZ, UA, UG, UM, US, UY, UZ, VA, VC, VE, VG, VI, VN, VU, WF, WS, XK, YE, YT, ZA, ZM, ZW&#125;&gt;* | special_ad_category_country&lt;br&gt; |
| `spend_cap`&lt;br&gt;&lt;br&gt;*int64* | A spend cap for the campaign, such that it will not spend more than this cap. Defined as integer value of subunit in your currency with a minimum value of $100 USD (or approximate local equivalent). Set the value to 922337203685478 to remove the spend cap. Not available for Reach and Frequency or Premium Self Serve campaigns&lt;br&gt; |
| `start_time`&lt;br&gt;&lt;br&gt;*datetime* | start_time&lt;br&gt; |
| `status`&lt;br&gt;&lt;br&gt;*enum&#123;ACTIVE, PAUSED, DELETED, ARCHIVED&#125;* | Only `ACTIVE` and `PAUSED` are valid during&lt;br&gt;creation. Other statuses can be used for update. If it is set to&lt;br&gt;`PAUSED`, its active child objects will be paused and have an effective&lt;br&gt;status `CAMPAIGN_PAUSED`.&lt;br&gt; |
| `stop_time`&lt;br&gt;&lt;br&gt;*datetime* | stop_time&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node to which you POSTed.
```
Struct &#123;
success: bool,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 200 | Permissions error |
| 613 | Calls to this api have exceeded the rate limit. |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 2635 | You are calling a deprecated version of the Ads API. Please update to the latest version. |
| 190 | Invalid OAuth 2.0 Access Token |
| 801 | Invalid operation |
## Deleting
### /&#123;campaign_id&#125;
You can delete a [Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group) by making a DELETE request to [/&#123;campaign_id&#125;](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group).
#### Parameters
This endpoint doesn&#039;t have any parameters.
#### Return Type
```
Struct &#123;
success: bool,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 200 | Permissions error |
| 80004 | There have been too many calls to this ad-account. Wait a bit and try again. For more info, please refer to /docs/graph-api/overview/rate-limiting#ads-management. |
| 100 | Invalid parameter |
| 190 | Invalid OAuth 2.0 Access Token |
### /act_&#123;ad_account_id&#125;/campaigns
You can dissociate a [Campaign](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group) from an [AdAccount](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account) by making a DELETE request to [/act_&#123;ad_account_id&#125;/campaigns](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account/campaigns).
#### Parameters
| Parameter | Description |
| --- | --- |
| `before_date`&lt;br&gt;&lt;br&gt;*datetime* | Set a before date to delete campaigns before this date&lt;br&gt; |
| `delete_strategy`&lt;br&gt;&lt;br&gt;*enum&#123;DELETE_ANY, DELETE_OLDEST, DELETE_ARCHIVED_BEFORE&#125;* | Delete strategy&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `object_count`&lt;br&gt;&lt;br&gt;*integer* | Object count&lt;br&gt; |
#### Return Type
```
Struct &#123;
objects_left_to_delete_count: unsigned int32,
deleted_object_ids: List [numeric string],
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
## Objective Validation
**Warning:** These older objectives are deprecated with the release of [Marketing API v17.0](https://developers.facebook.com/docs/graph-api/changelog/version17.0#marketing-api). Please refer to the [Outcome-Driven Ads Experiences mapping table](#odax-mapping) below to find the new objectives and their corresponding destination types, optimization goals and promoted objects.
Your campaign objective choice can limit the settings available to you.
### Optimization Goals
Certain campaign objectives support only certain ad set `optimization_goals`. See [Bidding Overview, Validation](https://developers.facebook.com/documentation/ads-commerce/marketing-api/bidding/overview#opt-goal-validation).
### Compatible Ad Types
| Objective | Compatible Ad Types |
| --- | --- |
| `APP_INSTALLS` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [App Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/mobile-app-ads)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Segment Asset Customization Ads](https://developers.facebook.com/docs/marketing-api/dynamic-creative/segment-asset-customization)&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Multi-Language Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/multi-language-ads)&lt;br&gt;- [Dynamic Ads](https://developers.facebook.com/docs/marketing-api/dynamic-ads)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
| `BRAND_AWARENESS` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Segment Asset Customization Ads](https://developers.facebook.com/docs/marketing-api/dynamic-creative/segment-asset-customization)&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Multi-Language Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/multi-language-ads)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
| `CONVERSIONS` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Collection Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/creative/collection-ads)&lt;br&gt;- [App Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/mobile-app-ads)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Ads that click to Messenger](https://developers.facebook.com/documentation/ads-commerce/marketing-api/ad-creative/messaging-ads#destination)&lt;br&gt;- [Offer Ads](https://developers.facebook.com/docs/marketing-api/guides/offer-ads)&lt;br&gt;- [Segment Asset Customization Ads](https://developers.facebook.com/docs/marketing-api/dynamic-creative/segment-asset-customization)&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Multi-Language Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/multi-language-ads)&lt;br&gt;- [Dynamic Ads](https://developers.facebook.com/docs/marketing-api/dynamic-ads)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
| `EVENT_RESPONSES` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Event and Local Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/event-ads) |
| `LEAD_GENERATION` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Lead Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/lead-ads)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
| `LINK_CLICKS` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Collection Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/creative/collection-ads)&lt;br&gt;- [App Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/mobile-app-ads)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Offer Ads](https://developers.facebook.com/docs/marketing-api/guides/offer-ads)&lt;br&gt;- [Segment Asset Customization Ads](https://developers.facebook.com/docs/marketing-api/dynamic-creative/segment-asset-customization)&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Multi-Language Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/multi-language-ads)&lt;br&gt;- [Dynamic Ads](https://developers.facebook.com/docs/marketing-api/dynamic-ads)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
| `MESSAGES` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Messenger Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/ad-creative/messaging-ads#destination) |
| `POST_ENGAGEMENT` | - Image Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign)) |
| `PRODUCT_CATALOG_SALES` | - Image Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Collection Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/creative/collection-ads)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Dynamic Ads](https://developers.facebook.com/docs/marketing-api/dynamic-ads)&lt;br&gt;- [Collaborative Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/collaborative-ads) |
| `REACH` | - Image Ads&lt;br&gt;- Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Segment Asset Customization Ads](https://developers.facebook.com/docs/marketing-api/dynamic-creative/segment-asset-customization)&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Multi-Language Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/multi-language-ads)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
| `STORE_VISITS` | - Image Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Collection Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/creative/collection-ads)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Offer Ads](https://developers.facebook.com/docs/marketing-api/guides/offer-ads) |
| `VIDEO_VIEWS` | - Video Ads&lt;br&gt;- Carousel Ads&lt;br&gt;- [Instant Experience Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instant-experiences)&lt;br&gt;- [Instagram Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads) (see [placement limitations](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/instagramads/get-started#campaign))&lt;br&gt;- [Segment Asset Customization Ads](https://developers.facebook.com/docs/marketing-api/dynamic-creative/segment-asset-customization)&lt;br&gt;- [Placement Asset Customization Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/dynamic-creative/placement-asset-customization)&lt;br&gt;- [Multi-Language Ads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/multi-language-ads)&lt;br&gt;- [Dynamic Creative](https://developers.facebook.com/docs/marketing-api/dynamic-creative/overview) |
### Objectives and Creative Fields &#123;#objective_creative&#125;
See our [ads guide](https://www.facebook.com/business/ads-guide/) for a list of creatives supported per objective. In the API, the objective determines which [ad creatives](https://developers.facebook.com/docs/reference/ads-api/adcreative) are valid.
| Objective | Creative Fields |
| --- | --- |
| `APP_INSTALLS` | `object_story_id` or `object_story_spec` |
| `CONVERSIONS` | `object_story_id` or `object_story_spec`&lt;br&gt;&lt;br&gt;Notes:&lt;br&gt;&lt;br&gt;- If you are creating link ads not connected to a page, use the following creative fields: `title`, `body`, `object_url`, and `image_file` or `image_hash`.&lt;br&gt;- Creative cannot include link ads pointing to an app store. |
| `EVENT_RESPONSES` | `object_story_id` or `object_story_spec` |
| `LEAD_GENERATION` | `object_story_id` or `object_story_spec` |
| `LINK_CLICKS` | `object_story_id` or `object_story_spec`&lt;br&gt;&lt;br&gt;Notes:&lt;br&gt;&lt;br&gt;- Creative cannot include link ads pointing to an app store.&lt;br&gt;- If you select `LINK_CLICKS` as both optimization goal and billing event, you must include `call_to_action`. |
| `MESSAGES` | `object_story_spec` |
| `PAGE_LIKES` | `object_story_id`, `object_story_spec`, `object_id`, and `body` |
| `POST_ENGAGEMENT` | `object_story_id` or `object_story_spec`&lt;br&gt;&lt;br&gt;Note: Creative cannot include link ads pointing to an app store. |
| `VIDEO_VIEWS` | `object_story_id` or `object_story_spec` |
### Objectives and Tracking Specs &#123;#objective_tracking&#125;
Tracking specs are applied by default based on the objective specified, please see the full list of defaults by objective [here](https://developers.facebook.com/documentation/ads-commerce/marketing-api/tracking-specs#default).
There are two important scenarios to take into account:
* Tracking pixels are not applied by default, and you must specify it explicitly when your objective is `CONVERSIONS`.
* Mobile app ads will no longer track installs or app events by default. **You must explicitly specify to track installs or app events for mobile app ads otherwise your ad will not track.**
To specify to track an install or app event, set the following in your [ad](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/adgroup):
```
tracking_specs=[&#123;&#039;action.type&#039;:[&#039;mobile_app_install&#039;],&#039;application&#039;:[&#123;your_app_id&#125;]&#125;,&#123;&#039;action.type&#039;:[&#039;app_custom_event&#039;],&#039;application&#039;:[&#123;your_app_id&#125;]&#125;]
```
### Objective and Promoted Objects &#123;#promoted-object&#125;
Certain objectives require the `promoted_object` to be set in ad sets. See [Promoted Object](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-promoted-object) for more information.
| Objective | Required promoted_object Fields |
| --- | --- |
| `APP_INSTALLS` | - `application_id` and `object_store_url`&lt;br&gt;- If `optimization_goal` is `OFFSITE_CONVERSIONS`: `application_id`, `object_store_url`, and `custom_event_type` |
| `CONVERSIONS` | - `pixel_id` (Conversion pixel ID)&lt;br&gt;- `pixel_id` (Facebook pixel ID) and `custom_event_type`&lt;br&gt;- `pixel_id` (Facebook pixel ID), `pixel_rule`, and `custom_event_type`&lt;br&gt;- `event_id` (Facebook event ID) and `custom_event_type`&lt;br&gt;- For mobile app events: `application_id`, `object_store_url`, and `custom_event_type`&lt;br&gt;- For offline conversions: `offline_conversion_data_set_id` (Offline dataset ID), and `custom_event_type` |
| `LINK_CLICKS` | For mobile app or Instant Experiences app engagement link clicks: `application_id` and `object_store_url`. |
| `PRODUCT_CATALOG_SALES` | - `product_set_id`, or&lt;br&gt;- `product_set_id` and `custom_event_type` |
| `PAGE_LIKES` | `page_id` |
| `OFFER_CLAIMS` | `page_id` |
### Objective and Placements &#123;#placement&#125;
Certain types of ad [placements](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/advanced-targeting#placement) are valid only for specific objectives or creatives. See [Business Help Center, Available ad placements for marketing objectives](https://www.facebook.com/business/help/279271845888065?id=369787570424415).
The table below shows some placements and their compatible objectives or creatives. You can pick a combination of those compatible placements. Note that:
* With `LEAD_GENERATION`, `device_platforms: desktop` cannot be selected together with `publisher_platforms: instagram`.
* If your objective is website traffic, `story` for `facebook_positions` does not support `destination_type: messenger`.
* If your objective is website traffic, `story` for `messenger_positions` does not support `destination_type: messenger`.
* If your objective is website traffic, `ig_search` and `explore_home` for `instagram_positions` do not support `destination_type: whatsapp &amp; messenger`.
| Objective | Creative | Placement |
| --- | --- | --- |
| `APP_INSTALLS`, promoting an Instant Experiences app | Desktop app ads | `device_platforms`: `desktop` |
| `APP_INSTALLS`, promoting a mobile app | Photo or video mobile app ads | `device_platforms`: `mobile`&lt;br&gt;&lt;br&gt;`publisher_platforms`: `facebook`, `feed`, `instagram`, `audience_network`&lt;br&gt; `facebook_positions`: `feed`, `video_feeds`, `instant articles` and `story`&lt;br&gt;&lt;br&gt;`audience_network_positions`: `classic`, `rewarded_video`&lt;br&gt;&lt;br&gt;`messenger_positions`: `story` |
| `BRAND_AWARENESS` | all | `publisher_platforms`: `facebook`, `instagram`, `audience_network`.&lt;br&gt;&lt;br&gt;`facebook_positions`: `feed`, `video_feeds`, `instream_video` and `story`, which is currently under limited availability&lt;br&gt;&lt;br&gt;`instagram_positions`: `stream`&lt;br&gt;&lt;br&gt;`audience_network_positions`: `classic`, `instream_video` |
| `CONVERSIONS` | Photo or video link ads from a page | We support `BRAND_AWARENESS`, `APP_INSTALL`, `POST_ENGAGEMENT`, `VIDEO_VIEWS`, `REACH`, `WEBSITE_CONVERSIONS`, and `TRAFFIC`.&lt;br&gt;Also supported: `right_hand_column` and `story` for `facebook_positions` and `messenger_positions`: `messenger_home` and `story`.&lt;br&gt;&lt;br&gt;`facebook_positions`: `story` only supports the objective `WEBSITE_CONVERSIONS`&lt;br&gt;&lt;br&gt;`messenger_positions`: `story` only supports the objective `WEBSITE_CONVERSIONS`&lt;br&gt;&lt;br&gt;Exception: `instream_video` is not supported for this objective. |
| `CONVERSIONS` | Link ads not connected to a page | `facebook_positions`: `right_hand_column` |
| `CONVERSIONS` (promoting mobile app) | Photo or video mobile app ads | `device_platforms`: `mobile`.&lt;br&gt;&lt;br&gt;`facebook_positions`: `right_hand_column` and `story`. `story` as a `facebook_positions` for this objective does not support `destination_type`: `messenger`.&lt;br&gt;&lt;br&gt;`messenger_positions`: `messenger_home`&lt;br&gt;&lt;br&gt;`story` as a `messenger_positions` for this objective does not support `destination_type: messenger`. |
| `EVENT_RESPONSES` | Event ads | As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `EVENT_RESPONSES` | Page post ads | `publisher_platforms`: `facebook`. &lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `LEAD_GENERATION` | Page post ads | `device_platforms`: `mobile`, `desktop`&lt;br&gt;&lt;br&gt;`publisher_platforms`: `facebook`, `instagram`&lt;br&gt;&lt;br&gt;`facebook_positions`: `feed` and `story`, which is in limited availability&lt;br&gt;&lt;br&gt;instagram_positions: stream&lt;br&gt;&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `LINK_CLICKS` | Photo or video link ads from a page | All, including `right_hand_column` and `messenger_positions`: `messenger_home` and `story`. |
| `LINK_CLICKS` | Link ads not connected to a page | `facebook_positions`: `right_hand_column` |
| `LINK_CLICKS`, promoting an Instant Experiences app | Desktop app ads | `device_platforms`: `desktop`&lt;br&gt;&lt;br&gt;`facebook_positions`: `right_hand_column` |
| `LINK_CLICKS`, promoting a mobile app | Photo or video mobile app ads | `device_platforms`: `mobile`, `facebook_positions`: `right_hand_column` |
| `PAGE_LIKES` | Video creatives | `publisher_platforms`: `facebook`&lt;br&gt;&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `POST_ENGAGEMENT` | Page post ads with video or photo | `publisher_platforms`: `facebook`, `instagram`&lt;br&gt;&lt;br&gt;`device_platforms`: `mobile`, `desktop`&lt;br&gt;&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `POST_ENGAGEMENT` | Page post ads with text only | `publisher_platforms`: `facebook`, `instagram`&lt;br&gt;&lt;br&gt;`device_platforms`: `mobile`, `desktop`&lt;br&gt;&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `POST_ENGAGEMENT` | New campaign | `publisher_platforms`: `facebook`, `instagram`&lt;br&gt;&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `PRODUCT_CATALOG_SALES` | dynamic ads | All, including `right_hand_column` for `facebook_positions`. |
| `REACH` | Reach ads | All except `right_hand_column` for `facebook_positions` as of 3.0. &lt;br&gt;Includes `messenger_positions`: `story` and `story` for `facebook_positions`. |
| `STORE_VISITS` | store visit ads | `publisher_platforms`: `facebook`&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
| `VIDEO_VIEWS` | Video ads | `publisher_platforms`: `facebook`, `instagram`, `audience_network`.&lt;br&gt;&lt;br&gt;Includes `story` for `facebook_positions` but not with the `optimation_goal` set to `TWO_SECOND_CONTINUOUS_VIDEO_VIEWS`.&lt;br&gt;&lt;br&gt;As of 3.0, you cannot use `right_hand_column` for `facebook_positions` |
### Objective, Optimization Goal and `attribution_spec` &#123;#attribution_spec&#125;
Use click-through and view-through attribution windows for [ad set](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign#Creating) to track conversions then use for ads delivery optimization. This is different from the attribution window you use for ads reporting. With `attribution_spec`, select a combination of click-through or view-through windows of 1 day or 7 days. The combinations you can use depend on your ad set&#039;s `optimization_goal` and campaign&#039;s `objective`.
**Recommended Default `attribution_spec`**
You may not have provided `attribution_spec` when you created ads sets optimized for Value Optimization. This is an optimization available for conversions, app installs, and product catalog sales objectives. In the past, we defaulted to a 1-day click through attribution window.
| Objective | Optimization Goal | Allowed Combination |
| --- | --- | --- |
| `CONVERSIONS, PRODUCT_CATALOG_SALES` | `OFFSITE_CONVERSIONS` | 1-day click&lt;br&gt;7-day click&lt;br&gt;1-day click and 1-day view&lt;br&gt;7-day click and 1-day view |
| `APP_INSTALLS, LINK_CLICKS` | `OFFSITE_CONVERSIONS` | 1-day click&lt;br&gt;&lt;br&gt;7-day click |
| `APP_INSTALLS` | `APP_INSTALLS` | 1-day click&lt;br&gt;1-day click and 1-day engaged-view&lt;br&gt;1-day click and 1-day view&lt;br&gt;1-day click and 1-day engaged-view and 1-day view |
| `CONVERSIONS` | `INCREMENTAL_OFFSITE_&lt;br&gt;CONVERSIONS` | Null click, Null view |
For all other `optimization_goal` and `objective` combinations, you can only use 1-day click for `attribution_spec`.
### Outcome-Driven Ads Experiences Objective Validation &#123;#odax&#125;
**Warning:** From v20.0 onwards, Impressions optimization goal is deprecated for the legacy Post Engagement objective and the `ON_POST` destination_type.
#### Objective values
The following are newer objectives:
* `OUTCOME_APP_PROMOTION`
* `OUTCOME_AWARENESS`
* `OUTCOME_ENGAGEMENT`
* `OUTCOME_LEADS`
* `OUTCOME_SALES`
* `OUTCOME_TRAFFIC`
These newer objectives will eventually replace the original objectives `APP_INSTALLS`, `BRAND_AWARENESS`, `CONVERSIONS`, `EVENT_RESPONSES`, `LEAD_GENERATION`, `LINK_CLICKS`, `LOCAL_AWARENESS`, `MESSAGES`, `OFFER_CLAIMS`, `PAGE_LIKES`, `POST_ENGAGEMENT`, `PRODUCT_CATALOG_SALES`, `REACH`, `STORE_VISITS`, `VIDEO_VIEWS`. We will continue supporting these original objectives throughout 2022.
#### Limitations
* Trying to duplicate existing objective campaigns to use the new objective values (`OUTCOME_APP_PROMOTION`, `OUTCOME_AWARENESS`, `OUTCOME_ENGAGEMENT`, `OUTCOME_LEADS`, `OUTCOME_SALES`, `OUTCOME_TRAFFIC`) may throw an error.
#### Example
**Outcome-Driven Ads Experiences**
```
curl -X POST \
-F &#039;name=&quot;New ODAX Campaign&quot;&#039; \
-F &#039;objective=&quot;OUTCOME_ENGAGEMENT&quot;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;special_ad_categories=[]&#039; \
-F &#039;access_token=ACCESS_TOKEN \
https://graph.facebook.com/v11.0/
act_AD_ACCOUNT_ID/campaigns
```
**Legacy**
```
curl -X POST \
-F &#039;name=&quot;New Campaign&quot;&#039; \
-F &#039;objective=&quot;APP_INSTALLS&quot;&#039; \
-F &#039;status=&quot;PAUSED&quot;&#039; \
-F &#039;special_ad_categories=[]&#039; \
-F &#039;access_token=ACCESS_TOKEN \
https://graph.facebook.com/v11.0/
act_AD_ACCOUNT_ID/campaigns
```
#### Objective Mapping &#123;#odax-mapping&#125;
| Old Objective | New Objective | Destination Type | Optimization Goal | Promoted Object |
| --- | --- | --- | --- | --- |
| `BRAND_AWARENESS` | `OUTCOME_AWARENESS` | — | `AD_RECALL_LIFT` | `page_id` |
| `REACH` | `OUTCOME_AWARENESS` | — | `REACH` | `page_id` |
| `REACH` | `OUTCOME_AWARENESS` | — | `IMPRESSIONS` | `page_id` |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | — | `LINK_CLICKS` | `application_id`, `object_store_url` |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | — | `LANDING_PAGE_VIEWS` | — |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | — | `REACH` | `application_id`, `object_store_url` |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | — | `IMPRESSIONS` | — |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `MESSENGER` | `LINK_CLICKS` | — |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `MESSENGER` | `REACH` | — |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `MESSENGER` | `IMPRESSIONS` | — |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `WHATSAPP` | `LINK_CLICKS` | `page_id` |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `WHATSAPP` | `REACH` | `page_id` |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `WHATSAPP` | `IMPRESSIONS` | `page_id` |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `PHONE_CALL` | `QUALITY_CALL` | — |
| `LINK_CLICKS` | `OUTCOME_TRAFFIC` | `PHONE_CALL` | `LINK_CLICKS` | — |
| `POST_ENGAGEMENT` | `OUTCOME_ENGAGEMENT` | `ON_POST` | `POST_ENGAGEMENT` | — |
| `POST_ENGAGEMENT` | `OUTCOME_ENGAGEMENT` | `ON_POST` | `REACH` | — |
| `POST_ENGAGEMENT` | `OUTCOME_ENGAGEMENT` | `ON_POST` | `IMPRESSIONS` | — |
| `PAGE_LIKES` | `OUTCOME_ENGAGEMENT` | `ON_PAGE` | `PAGE_LIKES` | `page_id` |
| `EVENT_RESPONSES` | `OUTCOME_ENGAGEMENT` | `ON_EVENT` | `EVENT_RESPONSES` | — |
| `EVENT_RESPONSES` | `OUTCOME_ENGAGEMENT` | `ON_EVENT` | `POST_ENGAGEMENT` | — |
| `EVENT_RESPONSES` | `OUTCOME_ENGAGEMENT` | `ON_EVENT` | `REACH` | — |
| `EVENT_RESPONSES` | `OUTCOME_ENGAGEMENT` | `ON_EVENT` | `IMPRESSIONS` | — |
| `APP_INSTALL` | `OUTCOME_APP_PROMOTION` | — | `LINK_CLICKS` | `application_id`, `object_store_url` |
| `APP_INSTALL` | `OUTCOME_APP_PROMOTION` | — | `OFFSITE_CONVERSIONS` | `application_id`, `object_store_url` |
| `APP_INSTALL` | `OUTCOME_APP_PROMOTION` | — | `APP_INSTALLS` | `application_id`, `object_store_url` |
| `VIDEO_VIEWS` | `OUTCOME_AWARENESS` | — | `THRUPLAY` | `page_id` |
| `VIDEO_VIEWS` | `OUTCOME_AWARENESS` | — | `TWO_SECOND_CONTINUOUS_VIDEO_VIEWS` | `page_id` |
| `VIDEO_VIEWS` | `OUTCOME_ENGAGEMENT` | `ON_VIDEO` | `THRUPLAY` | — |
| `VIDEO_VIEWS` | `OUTCOME_ENGAGEMENT` | `ON_VIDEO` | `TWO_SECOND_CONTINUOUS_VIDEO_VIEWS` | — |
| `LEAD_GENERATION` | `OUTCOME_LEADS` | `ON_AD` | `LEAD_GENERATION` | `page_id` |
| `LEAD_GENERATION` | `OUTCOME_LEADS` | `ON_AD` | `QUALITY_LEAD` | `page_id` |
| `LEAD_GENERATION` | `OUTCOME_LEADS` | `LEAD_FROM_MESSENGER` | `LEAD_GENERATION` | `page_id` |
| `LEAD_GENERATION` | `OUTCOME_LEADS` | `LEAD_FROM_IG_DIRECT` | `LEAD_GENERATION` | `page_id` |
| `LEAD_GENERATION` | `OUTCOME_LEADS` | `PHONE_CALL` | `QUALITY_CALL` | `page_id` |
| `MESSAGES` | `OUTCOME_ENGAGEMENT` | `MESSENGER` | `CONVERSATIONS` | `page_id` |
| `MESSAGES` | `OUTCOME_ENGAGEMENT` | `MESSENGER` | `LINK_CLICKS` | `page_id` |
| `MESSAGES` | `OUTCOME_ENGAGEMENT` | `MESSENGER` | `LEAD_GENERATION` | `page_id` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `OFFSITE_CONVERSIONS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `OFFSITE_CONVERSIONS` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `LINK_CLICKS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `LINK_CLICKS` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `REACH` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `REACH` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `LANDING_PAGE_VIEWS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_ENGAGEMENT` | — | `IMPRESSIONS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `OFFSITE_CONVERSIONS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `OFFSITE_CONVERSIONS` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `LINK_CLICKS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `LINK_CLICKS` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `REACH` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `REACH` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `LANDING_PAGE_VIEWS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_LEADS` | — | `IMPRESSIONS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_SALES` | — | `OFFSITE_CONVERSIONS` | `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_SALES` | — | `OFFSITE_CONVERSIONS` | `application_id`, `object_store_url` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_SALES` | `MESSENGER` | `CONVERSATIONS` | `page_id`, `pixel_id`, `custom_event_type` |
| `CONVERSIONS`&lt;br&gt;&lt;br&gt;(See [Available conversion locations and events by objective in Meta Ads Manager](https://www.facebook.com/business/help/2035196646663270) for more information on available conversion events by objective.) | `OUTCOME_SALES` | `PHONE_CALL` | `QUALITY_CALL` | `page_id` |
| `PRODUCT_CATALOG_SALES` | `OUTCOME_SALES` | `WEBSITE` | `LINK_CLICKS` | Campaign: `product_catalog_id`&lt;br&gt;&lt;br&gt;Ad set: `product_set_id`, `custom_event_type` |
| `STORE_VISITS` | `OUTCOME_AWARENESS` | — | `REACH` | `place_page_set_id` |
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/llms.txt
