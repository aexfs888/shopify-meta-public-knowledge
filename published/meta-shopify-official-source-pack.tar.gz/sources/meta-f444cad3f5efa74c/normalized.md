Administrador comercial - Business Management APIs - Documentación - Meta for Developers
-
Business Management APIs
Administrador comercial
- Usuarios del sistema
- Administración de activos comerciales
- Administración de activos de contenido del negocio
- Solución del administrador comercial de 2 niveles
# API del administrador comercial
Ayuda a los negocios y a las agencias a administrar en un único lugar sus páginas, cuentas publicitarias y apps de Facebook. La API del administrador comercial ayuda a administrar varios activos y permisos de cuentas publicitarias. También puedes automatizar la creación de cuentas publicitarias. Consulta los conceptos básicos del administrador comercial en el servicio de ayuda para anunciantes .
En el administrador comercial, se conectan activos relacionados con anuncios y otros activos comerciales para lo siguiente:
-
Administración de permisos.
-
Ejecución de campañas en nombre de otra empresa.
-
Creación de cuentas publicitarias y asignación de crédito para la compra de anuncios.
## Contenido de la documentación
### Empezar
Empieza a usar nuestra API. Trabaja con el administrador comercial , actualiza el administrador comercial , administra usuarios y roles y administra activos comerciales . Obtén información acerca de las notas de pago pendientes para ver y administrar los orígenes de crédito relacionados con un negocio.
### Guías
Guías basadas en casos de uso que te ayudan a realizar acciones específicas. Descubre cómo administrar tus activos comerciales. Incluye Negocio en nombre de .
|
### Prácticas recomendadas y preguntas frecuentes
Sigue estas normas si eres un socio de marketing o anunciante de Facebook que administra páginas o cuentas publicitarias.
### Ayuda
Preguntas frecuentes y recursos.
|
