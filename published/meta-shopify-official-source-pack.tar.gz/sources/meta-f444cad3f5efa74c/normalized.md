Business Manager - Business Management APIs - Documentation - Meta for Developers
-
Business Management APIs
Business Manager
- System Users
- Business Asset Management
- Business Creative Asset Management
- 2-Tier Business Manager Solution
# Business Manager API
Help businesses and agencies manage Facebook Pages, ad accounts and apps in one place. Business Manager API's help manage multiple ad account assets and permissions. You can also automate the creation of ad accounts. See Ads Help Center, Business Manager Basics .
In Business Manager you connect ads-related assets and other business assets for:
- Permission management.
- Run campaigns on behalf of another company.
- Create ad accounts and assign credit to buy ads.
## Documentation Contents
### Get Started
Start using our API. Work With Business Manager , Update Business Manager , Manage People and Roles , and Manage Business Assets . Learn about Invoices to view and manage credit sources associated with a business.
### Guides
Use case based guides to help you perform specific actions. Learn how to manage your business' assets. Includes Business On Behalf Of .
|
### Best Practices and FAQ
Follow these guidelines if you are a Facebook Marketing Partner or a advertiser managing ad accounts or Pages.
### Support
Frequently asked questions and resources.
|
