-
Account Security | Facebook Help Center
Help Center
English (US)
##
Account Security
#
Account Security
Copy link
We build security into Facebook with security features like login alerts and two-factor authentication to help you add an extra layer of protection to your account. You can also review and update your security settings at any time.
Learn more about what you can do to keep your account secure and how to protect yourself from phishing .
Security Tips and Features
Spam, Scams and Phishing
##
Was this helpful?
Yes
No
## Popular Articles
Security Tips and Features
Add a security key to your Meta Account
Use a security key to log into your Facebook account
Protect your personal and business account from malicious software designed to steal your login information
Popular Articles
Security Tips and Features
Add a security key to your Meta Account
Use a security key to log into your Facebook account
Protect your personal and business account from malicious software designed to steal your login information
## Related Topics
Your Privacy
Learn how privacy settings help you connect and share with people you know and trust.
Account Settings
Learn how to adjust your settings, change your username and choose a legacy contact.
Reporting Abuse
Learn how to report something that goes against the Facebook Community Standards.
Your Privacy
Account Settings
Reporting Abuse
## Other ways to get help
Chat with Meta AI support assistant
Resolve issues, make changes and get support in real time
Get a call from Meta AI assistant
Get support info from our AI support assistant by phone
About
- Privacy
- Terms and Policies
- Ad Choices
- Careers
- Cookies
- Create Ad
- Create Page
© 2026 Meta
Feedback
