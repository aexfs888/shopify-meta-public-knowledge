-
Seguridad de la cuenta | Servicio de ayuda de Facebook
Servicio de ayuda
Español
##
Seguridad de la cuenta
#
Seguridad de la cuenta
Copiar enlace
Incorporamos medidas de seguridad en Facebook mediante diversas funciones de seguridad , como las alertas de inicio de sesión y la autenticación en dos pasos , para ayudarte a agregar un nivel adicional de protección a la cuenta. También puedes revisar y actualizar tu configuración de seguridad en cualquier momento.
Obtén más información sobre lo que puedes hacer para mantener la seguridad de tu cuenta y cómo protegerte del phishing .
Consejos y funciones de seguridad
Spam, estafas y phishing
##
¿Te resultó útil?
Sí
No
## Artículos populares
Cómo activar la protección avanzada en Facebook
Usar la comprobación rápida de seguridad para aumentar la seguridad de tu cuenta de Facebook
Consejos y funciones de seguridad
Protege tu cuenta personal y comercial de software malicioso diseñado para robar tu información de inicio de sesión
Artículos populares
Cómo activar la protección avanzada en Facebook
Usar la comprobación rápida de seguridad para aumentar la seguridad de tu cuenta de Facebook
Consejos y funciones de seguridad
Protege tu cuenta personal y comercial de software malicioso diseñado para robar tu información de inicio de sesión
## Temas relacionados
Tu privacidad
Obtén información sobre cómo la configuración de privacidad te ayuda a conectarte y compartir contenido con las personas que conoces y en quienes confías.
Configuración de la cuenta
Obtén información sobre cómo modificar la configuración, cambiar tu nombre de usuario y elegir un contacto de legado.
Reportar conductas abusivas
Obtén información sobre cómo reportar contenido que infrinja las Normas comunitarias de Facebook.
Tu privacidad
Configuración de la cuenta
Reportar conductas abusivas
## Otras formas de obtener ayuda
Chatea con el asistente de ayuda de Meta AI
Resuelve problemas, realiza cambios y obtén ayuda en tiempo real
Información
- Privacidad
- Condiciones y políticas
- Opciones de anuncios
- Empleo
- Cookies
- Crear anuncio
- Crear página
© 2026 Meta
Enviar comentarios
