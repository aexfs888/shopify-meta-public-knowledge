# Ad Account Product Audiences
## Reading
You can&#039;t perform this operation on this endpoint.
## Creating
### /act_&#123;ad_account_id&#125;/product_audiences
You can make a POST request to *product_audiences* edge from the following paths:
- [/act_&#123;ad_account_id&#125;/product_audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account/product_audiences)
When posting to this edge, an [AdAccount](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-account) will be created.
#### Example
### HTTP
```
POST /v25.0/act_&lt;AD_ACCOUNT_ID&gt;/product_audiences HTTP/1.1
Host: graph.facebook.com
name=Test+Iphone+Product+Audience&amp;product_set_id=%3CPRODUCT_SET_ID%3E&amp;inclusions=%5B%7B%22retention_seconds%22%3A86400%2C%22rule%22%3A%7B%22and%22%3A%5B%7B%22event%22%3A%7B%22eq%22%3A%22AddToCart%22%7D%7D%2C%7B%22userAgent%22%3A%7B%22i_contains%22%3A%22iPhone%22%7D%7D%5D%7D%7D%5D&amp;exclusions=%5B%7B%22retention_seconds%22%3A172800%2C%22rule%22%3A%7B%22event%22%3A%7B%22eq%22%3A%22Purchase%22%7D%7D%7D%5D
```
### PHP SDK
```
/* PHP SDK v5.0.0 */
/* make the API call */
try &#123;
// Returns a `Facebook\FacebookResponse` object
$response = $fb-&gt;post(
&#039;/act_&lt;AD_ACCOUNT_ID&gt;/product_audiences&#039;,
array (
&#039;name&#039; =&gt; &#039;Test Iphone Product Audience&#039;,
&#039;product_set_id&#039; =&gt; &#039;&lt;PRODUCT_SET_ID&gt;&#039;,
&#039;inclusions&#039; =&gt; &#039;[&#123;&quot;retention_seconds&quot;:86400,&quot;rule&quot;:&#123;&quot;and&quot;:[&#123;&quot;event&quot;:&#123;&quot;eq&quot;:&quot;AddToCart&quot;&#125;&#125;,&#123;&quot;userAgent&quot;:&#123;&quot;i_contains&quot;:&quot;iPhone&quot;&#125;&#125;]&#125;&#125;]&#039;,
&#039;exclusions&#039; =&gt; &#039;[&#123;&quot;retention_seconds&quot;:172800,&quot;rule&quot;:&#123;&quot;event&quot;:&#123;&quot;eq&quot;:&quot;Purchase&quot;&#125;&#125;&#125;]&#039;,
),
&#039;&#123;access-token&#125;&#039;
);
&#125; catch(Facebook\Exceptions\FacebookResponseException $e) &#123;
echo &#039;Graph returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125; catch(Facebook\Exceptions\FacebookSDKException $e) &#123;
echo &#039;Facebook SDK returned an error: &#039; . $e-&gt;getMessage();
exit;
&#125;
$graphNode = $response-&gt;getGraphNode();
/* handle the result */
```
### JavaScript SDK
```
/* make the API call */
FB.api(
&quot;/act_&lt;AD_ACCOUNT_ID&gt;/product_audiences&quot;,
&quot;POST&quot;,
&#123;
&quot;name&quot;: &quot;Test Iphone Product Audience&quot;,
&quot;product_set_id&quot;: &quot;&lt;PRODUCT_SET_ID&gt;&quot;,
&quot;inclusions&quot;: &quot;[&#123;\&quot;retention_seconds\&quot;:86400,\&quot;rule\&quot;:&#123;\&quot;and\&quot;:[&#123;\&quot;event\&quot;:&#123;\&quot;eq\&quot;:\&quot;AddToCart\&quot;&#125;&#125;,&#123;\&quot;userAgent\&quot;:&#123;\&quot;i_contains\&quot;:\&quot;iPhone\&quot;&#125;&#125;]&#125;&#125;]&quot;,
&quot;exclusions&quot;: &quot;[&#123;\&quot;retention_seconds\&quot;:172800,\&quot;rule\&quot;:&#123;\&quot;event\&quot;:&#123;\&quot;eq\&quot;:\&quot;Purchase\&quot;&#125;&#125;&#125;]&quot;
&#125;,
function (response) &#123;
if (response &amp;&amp; !response.error) &#123;
/* handle the result */
&#125;
&#125;
);
```
### Android SDK
```
Bundle params = new Bundle();
params.putString(&quot;name&quot;, &quot;Test Iphone Product Audience&quot;);
params.putString(&quot;product_set_id&quot;, &quot;&lt;PRODUCT_SET_ID&gt;&quot;);
params.putString(&quot;inclusions&quot;, &quot;[&#123;\&quot;retention_seconds\&quot;:86400,\&quot;rule\&quot;:&#123;\&quot;and\&quot;:[&#123;\&quot;event\&quot;:&#123;\&quot;eq\&quot;:\&quot;AddToCart\&quot;&#125;&#125;,&#123;\&quot;userAgent\&quot;:&#123;\&quot;i_contains\&quot;:\&quot;iPhone\&quot;&#125;&#125;]&#125;&#125;]&quot;);
params.putString(&quot;exclusions&quot;, &quot;[&#123;\&quot;retention_seconds\&quot;:172800,\&quot;rule\&quot;:&#123;\&quot;event\&quot;:&#123;\&quot;eq\&quot;:\&quot;Purchase\&quot;&#125;&#125;&#125;]&quot;);
/* make the API call */
new GraphRequest(
AccessToken.getCurrentAccessToken(),
&quot;/act_&lt;AD_ACCOUNT_ID&gt;/product_audiences&quot;,
params,
HttpMethod.POST,
new GraphRequest.Callback() &#123;
public void onCompleted(GraphResponse response) &#123;
/* handle the result */
&#125;
&#125;
).executeAsync();
```
### iOS SDK
```
NSDictionary *params = &#064;&#123;
&#064;&quot;name&quot;: &#064;&quot;Test Iphone Product Audience&quot;,
&#064;&quot;product_set_id&quot;: &#064;&quot;&lt;PRODUCT_SET_ID&gt;&quot;,
&#064;&quot;inclusions&quot;: &#064;&quot;[&#123;\&quot;retention_seconds\&quot;:86400,\&quot;rule\&quot;:&#123;\&quot;and\&quot;:[&#123;\&quot;event\&quot;:&#123;\&quot;eq\&quot;:\&quot;AddToCart\&quot;&#125;&#125;,&#123;\&quot;userAgent\&quot;:&#123;\&quot;i_contains\&quot;:\&quot;iPhone\&quot;&#125;&#125;]&#125;&#125;]&quot;,
&#064;&quot;exclusions&quot;: &#064;&quot;[&#123;\&quot;retention_seconds\&quot;:172800,\&quot;rule\&quot;:&#123;\&quot;event\&quot;:&#123;\&quot;eq\&quot;:\&quot;Purchase\&quot;&#125;&#125;&#125;]&quot;,
&#125;;
/* make the API call */
FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
initWithGraphPath:&#064;&quot;/act_&lt;AD_ACCOUNT_ID&gt;/product_audiences&quot;
parameters:params
HTTPMethod:&#064;&quot;POST&quot;];
[request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
id result,
NSError *error) &#123;
// Handle the result
&#125;];
```
### cURL
```
curl -X POST \
-F &#039;name=&quot;Test Iphone Product Audience&quot;&#039; \
-F &#039;product_set_id=&quot;&lt;PRODUCT_SET_ID&gt;&quot;&#039; \
-F &#039;inclusions=[
&#123;
&quot;retention_seconds&quot;: 86400,
&quot;rule&quot;: &#123;
&quot;and&quot;: [
&#123;
&quot;event&quot;: &#123;
&quot;eq&quot;: &quot;AddToCart&quot;
&#125;
&#125;,
&#123;
&quot;userAgent&quot;: &#123;
&quot;i_contains&quot;: &quot;iPhone&quot;
&#125;
&#125;
]
&#125;
&#125;
]&#039; \
-F &#039;exclusions=[
&#123;
&quot;retention_seconds&quot;: 172800,
&quot;rule&quot;: &#123;
&quot;event&quot;: &#123;
&quot;eq&quot;: &quot;Purchase&quot;
&#125;
&#125;
&#125;
]&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/product_audiences
```
Try it in [Graph API Explorer](https://developers.facebook.com/tools/explorer/?method=POST&amp;path=act_%3CAD_ACCOUNT_ID%3E%2Fproduct_audiences%3Fname%3DTest%2BIphone%2BProduct%2BAudience%26product_set_id%3D%253CPRODUCT_SET_ID%253E%26inclusions%3D%255B%257B%2522retention_seconds%2522%253A86400%252C%2522rule%2522%253A%257B%2522and%2522%253A%255B%257B%2522event%2522%253A%257B%2522eq%2522%253A%2522AddToCart%2522%257D%257D%252C%257B%2522userAgent%2522%253A%257B%2522i_contains%2522%253A%2522iPhone%2522%257D%257D%255D%257D%257D%255D%26exclusions%3D%255B%257B%2522retention_seconds%2522%253A172800%252C%2522rule%2522%253A%257B%2522event%2522%253A%257B%2522eq%2522%253A%2522Purchase%2522%257D%257D%257D%255D&amp;version=v25.0)
If you want to learn how to use the Graph API, read our [Using Graph API guide](https://developers.facebook.com/docs/graph-api/using-graph-api)
#### Parameters
| Parameter | Description |
| --- | --- |
| `associated_audience_id`&lt;br&gt;&lt;br&gt;*int64* | SELF_EXPLANATORY&lt;br&gt; |
| `creation_params`&lt;br&gt;&lt;br&gt;*dictionary &#123; string : &lt;string&gt; &#125;* | SELF_EXPLANATORY&lt;br&gt; |
| `description`&lt;br&gt;&lt;br&gt;*string* | SELF_EXPLANATORY&lt;br&gt; |
| `enable_fetch_or_create`&lt;br&gt;&lt;br&gt;*boolean* | enable_fetch_or_create&lt;br&gt; |
| `event_sources`&lt;br&gt;&lt;br&gt;*array&lt;JSON object&gt;* | event_sources&lt;br&gt;&lt;br&gt;&lt;br&gt;`id` *int64*&lt;br&gt;id&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`type` *enum &#123;APP, OFFLINE_EVENTS, PAGE, PIXEL&#125;*&lt;br&gt;type&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `exclusions`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | SELF_EXPLANATORY&lt;br&gt;&lt;br&gt;&lt;br&gt;`booking_window` *Object*&lt;br&gt;&lt;br&gt;`min_seconds` *int64*&lt;br&gt;&lt;br&gt;`max_seconds` *int64*&lt;br&gt;&lt;br&gt;`count` *Object*&lt;br&gt;&lt;br&gt;`event` *string*&lt;br&gt;&lt;br&gt;`type` *enum &#123;CUSTOM, PRIMARY, WEBSITE, APP, OFFLINE_CONVERSION, CLAIM, MANAGED, PARTNER, VIDEO, LOOKALIKE, ENGAGEMENT, BAG_OF_ACCOUNTS, STUDY_RULE_AUDIENCE, FOX, MEASUREMENT, REGULATED_CATEGORIES_AUDIENCE, BIDDING, EXCLUSION, MESSENGER_SUBSCRIBER_LIST&#125;*&lt;br&gt;&lt;br&gt;`retention` *Object*&lt;br&gt;&lt;br&gt;`min_seconds` *integer*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`max_seconds` *integer*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`retention_days` *int64*&lt;br&gt;&lt;br&gt;`retention_seconds` *integer*&lt;br&gt;&lt;br&gt;`rule` *Object*&lt;br&gt;&lt;br&gt;`pixel_id` *int64* |
| `inclusions`&lt;br&gt;&lt;br&gt;*list&lt;Object&gt;* | SELF_EXPLANATORY&lt;br&gt;&lt;br&gt;&lt;br&gt;`booking_window` *Object*&lt;br&gt;&lt;br&gt;`min_seconds` *int64*&lt;br&gt;&lt;br&gt;`max_seconds` *int64*&lt;br&gt;&lt;br&gt;`count` *Object*&lt;br&gt;&lt;br&gt;`event` *string*&lt;br&gt;&lt;br&gt;`type` *enum &#123;CUSTOM, PRIMARY, WEBSITE, APP, OFFLINE_CONVERSION, CLAIM, MANAGED, PARTNER, VIDEO, LOOKALIKE, ENGAGEMENT, BAG_OF_ACCOUNTS, STUDY_RULE_AUDIENCE, FOX, MEASUREMENT, REGULATED_CATEGORIES_AUDIENCE, BIDDING, EXCLUSION, MESSENGER_SUBSCRIBER_LIST&#125;*&lt;br&gt;&lt;br&gt;`retention` *Object*&lt;br&gt;&lt;br&gt;`min_seconds` *integer*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`max_seconds` *integer*&lt;br&gt;**[required]**&lt;br&gt;&lt;br&gt;&lt;br&gt;`retention_days` *int64*&lt;br&gt;&lt;br&gt;`retention_seconds` *integer*&lt;br&gt;&lt;br&gt;`rule` *Object*&lt;br&gt;&lt;br&gt;`pixel_id` *int64* |
| `name`&lt;br&gt;&lt;br&gt;*string* | SELF_EXPLANATORY&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `opt_out_link`&lt;br&gt;&lt;br&gt;*string* | SELF_EXPLANATORY&lt;br&gt; |
| `parent_audience_id`&lt;br&gt;&lt;br&gt;*int64* | SELF_EXPLANATORY&lt;br&gt; |
| `product_set_id`&lt;br&gt;&lt;br&gt;*numeric string or integer* | SELF_EXPLANATORY&lt;br&gt;&lt;br&gt;**[required]**&lt;br&gt; |
| `subtype`&lt;br&gt;&lt;br&gt;*enum &#123;CUSTOM, PRIMARY, WEBSITE, APP, OFFLINE_CONVERSION, CLAIM, MANAGED, PARTNER, VIDEO, LOOKALIKE, ENGAGEMENT, BAG_OF_ACCOUNTS, STUDY_RULE_AUDIENCE, FOX, MEASUREMENT, REGULATED_CATEGORIES_AUDIENCE, BIDDING, EXCLUSION, MESSENGER_SUBSCRIBER_LIST&#125;* | SELF_EXPLANATORY&lt;br&gt; |
#### Return Type
This endpoint supports [read-after-write](https://developers.facebook.com/docs/graph-api/overview#read-after-write) and will read the node represented by *id* in the return type.
```
Struct &#123;
id: numeric string,
message: string,
&#125;
```
#### Error Codes
| Error Code | Description |
| --- | --- |
| 100 | Invalid parameter |
| 2654 | Failed to create custom audience |
## Updating
You can&#039;t perform this operation on this endpoint.
## Deleting
You can&#039;t perform this operation on this endpoint.
