-
About Facebook Page access | Facebook Help Center
Help Center
English (US)
# About Facebook Page access
Copy link
Computer Help
iPhone App Help
iPad App Help
Android App Help
Mobile Browser Help
Basic Mobile Browser Help
Facebook Lite App Help
More
Computer Help
iPhone App Help
iPad App Help
Android App Help
Mobile Browser Help
Basic Mobile Browser Help
Facebook Lite App Help
You can give trusted people Facebook access or task access to help manage your Facebook Page. Compare Facebook Page access types, including Community Manager access for live chat moderation, to understand what each type allows.
## Facebook access for a Facebook Page
Facebook access comes with full control or partial control. People with Facebook access can switch into the Page and manage the Page on Facebook or through other Facebook tools. Switching into a Page means acting as the Page, rather than as your personal profile, on Facebook. With Facebook access, people can manage the following with full or partial control:
Content: Create, manage or delete any content on your Page like posts, Stories, and more. Apply for rights management and monetization of original content.
- Messages: Respond to direct messages as the Page in Inbox.
- Comments: Respond to comments on the Page and edit or delete existing comments made by the Page.
- Linked Accounts: Add, manage or remove linked accounts, such as Instagram.
- Ads: Create, manage and delete ads.
- Insights: Use Page, post and ad insights to analyze the performance of the Page.
- Events: Create, edit and delete events by the Page.
- Removal and Bans: Remove or ban people from the Page.
People with Facebook access with full control can also manage:
- Settings: Manage and edit all settings, such as Page information and deleting the Page.
- Access: Give or remove people’s Facebook or task access to the Page or linked Instagram account, including people with Facebook access with full control.
Giving Facebook access with full control to others gives them the same access as you. People with Facebook access with full control can give other people access to manage the Page, remove anyone from the Page (including you), or delete the Page. For your Page to remain active, at least one person must have Facebook access with full control. If there is no longer anyone with full control over the Page, the Page will be automatically deactivated and scheduled for deletion.
## Task access for a Facebook Page
People with task access can manage the Page from other management tools such as Meta Business Suite or Ads Manager . People with task access can’t switch into the Page or manage the Page on Facebook.
People with task access can manage the following:
- Content: Create, manage or delete any content on your Page like posts, Stories, and more. Apply for and access ways to manage rights to and potentially monetize your original content.
- Messages and Community Activity: Respond to direct messages, comment, manage unwanted content, and report Page activity.
- Ads: Create, manage and delete ads, and other ads-related tasks.
- Insights: View Page, content, ad, and metric performance.
## Community Manager access for a Facebook Page
Community Managers have access to moderate the chat of the Page's live streams . People with Community Manager access can’t switch into the Page or manage the Page on Facebook. Community Managers can moderate live chats through the following actions:
- Delete or report comments.
- Suspend users from live stream chat for 15 minutes.
- Ban users from the current live stream or from all live streams on the Page.
- Pin comments to the top of the live chat.
Note: If your Facebook Page is part of a business portfolio, your Facebook Page access levels are different.
##
Was this helpful?
Yes
No
## Related Articles
Request Facebook access to a Page
How to accept an invitation to access a Facebook Page
How to give, edit or remove Facebook Page access
Requesting release of your Page’s ownership from a Business Account
Recover a hacked Facebook Page you manage
Related Articles
Request Facebook access to a Page
How to accept an invitation to access a Facebook Page
How to give, edit or remove Facebook Page access
Requesting release of your Page’s ownership from a Business Account
Recover a hacked Facebook Page you manage
## Other ways to get help
Chat with Meta AI support assistant
Resolve issues, make changes and get support in real time
- About
- Privacy
- Terms and Policies
- Ad Choices
- Careers
- Cookies
- Create Ad
- Create Page
© 2026 Meta
Feedback
