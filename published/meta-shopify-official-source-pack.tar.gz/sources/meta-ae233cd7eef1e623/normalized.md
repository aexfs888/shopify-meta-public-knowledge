-
Información sobre el acceso a la página de Facebook | Servicio de ayuda de Facebook
Servicio de ayuda
Español
# Información sobre el acceso a la página de Facebook
Copiar enlace
Ayuda para computadoras
Ayuda de la app para iPhone
Ayuda de la app para iPad
Ayuda de la app para Android
Ayuda para navegadores de celular
Ayuda para navegadores de celular básicos
Ayuda de la app Facebook Lite
Más
Ayuda para computadoras
Ayuda de la app para iPhone
Ayuda de la app para iPad
Ayuda de la app para Android
Ayuda para navegadores de celular
Ayuda para navegadores de celular básicos
Ayuda de la app Facebook Lite
Puedes otorgar acceso a Facebook o a tareas a personas de confianza para que te ayuden a administrar la página.
## Acceso a Facebook
El acceso a Facebook puede incluir control total o control parcial. Las personas pueden cambiar a la página y administrarla en Facebook o mediante otras herramientas de Facebook. Con el acceso a Facebook, las personas pueden administrar lo siguiente con control total o parcial:
Contenido : crear, administrar y eliminar contenido en la página, como las publicaciones, las historias y mucho más. Solicita acceso a la administración de derechos y monetización de contenido original.
- Mensajes : responder mensajes directos en la bandeja de entrada en nombre de la página.
- Comentarios : responder comentarios en la página y editar o eliminar comentarios ya hechos por la página.
- Cuentas vinculadas : agregar, administrar o eliminar cuentas vinculadas, como una cuenta de Instagram.
- Anuncios : crear, administrar y eliminar anuncios.
- Estadísticas : usar estadísticas de la página, las publicaciones y los anuncios para analizar el rendimiento de la página.
- Eventos : crear, editar y eliminar eventos de la página.
- Eliminaciones y prohibiciones : eliminar a personas de la página o prohibir su acceso a ella.
Las personas con control total también pueden administrar lo siguiente:
- Configuración : administrar y editar todas las opciones de configuración, como la información de la página, y eliminar la página.
- Acceso : otorgar o eliminar el acceso de las personas a Facebook o a las tareas de la página o de la cuenta de Instagram vinculada, incluido el acceso a Facebook con control total.
Si otorgas a otras personas acceso a Facebook con control total, tendrán el mismo nivel de acceso que tú. Esto significa que podrán otorgar acceso a otras personas para que administren la página, eliminar a cualquier persona de la página (incluso a ti) o eliminar la página. Para que tu página permanezca activa, debe tener al menos una persona con acceso a Facebook con control total. Si ya no hay nadie con control total de la página, se desactivará automáticamente y se programará su eliminación.
## Acceso a tareas
Las personas con acceso a tareas pueden administrar la página mediante otras herramientas de administración, como Meta Business Suite o el administrador de anuncios . Esto quiere decir que no pueden acceder a la cuenta de la página ni administrarla en Facebook.
Las personas con acceso a tareas pueden administrar lo siguiente:
- Contenido : crear, administrar y eliminar contenido en la página, como las publicaciones, las historias y mucho más. Solicitar acceso a métodos para administrar los derechos de tu contenido original y, potencialmente, monetizarlo.
- Mensajes y actividad de la comunidad : responder mensajes directos, hacer comentarios, administrar contenido no deseado y reportar actividad en la página.
- Anuncios : crear, administrar y eliminar anuncios, y realizar otras tareas relacionadas con ellos.
- Estadísticas: consultar el rendimiento de la página, el contenido, los anuncios y las métricas.
## Acceso de community manager
Los community managers tienen acceso a la moderación del chat de los streams en vivo de la página . No pueden acceder a la cuenta de la página ni administrarla en Facebook. Los community managers pueden moderar los chats en vivo de la siguiente manera:
- Eliminar o reportar comentarios.
- Suspender por 15 minutos a usuarios del chat del stream en vivo.
- Bloquear usuarios del stream en vivo actual o de todos los streams en vivo de la página.
- Fijar comentarios en la parte superior del chat en vivo. Nota: Si tu página es parte de un portfolio comercial, tus niveles de acceso son diferentes.
##
¿Te resultó útil?
Sí
No
## Artículos relacionados
Información sobre el estado de la página de Facebook
Aceptar el acceso a una página de Facebook
Solicitar acceso de Facebook a una página
Otorgar, editar o eliminar el acceso a una página de Facebook
Cómo ver los enlaces que visitaste en Facebook
Artículos relacionados
Información sobre el estado de la página de Facebook
Aceptar el acceso a una página de Facebook
Solicitar acceso de Facebook a una página
Otorgar, editar o eliminar el acceso a una página de Facebook
Cómo ver los enlaces que visitaste en Facebook
## Otras formas de obtener ayuda
Chatea con el asistente de ayuda de Meta AI
Resuelve problemas, realiza cambios y obtén ayuda en tiempo real
- Información
- Privacidad
- Condiciones y políticas
- Opciones de anuncios
- Empleo
- Cookies
- Crear anuncio
- Crear página
© 2026 Meta
Enviar comentarios
