- Shopify Help Center | Marketing on Facebook and Instagram
Help
Log in
Contents
# Marketing on Facebook and Instagram
You can use Facebook and Instagram by Meta to sync your products to a catalog on Facebook so that you can create marketing activities for your products on Facebook.
For ad creation across the Facebook, Instagram, Messenger or Audience Network, use Meta's Ads Manager .
After you set up Facebook and Instagram by Meta, you can create the following ads on Facebook to feature your Shopify products:
Facebook audience building ads can increase the traffic to your online store.
- Facebook dynamic retargeting ads can help your customers discover new products from your store.
- Facebook Page posts can make your existing Facebook audience aware of store promotions or new products.
### Optimize your Facebook ad campaigns
After you've created your Facebook ad campaigns, you can assess and optimize their performance by reviewing key metrics in Meta's Ads Manager.
To assess how your ad campaign is performing, review the following core key performance indicators (KPIs):
- CPC (Cost Per Click) : The average cost you pay when someone clicks on your ad.
- CTR (Click-Through Rate) : The percentage of people who click on your ad after viewing it. As a benchmark, aim to achieve at least 1% CTR on Desktop and News Feed ads, and at least 2% on Mobile News Feed ads.
- CPP (Cost Per Purchase) : The average cost to acquire a customer purchase through your ads.
- Frequency : How many times, on average, your ad was shown to each person.
Wait 4-5 days after launching your campaign before making optimization decisions. This provides enough data to make informed changes.
You can get a detailed overview of your ad performance with the following steps:
- In Meta's Ads Manager, open your campaign.
- Click Breakdown to view detailed performance data by placement, demographics, and other factors.
- Use this data to identify which ad sets and placements are performing best, and adjust your targeting or budget accordingly.
For more information on optimizing your Facebook ads, refer to the following resources:
- Facebook Ads Tactics That'll Skyrocket Sales
- How to Optimize Facebook Ads
### In this section
-
Creating Facebook audience building ads to sell your Shopify products
-
Creating Facebook dynamic retargeting ads to sell your Shopify products
-
Creating Facebook Page posts to sell your Shopify products
Leave feedback
