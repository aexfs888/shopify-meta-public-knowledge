# Customer File Custom Audiences
**Warning:** Beginning September 2, 2025, we will start to roll out more proactive restrictions on custom audiences that may suggest information not permitted under our terms. For example, any custom audience or lookalike audience suggesting specific health conditions (e.g., &quot;arthritis&quot;, &quot;diabetes&quot;) or financial status (e.g., &quot;credit score&quot;, &quot;high income&quot;) will be flagged and prevented from being used to run ad campaigns.
**What these restrictions mean for your campaigns:**
* You won&#039;t be able to use flagged custom audiences when creating new campaigns.
* If you have an active campaign using flagged custom audiences, you should edit or pause it and choose a different audience to avoid performance and delivery issues.
**For API developers:**
* Beginning September 2, 2025, `operation_statu`s will return `471` to signal if your custom audiences have been flagged.
More information on this update and how to resolve flagged custom audiences can be found [here](https://www.facebook.com/business/help/1055828013359808).
The Marketing API allows you to build target Custom Audiences from customer information. This includes email addresses, phone numbers, names, dates of birth, gender, locations, [App User IDs](https://developers.facebook.com/docs/graph-api/reference/user), [Page Scoped User IDs](https://developers.facebook.com/docs/app-events/bots-for-messenger), Apple&#039;s Advertising Identifier (IDFA), or [Android Advertising ID](https://developer.android.com/google/play-services/id.html).
**Warning:** As the owner of your business&#039;s data, you are responsible for creating and managing this data. This includes information from your Customer Relationship Management (CRM) systems. To create audiences, you must share your data in a hashed format to maintain privacy. See [Hashing and Normalizing Data](#hash). Meta compares this with our hashed data to see if we should add someone on Facebook to your ad&#039;s audience.
You can add an unlimited number of records to an audience, but only up to 10000 at a time. Changes to your Custom Audiences don&#039;t happen immediately and usually take up to 24 hours. The number of records you request to remove and/or the number of Custom Audiences your account contains will increase the amount of time it takes to process this request.
To improve how advertisers create and manage their audiences, Customer File Custom Audiences that have not been used in any active ad sets in over two years will be flagged for deletion on a rolling basis. You will need to provide us with your instructions before we take any action. Once audiences are moved to the &quot;Expiring Audience&quot; stage and flagged, you will need to provide your instructions by either using the flagged audience in an active ad set, which we will consider an instruction to retain the audience, or by deciding not to use the flagged audience in an active ad set, which we will consider an instruction to delete the audience. For more information, see the [Custom Audiences Overview](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/overview#custom-audiences-deletion) documentation.
**Warning:** If you share conversion events using the [**Conversions API**](https://developers.facebook.com/documentation/ads-commerce/conversions-api), you can create a [website custom audience](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/guides/website-custom-audiences) without additional data uploads. However, you can continue uploading supported customer information to create a Customer File Custom Audience.
## Build a custom audience &#123;#build&#125;
### Step 1: Create an empty [Custom Audience](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience)
Specify `subtype=CUSTOM` and `customer_file_source` in your API call.
```html
curl -X POST \
-F &#039;name=&quot;My new Custom Audience&quot;&#039; \
-F &#039;subtype=&quot;CUSTOM&quot;&#039; \
-F &#039;description=&quot;People who purchased on my website&quot;&#039; \
-F &#039;customer_file_source=&quot;USER_PROVIDED_ONLY&quot;&#039; \
-F &#039;audience_labels=[&quot;HIGH_VALUE_CUSTOMERS&quot;]&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/v25.0/act_&lt;AD_ACCOUNT_ID&gt;/customaudiences
```
#### Parameters
| Name | Description |
| --- | --- |
| `customer_file_source` &lt;br&gt;enum string | Describes how the customer information in your Custom Audience was originally collected. &lt;br&gt;**Values:**&lt;br&gt;&lt;br&gt;* `USER_PROVIDED_ONLY` &lt;br&gt;Advertisers collected information directly from customers&lt;br&gt;* `PARTNER_PROVIDED_ONLY` &lt;br&gt;Advertisers sourced information directly from partners (e.g., agencies or data providers)&lt;br&gt;* `BOTH_USER_AND_PARTNER_PROVIDED` &lt;br&gt;Advertisers collected information directly from customers and it was also sourced from partners (e.g., agencies) |
| `name` &lt;br&gt;string | Custom Audience name |
| `description` &lt;br&gt;string | Custom Audience description |
| `subtype` &lt;br&gt;string | Type of Custom Audience |
| `audience_labels` &lt;br&gt;string | Choose a label that describes this audience. Labels may be used to find audiences for your ads more effectively. [About audience labels](https://www.facebook.com/business/help/706325895111530).&lt;br&gt;&lt;br&gt;**Engaged audiences:**&lt;br&gt;&lt;br&gt;* `QUALIFIED_LEADS` — Leads that meet your qualification criteria.&lt;br&gt;* `DISQUALIFIED_LEADS` — Leads that don&#039;t meet your qualification criteria.&lt;br&gt;* `APP_USERS` — People that are currently using your app.&lt;br&gt;* `TRIAL_USERS` — People who started a trial of your product.&lt;br&gt;* `ENGAGED_USERS` — People that showed interest but are not customers.&lt;br&gt;&lt;br&gt;**Customers:**&lt;br&gt;&lt;br&gt;* `HIGH_VALUE_CUSTOMERS` — Customers you consider valuable to your business.&lt;br&gt;* `LOW_VALUE_CUSTOMERS` — Customers who are of low or negative value to your business.&lt;br&gt;* `AT_RISK` — Customers who are showing signs of disengaging or churning.&lt;br&gt;* `DISENGAGED` — Customers who have not made a purchase recently or stopped subscribing.&lt;br&gt;* `CUSTOMERS` — Your existing customers. |
### Step 2: Specify a list of users
Use a `POST` API call to the `/&#123;audience_id&#125;/users` endpoint to specify the list of users you want to add to your Custom Audience.
#### Parameters
| Name | Description |
| --- | --- |
| `session` &lt;br&gt;JSON Object | **Required** &lt;br&gt;Use the `session` parameter to track if a specific batch of users has been uploaded. &lt;br&gt;If you have an upload with more than 10,000 users, you need to split it into separate batches; each request can take up to 10,000 users.&lt;br&gt;&lt;br&gt;**Example**&lt;br&gt;&lt;br&gt;```
&#123;
&quot;session_id&quot;:9778993,
&quot;batch_seq&quot;:10,
&quot;last_batch_flag&quot;:true,
&quot;estimated_num_total&quot;:99996
&#125;
``` |
| `payload` &lt;br&gt;JSON Object | **Required** &lt;br&gt;Includes `schema` and `data`.&lt;br&gt;&lt;br&gt;**Example**&lt;br&gt;&lt;br&gt;```
&#123;
&quot;schema&quot;:&quot;EMAIL_SHA256&quot;,
&quot;data&quot;:
[
[&quot;&lt;HASHED_DATA&gt;&quot;],
[&quot;&lt;HASHED_DATA&gt;&quot;],
[&quot;&lt;HASHED_DATA&gt;&quot;]
]
&#125;
``` |
#### Data processing options for US users
**Note:** If you want to enable Limited Data Use for people in California via customer list custom audiences on or after June 1, 2023, you must upload new audiences or [update your existing audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/guides/custom-audiences) with the Limited Data Use flag. Regularly update and maintain your audiences and people’s Limited Data Use statuses as needed.
Please note that a Limited Data Use flag applied to a user in one audience will not automatically carry over to different audiences. In the same way advertisers must manage each of their existing customer list custom audiences separately by the criteria they select, the Limited Data Use flag must be applied separately to each audience they leverage for their advertising.
To explicitly NOT enable `LDU` for the record, you can either send an empty `data_processing_options` array or remove the field in the payload. Example of an empty array:
```
&#123;
&quot;payload&quot;: &#123;
&quot;schema&quot;: [
&quot;EMAIL&quot;,
&quot;DATA_PROCESSING_OPTIONS&quot;
],
&quot;data&quot;: [
[
&quot;&lt;HASHED_DATA&gt;
&quot;,
[]
]
]
&#125;
&#125;
```
To explicitly enable `LDU`, and have Meta perform geolocation (by not including state and country of the given record), specify an array containing `LDU` for each record:
```
&#123;
&quot;payload&quot;: &#123;
&quot;schema&quot;: [
&quot;EMAIL&quot;,
&quot;DATA_PROCESSING_OPTIONS&quot;
],
&quot;data&quot;: [
[
&quot;&lt;HASHED_DATA&gt;
&quot;,
[&quot;LDU&quot;]
]
]
&#125;
&#125;
```
To enable LDU and manually specify the location:
```
&#123;
&quot;customer_consent&quot;: true,
&quot;payload&quot;: &#123;
&quot;schema&quot;: [
&quot;EMAIL&quot;,
&quot;DATA_PROCESSING_OPTIONS&quot;,
&quot;DATA_PROCESSING_OPTIONS_COUNTRY&quot;,
&quot;DATA_PROCESSING_OPTIONS_STATE&quot;
],
&quot;data&quot;: [
[
&quot;&lt;HASHED_DATA&gt;&quot;,
[&quot;LDU&quot;],
1,
1000
]
]
&#125;
&#125;
```
#### `session` fields
| Name | Description |
| --- | --- |
| `session_id` &lt;br&gt;positive 64-bit integer | **Required** &lt;br&gt;Identifier used to track the session. This number **must** be generated by the advertiser and unique within a specific ad account. |
| `batch_seq` &lt;br&gt;positive integer | **Required** &lt;br&gt;Number to identify the request listed in the current session. This number **must** be sequential and start from `1`. |
| `last_batch_flag` &lt;br&gt;boolean | **Required** &lt;br&gt;&lt;br&gt;Indicate to our systems that all batches for the ongoing Replace session have been provided. When set to `true`, the current request is the last one from the current session, and we don&#039;t accept any further batches for that session. If you don&#039;t send this flag, we automatically terminate the session 90 minutes after we receive your first batch. Any batch received after 90 minutes is also discarded.&lt;br&gt;**You must mark the last request to let Meta know that this is the last batch.** |
| `estimated_num_total` &lt;br&gt;integer | **Optional** &lt;br&gt;Estimated total number of users to be uploaded in this session. This field is used to improve this session&#039;s processing. |
#### Response
A successful response includes a JSON object with the following fields:
| Name | Description |
| --- | --- |
| `audience_id` &lt;br&gt;numeric string | Audience identifier |
| `session_id` &lt;br&gt;integer | Session ID you passed in |
| `num_received` &lt;br&gt;integer | Total number of users received in this session so far |
| `num_invalid_entries` &lt;br&gt;integer | Number of entries sent with incorrect hashing. Those entries did not return a match and are not added to the custom audience. This is not an exact number, but it represents the number range of users that did not match. |
| `invalid_entry_samples` &lt;br&gt;JSON Array of String or Map &#123;string: string&#125; | Up to 100 samples of invalid entries found in the current request |
Learn more about [sharing your Custom Audience with business objects](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience/adaccounts).
### Error codes
These are errors that may be received when creating custom audiences.
| Error Code | Error Subcode | Description | Resolution |
| --- | --- | --- | --- |
| 1 | | Please reduce the amount of data you&#039;re asking for, then retry your request | This relates to the limit of data to return in an API response. While there is no specific maximum limit, the best practice is to use a limit of 20 with pagination. |
| 100 | 1713098 | Invalid rule JSON format | Check the JSON format and parameters for issues, and retry the call. |
| 200 | 1870050 | Permissions error | Check that the ad account is linked to the Meta Business Suite account. |
| 200 | 1870090 | Custom Audience Terms Not Accepted | Follow the Terms of Service guidelines for custom audiences, specifically for the business the account is acting on behalf of or a shared ad account.&lt;br&gt;To sign the contracts for the original business, a user has to switch to an ad account not acting on behalf of or owned by the business they need to accept. |
## Remove members from a custom audience &#123;#remove&#125;
Use a `DELETE` API call to the `/&#123;audience_id&#125;/users` endpoint to specify the list of users you want to remove from your Custom Audience.
```
curl -X DELETE \
--data-urlencode &#039;payload=&#123;
&quot;schema&quot;: &quot;EMAIL_SHA256&quot;,
&quot;data&quot;: [
&quot;&lt;HASHED_DATA&gt;&quot;,
&quot;&lt;HASHED_DATA&gt;&quot;,
&quot;&lt;HASHED_DATA&gt;&quot;
]
&#125;&#039; \
-d &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/&lt;VERSION&gt;/&lt;CUSTOM_AUDIENCE_ID&gt;/users
```
Or, you can add the `method` parameter and set it to `DELETE` in the `POST` request used to add audience members.
You can remove people from a list with `EXTERN_ID`, if available.
```
curl -X DELETE \
--data-urlencode &#039;payload=&#123;
&quot;schema&quot;: &quot;EXTERN_ID&quot;,
&quot;data&quot;: [
&quot;&lt;ID&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;ID&gt;&quot;
]
&#125;&#039; \
-d &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/&lt;VERSION&gt;/&lt;CUSTOM_AUDIENCE_ID&gt;/users
```
You can remove a list of people from all custom audiences across your ad account using this endpoint.
There may be some reasons why this information is not processed. For example, if the ad account is not owned by a business portfolio, you have not yet accepted the [Custom Audience Terms](https://www.facebook.com/legal/terms/customaudience), or the information does not match with a user.
To remove an Accounts Center account, include the same fields as in [user update](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience/users) and make a `HTTP DELETE` call to:
```
https://graph.facebook.com/&lt;API_VERSION&gt;/act_&lt;AD_ACCOUNT_ID&gt;/usersofanyaudience
```
## Multi-key matching &#123;#multikey&#125;
To increase the match rate for your records, provide multiple keys in an array of individual keys; for example, [`EXTERN_ID`, `LN`, `FN`, `EMAIL`]. While you don&#039;t need to hash `EXTERN_ID`, you must hash all personally identifying information, such as emails and names. For details, see [Hashing and Normalizing Data](#hash).
You can provide some or all multi-keys for a record.
#### Add users with multi-key matches
```
curl \
-F &#039;payload=&#123;
&quot;schema&quot;: [
&quot;FN&quot;,
&quot;LN&quot;,
&quot;EMAIL&quot;
],
&quot;data&quot;: [
[
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;
],
[
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;
]
]
&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/&lt;VERSION&gt;/&lt;CUSTOM_AUDIENCE_ID&gt;/users
```
### Using `PAGEUID` &#123;#PAGEUID&#125;
If you use the `PAGEUID` key, you must also include a list of page IDs. You can only send us one `PAGEUID`, which should be an array with one element.
```
curl -X POST \
-F &#039;payload=&#123;
&quot;schema&quot;: [
&quot;PAGEUID&quot;
],
&quot;is_raw&quot;: &quot;true&quot;,
&quot;page_ids&quot;: [
&quot;&lt;PAGE_IDs&gt;&quot;
],
&quot;data&quot;: [
[
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;VALUE&gt;&quot;
],
[
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;VALUE&gt;&quot;
],
[
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;ID&gt;&quot;,
&quot;&lt;VALUE&gt;&quot;
]
]
&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/&lt;VERSION&gt;/&lt;CUSTOM_AUDIENCE_ID&gt;/users
```
### Hashing and normalization for multi-key &#123;#hash&#125;
You must hash data as `SHA256`; we don&#039;t support other hashing mechanisms. This is required for all data except [External Identifiers](#external_identifiers), [App User IDs](https://developers.facebook.com/docs/graph-api/reference/user), [Page Scoped User IDs](https://developers.facebook.com/docs/app-events/bots-for-messenger) and Mobile Advertiser IDs.
Before you hash your data, normalize it so we can handle it. **Only First name (`FN`) and Last Name (`LN`) support special characters and non-Roman alphabets. For the best match results, provide the Roman alphabet translation with no special characters.**
**Warning:** Please download this CSV file for examples of properly normalized and hashed data for the parameters below.
Download (Right-click &gt; Save Link As)
| Key | Guidelines |
| --- | --- |
| `EMAIL` &lt;br&gt;criteria: email addresses | **Hashing required** &lt;br&gt;Trim leading and trailing white space, and convert all characters to lowercase. |
| `PHONE` &lt;br&gt;criteria: phone numbers | **Hashing required** &lt;br&gt;Remove symbols, letters, and any leading zeroes. You should prefix the country code if the `COUNTRY` field is not specified. |
| `GEN` &lt;br&gt;criteria: gender | **Hashing required** &lt;br&gt;Use these values: `m` for male, `f` for female. |
| `DOBY` &lt;br&gt;criteria: birth year | **Hashing required** &lt;br&gt;Use the *YYYY* format: 1900 to the current year. |
| `DOBM` &lt;br&gt;criteria: birth month | **Hashing required** &lt;br&gt;Use the *MM* format: `01` to `12`. |
| `DOBD` &lt;br&gt;criteria: birthday | **Hashing required** &lt;br&gt;Use the *DD* format: `01` to `31`. |
| `LN` and `FN` &lt;br&gt;criteria: last and first names | **Hashing required** &lt;br&gt;Use `a`-`z` only. Lowercase only, no punctuation. Special characters in UTF-8 format. |
| `FI` &lt;br&gt;criteria: first name initial | **Hashing required** &lt;br&gt;Use `a`-`z` only. Lowercase only. Special characters in UTF-8 format. |
| `ST` &lt;br&gt;criteria: US states | **Hashing required** &lt;br&gt;Use the [2-character ANSI abbreviation code](https://en.wikipedia.org/wiki/Federal_Information_Processing_Standard_state_code), lowercase. Normalize states outside the US in lowercase, with no punctuation, no special characters, and no white space. |
| `CT` &lt;br&gt;criteria: city | **Hashing required** &lt;br&gt;Use `a`-`z` only. Lowercase only, with no punctuation, no special characters, and no white space. |
| `ZIP` &lt;br&gt;criteria: zip code | **Hashing required** &lt;br&gt;Use lowercase, and no white space. For the US, use only the first 5 digits. For the UK, use the Area/District/Sector format. |
| `COUNTRY` &lt;br&gt;criteria: country code | **Hashing required**&lt;br&gt;&lt;br&gt;Use lowercase, 2-letter country codes in [ISO 3166-1 alpha-2](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2). |
| `MADID` &lt;br&gt;criteria: mobile advertiser ID | **Do not hash**&lt;br&gt;&lt;br&gt;Use all lowercase, and keep hyphens. |
## Hashing &#123;#example_sha256&#125;
Provide `SHA256` values for normalized keys and `HEX` representations of this value, using lowercase for A through F. The hash function in PHP converts normalized emails and phone numbers.
| Example | Result |
| --- | --- |
| `hash(&quot;sha256&quot;, &quot;mary&#064;example.com&quot;)` | f1904cf1a9d73a55fa5de0ac823c4403ded71afd4c3248d00bdcd0866552bb79 |
| `hash(&quot;sha256&quot;, &quot;15559876543&quot;)` | 1ef970831d7963307784fa8688e8fce101a15685d62aa765fed23f3a2c576a4e |
## External identifiers &#123;#external_identifiers&#125;
You can match people for an audience with your own identifiers, known as External Identifiers (`EXTERN_ID`). This can be any unique ID from the advertiser, such as loyalty membership IDs, user IDs, and external cookie IDs.
**Warning:** While you don&#039;t need to hash this ID, you must hash all Personally Identifying Information (PII) that you send with the `EXTERN_ID`s.
For better matching, you should also use the exact format when you send the IDs. For example, if you choose to hash using SHA256, make sure to use the same hashed value.
You can use these IDs as individual keys to delete people from Custom Audiences or create new Custom Audiences. This way you don&#039;t need to re-upload any other matching keys. If you tag someone with hashed personal information and `EXTERN_ID`, we give `EXTERN_ID` lower precedence when we match them with people on Facebook.
**Note:** The data retention period for `EXTERN_ID` is 90 days.
You can reuse the `EXTERN_ID` mapping to build customer file custom audiences within a single ad account.
If you have an audience of `EXTERN_ID` fields in your ad account, create a new audience with just these identifiers.
```
curl \
-F &#039;payload=&#123;&quot;schema&quot;:&quot;EXTERN_ID&quot;,&quot;data&quot;:[&quot;&lt;ID&gt;&quot;,&quot;&lt;ID&gt;&quot;]&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/&lt;VERSION&gt;/&lt;CUSTOM_AUDIENCE_ID&gt;/users
```
You can also add people tagged `EXTERN_ID` and with multi-key matching.
```
curl \
-F &#039;payload=&#123;
&quot;schema&quot;: [
&quot;EXTERN_ID&quot;,
&quot;FN&quot;,
&quot;EMAIL&quot;,
&quot;LN&quot;
],
&quot;data&quot;: [
[
&quot;&lt;ID&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;
],
[
&quot;&lt;ID&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;
],
[
&quot;&lt;ID&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;,
&quot;&lt;HASH&gt;&quot;
]
]
&#125;&#039; \
-F &#039;access_token=&lt;ACCESS_TOKEN&gt;&#039; \
https://graph.facebook.com/&lt;VERSION&gt;/&lt;CUSTOM_AUDIENCE_ID&gt;/users
```
**Warning:** We support `EXTERN_ID` parameters for individual [ad accounts](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference). We cannot use values from one ad account for any other ad accounts, even if the accounts belong to the same entity.
## Replace users API &#123;#replace-api&#125;
The `/&lt;CUSTOM_AUDIENCE_ID&gt;/usersreplace` endpoint allows you to perform 2 actions with one API call:
* Completely remove existing users from a specific audience.
* Replace those users with a new set of users.
Using the `/&lt;CUSTOM_AUDIENCE_ID&gt;/usersreplace` endpoint allows you to automatically delete all existing users rather than having to upload a list of users you want to delete. **This endpoint does not reset your ad set&#039;s [learning phase](https://www.facebook.com/business/help/112167992830700) when an audience is part of active ad sets unlike POST or DELETE API calls to the [`/&lt;CUSTOM_AUDIENCE_ID&gt;/users` endpoint](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience/users).**
The Replace Users API only works with audiences that meet the following requirements:
* The number of users in place before running a replace process must be smaller than 100 million. If your audience is larger than 100 million, we suggest leveraging the [`/&lt;CUSTOM_AUDIENCE_ID&gt;/users` endpoint](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience/users) to add and remove users.
* Subtype must be set to `CUSTOM`.
* You cannot replace a value-based customer file custom audience with a non-value-based customer file custom audience, or vice-versa.
### Get started
Before you start a replace process, do the following:
* Make sure your audience&#039;s `operation_status` is `Normal`.
**Warning:** You cannot perform a replace operation if there is one already being executed.
* Don&#039;t add or remove users via `/&lt;CUSTOM_AUDIENCE_ID&gt;/users` during an ongoing replace operation via `/&lt;CUSTOM_AUDIENCE_ID&gt;/usersreplace`. If you try performing a second replace operation before the first is completed, you will receive a message indicating a replace operation is already in progress.
* The maximum duration window for 1 replace session is 90 minutes. The API will reject any batches for a session received after 90 minutes from the time the session started. If you need to send batches for a duration longer than 90 minutes, wait until the replace operation for that session is done, then use the `/&lt;CUSTOM_AUDIENCE&gt;/users` endpoint&#039;s add operation for the rest of your uploads.
* When using multi-batch uploads with session IDs, the schema defined in the first batch must be maintained consistently across all subsequent batches in that session, and changing the schema mid-session will result in errors.
* Once your audience is ready, specify the list of users you want to replace with your custom audience using a `POST` call to `/&lt;CUSTOM_AUDIENCE_ID&gt;/usersreplace`.
* Once you start the replacement progress, your audience&#039;s `operation_status` switches to `replace_in_progress`.
* If your replacement operation is incomplete, your audience&#039;s `operation_status` switches to `replace_error`.
* If an `operation_status` of 471 is returned, the custom audience has been flagged for integrity reasons.
### Sample request
```html
curl POST \
--data &#039;&#123;
&quot;session&quot;: &#123;
&quot;session_id&quot;:9778993,
&quot;batch_seq&quot;:10,
&quot;last_batch_flag&quot;:true,
&quot;estimated_num_total&quot;:99996
&#125;,
&quot;payload&quot;: &#123;
&quot;schema&quot;: [&quot;EMAIL&quot;,&quot;DATA_PROCESSING_OPTIONS&quot;],
&quot;data&quot;: [
[&quot;&lt;HASHED_DATA&gt;&quot;], [&quot;&lt;HASHED_DATA&gt;&quot;]
]
&#125;,
&#125;&#039;
https://graph.facebook.com/v25.0/&lt;CUSTOM_AUDIENCE_ID&gt;/usersreplace?access_token=&lt;ACCESS_TOKEN&gt;
```
### Call parameters
You can include the following parameters in your `POST` call to `/&lt;CUSTOM_AUDIENCE_ID&gt;/usersreplace`:
| Name | Description |
| --- | --- |
| `session`&lt;br&gt;&lt;br&gt;JSON object | **Required.** &lt;br&gt;Used to track if a specific batch of users has been uploaded. Must include a session ID and batch information. See [Session Fields](#session-fields). &lt;br&gt;You can add up to 10,000 people to an audience at a given time. If you have more than 10,000 people, split your session into multiple batches, which should all have 1 session ID.&lt;br&gt;&lt;br&gt;Example:&lt;br&gt;&lt;br&gt;```html
&#123;
&#039;session_id&#039;:9778993,
&#039;batch_seq&#039;:10,
&#039;last_batch_flag&#039;:true,
&#039;estimated_num_total&#039;:99996
&#125;
``` |
| `payload` &lt;br&gt;&lt;br&gt;JSON object | **Required.** &lt;br&gt;Used to provide the information you want to be uploaded to your audience. Must include `schema` and `data`. See [Payload Fields](#payload-fields) for more information.&lt;br&gt;&lt;br&gt;Example:&lt;br&gt;&lt;br&gt;```html
&#123;
&quot;schema&quot;:&quot;EMAIL&quot;,
&quot;data&quot;:[
[&quot;&lt;HASHED_EMAIL&gt;&quot;],
[&quot;&lt;HASHED_EMAIL&gt;&quot;],
[&quot;&lt;HASHED_EMAIL&gt;&quot;]
]
&#125;
``` |
#### `session` object fields &#123;#session-fields&#125;
| Name | Description |
| --- | --- |
| `session_id`&lt;br&gt;&lt;br&gt;64-bit integer | **Required.** &lt;br&gt;Used to track the session. You must generate this identifier and the number must be unique within the same ad account. |
| `batch_seq`&lt;br&gt;&lt;br&gt;integer | **Required. Must start at `1`.** &lt;br&gt;A new replace session starts when we receive a `batch_seq` of `1`. Avoid sending duplicate batches with a sequence of `1` for a given `session_id`. &lt;br&gt;Labeling the first batch is important; the rest of the batches of a session can be duplicates or any number except `1` because we use this parameter to identify the start of the session. All non-first batches for a session should be sent after the first batch. Consider the first batch as a trigger/pre-step for the replace operation. |
| `last_batch_flag`&lt;br&gt;&lt;br&gt;Boolean | **Optional.** &lt;br&gt;Indicates all batches for the ongoing replace session have been provided. When set to true, no further batches are accepted for that session. If you do not set this flag, the session is automatically terminated 90 minutes after the first batch is received. Any batch received after 90 minutes is also discarded. |
| `estimated_num_total`&lt;br&gt;&lt;br&gt;integer | **Optional.** &lt;br&gt;Estimated total number of users to be uploaded in this session. Used by our system to improve a session&#039;s processing. |
#### `payload` object fields &#123;#payload-fields&#125;
| Name | Description |
| --- | --- |
| `schema`&lt;br&gt;&lt;br&gt;string or JSON string array | **Required.** &lt;br&gt;Specify what type of information you will provide. It can be a single key or multi-key from this list:&lt;br&gt;&lt;br&gt;- `EMAIL`&lt;br&gt;- `PHONE`&lt;br&gt;- `GEN`&lt;br&gt;- `DOBY`&lt;br&gt;- `DOBM`&lt;br&gt;- `DOBD`&lt;br&gt;- `LN`&lt;br&gt;- `FN`&lt;br&gt;- `FI`&lt;br&gt;- `CT`&lt;br&gt;- `ST`&lt;br&gt;- `ZIP`&lt;br&gt;- `COUNTRY`&lt;br&gt;- `MADID`&lt;br&gt;- `[&quot;hash1&quot;, &quot;hash2&quot;, ...]`&lt;br&gt;&lt;br&gt;Example:&lt;br&gt;&lt;br&gt;```html
[&quot;PHONE&quot;, &quot;LN&quot;, &quot;FN&quot;, &quot;ZIP&quot;, &quot;DOBYM&quot;]
``` |
| `data`&lt;br&gt;&lt;br&gt;JSON array | **Required.** &lt;br&gt;List of data corresponding to the schema.&lt;br&gt;&lt;br&gt;Examples:&lt;br&gt;&lt;br&gt;- If the schema is `&quot;EMAIL&quot;`, the data should be a list of email `sha256` hashes.&lt;br&gt;- If the schema is a list of hashes as in the previous example, the data should be like `&quot;phone_hash_value&quot;`, `&quot;LN_FN_ZIP_DOBYM&quot;`. |
Once you make your `POST` request, you get a response with the following fields:
| Name | Description |
| --- | --- |
| `account_id`&lt;br&gt;&lt;br&gt;integer | Account identifier. |
| `session_id`&lt;br&gt;&lt;br&gt;integer | Session ID you have previously provided. |
| `num_received`&lt;br&gt;&lt;br&gt;integer | Total number of users received in this session so far. |
| `num_invalid_entries`&lt;br&gt;&lt;br&gt;integer | Total number of users with an invalid format or unable to be decoded. If this number is not zero, recheck your data. |
| `invalid_entry_samples`&lt;br&gt;&lt;br&gt;JSON string array | Up to 100 samples of invalid entries in current request. Recheck your data. |
### Replace users API common errors
All errors returned from the `/&#123;custom-sudience-id&#125;/usersreplace` endpoint have the error code **2650**. Here are some of the most common error subcodes returned, as well as guidance on how to resolve them.
| Error SubCode | Description | What To Do |
| --- | --- | --- |
| 1870145 | Audience Update In Progress | You can&#039;t replace a customer list custom audience that is in the process of being updated. Wait for the audience availability to become &quot;Normal&quot; and try again. |
| 1870158 | Replace Session Timed Out | You&#039;ve reached the 90-minute time limit for your replace batch session. Your customer list custom audience will be replaced with what you&#039;ve uploaded so far. To add more to the custom audience, wait until the replace process is finished, and then use the `ADD` operation. |
| 1870147 | Invalid Upload Batch for Replace | The first `batch_seq` was not detected. You must start your `batch_seq` at integer `1`. |
| 1870159 | Replace Session Finished | This replace operation is already finished because you uploaded a batch with `last_batch_flag==true`. To add additional batches to the custom audience, wait until the replace process is finished, and then use the `ADD` operation. |
| 1870148 | Something Went Wrong | Your customer list was not fully updated. If your audience size is significantly different than expected, consider trying again. |
| 1870144 | DFCA Size Not Supported For Replace | You can&#039;t replace a customer list customer audience that has a size of 100 million or more. |
## FAQ
**What is the recommended maximum value of &quot;limit&quot; that should be used in the /customaudiences endpoint?**
The `limit` field is the maximum number of objects that may be returned in an API call. There is no specific maximum value of the `limit` parameter when querying the custom audience endpoints.
However, the best practice is to use a limit of 20 with pagination. See the [Paginated Results documentation](https://developers.facebook.com/docs/graph-api/results) for more information.
**What are the limits on the number of custom audiences we can have in an account?**
The limits we have on the number of custom audiences in an account:
* Standard Data File Custom Audiences: 500
* Custom Audiences from your website: 10000
* Mobile App Custom Audiences: 200
* Lookalike Audiences: 500
**Is hashing required for Mobile Advertiser IDs (MADID)?**
No.
**Are there any restrictions on an audience based on the Customer File Source (i.e., USER_PROVIDED_ONLY, PARTNER_PROVIDED_ONLY, BOTH_USER_AND_PARTNER_PROVIDED)?**
Currently, there are no restrictions on the `customer_file_source` field when creating a custom audience using the Marketing API.
**How do you resolve the &quot;Custom Audience Terms Not Accepted&quot; error? **
The &quot;Custom Audience Terms Not Accepted&quot; error typically occurs when attempting to create or use a custom audience on Meta&#039;s advertising platform without accepting the necessary terms and conditions or when accepting the terms and conditions for an ad account on behalf of or shared with different businesses.
Please see the [Custom Audiences Terms of Service](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/custom-audience-terms-of-service) document for more information on accepting the terms of service while checking the special use cases of shared ad accounts or on behalf of ad accounts.
## Resources &#123;#types&#125;
There are other types of audiences you can build and target, or share:
* **[Custom Audiences From Your Website](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/guides/website-custom-audiences)** — Create an audience based on people who visited a specific page or made action on your website. Build an audience based on data from [Meta Pixel](https://developers.facebook.com/docs/marketing-api/audiences-api/pixel) on your site.
* **[Custom Audiences From Your Mobile App](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/guides/mobile-app-custom-audiences)** — Create an audience based on people who use your mobile app. Build an audience based on data from [App Events](https://developers.facebook.com/docs/app-events).
* **[Lookalike Audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/guides/lookalike-audiences)** — Identify people you already know and advertise to similar people on the Facebook app.
* **[Offline Custom Audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/guides/offline-custom-audiences)** — Create an audience based on people who visited your store, made calls to your customer service, or took action through other offline means.
* **[Canvas Engagement Audiences](https://developers.facebook.com/documentation/ads-commerce/marketing-api/creative/collection-ads#audience)** — Create an audience that contains anyone who engaged with your Canvas.
## See also
* [Custom Audience](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience)
* [Custom Audience Users](https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/custom-audience/users)
* [Custom Audience Session](https://developers.facebook.com/docs/marketing-api/reference/custom-audience-session)
* [Custom Audience Terms Of Service](https://developers.facebook.com/documentation/ads-commerce/marketing-api/audiences/reference/custom-audience-terms-of-service)
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
