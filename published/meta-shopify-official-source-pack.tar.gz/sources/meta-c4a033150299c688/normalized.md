# &quot;Glossary: Conversions API for Multiple Accounts&quot;
**Warning:** ## This content has moved!
This content has been incorporated into the &quot;Gateway Products&quot; documentation.
* Go to: [Gateway Products: Conversions API Gateway and Signals Gateway](https://developers.facebook.com/documentation/ads-commerce/gateway-products)
---
Full documentation index for this product: https://developers.facebook.com/documentation/ads-commerce/llms.txt
